import {
  SET_DISTRIBUTOR_BASIC_DETAILS,
  SET_DISTRIBUTOR_BASIC_DETAILS_DELETE,
  SET_DISTRIBUTOR_STORE_DETAILS,
  SET_DISTRIBUTOR_STORE_DETAILS_DELETE,
  SET_DISTRIBUTOR_EXISTING_SYSTEM_DETAILS,
  SET_DISTRIBUTOR_SYSTEM_INTEGRATE_DETAILS,
  SET_DISTRIBUTOR_SYSTEM_INTEGRATE_DETAILS_DELETE,
  SET_DISTRIBUTOR_EXCEL_DETAILS,
  SET_DISTRIBUTOR_PERVIEW_CONFIRM,
} from "../actions/types";

const initialState = {
  basicDetails: [],
  storeDetails: [],
  systemDetails: [],
  existingSystem: {},
  excelDetails: {},
};

export default function (state = initialState, action) {
  switch (action.type) {
    case SET_DISTRIBUTOR_BASIC_DETAILS:
      return {
        ...state,
        basicDetails: action.payload,
      };

    case SET_DISTRIBUTOR_BASIC_DETAILS_DELETE:
      let basicDetails = [...state.basicDetails];
      basicDetails.splice(action.payload, 1);
      return {
        ...state,
        basicDetails,
        bootstrapped: basicDetails.length === 0,
      };

    case SET_DISTRIBUTOR_STORE_DETAILS:
      return { ...state, storeDetails: action.payload };

    case SET_DISTRIBUTOR_STORE_DETAILS_DELETE:
      let storeDetails = [...state.storeDetails];
      storeDetails.splice(action.payload, 1);
      return {
        ...state,
        storeDetails,
        bootstrapped: storeDetails.length === 0,
      };

    case SET_DISTRIBUTOR_EXISTING_SYSTEM_DETAILS:
      return {
        ...state,
        existingSystem: action.payload,
        systemDetails: [],
        excelDetails: {},
      };

    case SET_DISTRIBUTOR_SYSTEM_INTEGRATE_DETAILS:
      return {
        ...state,
        systemDetails: action.payload,
        existingSystem: {},
        excelDetails: {},
      };

    case SET_DISTRIBUTOR_SYSTEM_INTEGRATE_DETAILS_DELETE:
      let systemDetails = [...state.systemDetails];
      systemDetails.splice(action.payload, 1);
      return {
        ...state,
        systemDetails,
        bootstrapped: systemDetails.length === 0,
      };

    case SET_DISTRIBUTOR_EXCEL_DETAILS:
      return {
        ...state,
        excelDetails: action.payload,
        systemDetails: [],
        existingSystem: {},
      };

    case SET_DISTRIBUTOR_PERVIEW_CONFIRM:
      return {
        ...state,
        basicDetails: [],
        storeDetails: [],
        systemDetails: [],
        existingSystem: {},
      };

    default:
      return state;
  }
}
