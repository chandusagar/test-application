import {
  SHOW_SUPPLIER_MODEL,
  SHOW_SUPPLIER_ACTIVE_LIST_CLEAR,
  SUPPLIER_MODEL_ACTIVE_LIST,
  SET_SUPPLIER_BASIC_DETAILS,
  SET_SUPPLIER_BASIC_DETAILS_DELETE,
  SET_SUPPLIER_STORE_DETAILS,
  SET_SUPPLIER_STORE_DETAILS_DELETE,
  SET_SUPPLIER_EXISTING_SYSTEM_DETAILS,
  SET_SUPPLIER_RAW_MATERIAL,
  SET_SUPPLIER_RAW_MATERIAL_DELETE,
  SET_SUPPLIER_EXCEL_DETAILS,
  SET_SUPPLIER_PERVIEW_CONFIRM,
} from "../actions/types";

const initialState = {
  activeList: [],
  basicDetails: [],
  storeDetails: [],
  systemDetails: [],
  existingSystem: {},
  excelDetails: {},
  showSupplierModel: false,
};

export default function (state = initialState, action) {
  switch (action.type) {
    case SHOW_SUPPLIER_MODEL:
      return {
        ...state,
        showSupplierModel: action.payload,
      };
    case SUPPLIER_MODEL_ACTIVE_LIST:
      let firstIndex = state.activeList.indexOf(action.key);
      let activeList = [...state.activeList];
      activeList.splice(firstIndex, 1);
      return {
        ...state,
        activeList,
        bootstrapped: activeList.length === 0,
      };

    case SHOW_SUPPLIER_ACTIVE_LIST_CLEAR:
      return {
        ...state,
        activeList: [],
      };

    case SET_SUPPLIER_BASIC_DETAILS:
      return {
        ...state,
        basicDetails: action.payload,
      };

    case SET_SUPPLIER_BASIC_DETAILS_DELETE:
      let basicDetails = [...state.basicDetails];
      basicDetails.splice(action.payload, 1);
      return {
        ...state,
        basicDetails,
        bootstrapped: basicDetails.length === 0,
      };

    case SET_SUPPLIER_STORE_DETAILS:
      return { ...state, storeDetails: action.payload };

    case SET_SUPPLIER_STORE_DETAILS_DELETE:
      let storeDetails = [...state.storeDetails];
      storeDetails.splice(action.payload, 1);
      return {
        ...state,
        storeDetails,
        bootstrapped: storeDetails.length === 0,
      };

    case SET_SUPPLIER_EXISTING_SYSTEM_DETAILS:
      return {
        ...state,
        existingSystem: action.payload,
        systemDetails: [],
        excelDetails: {},
      };

    case SET_SUPPLIER_RAW_MATERIAL:
      return {
        ...state,
        systemDetails: action.payload,
        existingSystem: {},
        excelDetails: {},
      };

    case SET_SUPPLIER_RAW_MATERIAL_DELETE:
      let systemDetails = [...state.systemDetails];
      systemDetails.splice(action.payload, 1);
      return {
        ...state,
        systemDetails,
        bootstrapped: systemDetails.length === 0,
      };

    case SET_SUPPLIER_EXCEL_DETAILS:
      return {
        ...state,
        excelDetails: action.payload,
        systemDetails: [],
        existingSystem: {},
      };

    case SET_SUPPLIER_PERVIEW_CONFIRM:
      return {
        ...state,
        activeList: [],
        basicDetails: [],
        storeDetails: [],
        systemDetails: [],
        existingSystem: {},
      };

    default:
      return state;
  }
}
