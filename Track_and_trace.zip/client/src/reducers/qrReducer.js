import {
  SET_QR_ORDER_TAB_ACTIVE,
  SET_QR_ORDER_ALERT_SUCCESS_MESSAGE,
  SET_QR_ORDER_ALERT_ERROR_MESSAGE,
} from "../actions/types";

const initialState = {
  qrTab: "Create",
  alertSuccessMessage: "",
  alertErrorMessage: "",
};

export default function (state = initialState, action) {
  switch (action.type) {
    case SET_QR_ORDER_TAB_ACTIVE:
      return {
        ...state,
        qrTab: action.payload,
      };
    case SET_QR_ORDER_ALERT_SUCCESS_MESSAGE:
      return {
        ...state,
        alertSuccessMessage: action.payload,
      };
    case SET_QR_ORDER_ALERT_ERROR_MESSAGE:
      return {
        ...state,
        alertErrorMessage: action.payload,
      };
    default:
      return state;
  }
}
