import { combineReducers } from "redux";
import { persistReducer } from "redux-persist";
import storage from "redux-persist/lib/storage";

import supplierReducer from "./supplierReducer";
import manufacturerReducer from "./manufacturerReducer";
import logisticsReducer from "./logisticsReducer";
import distributorReducer from "./distributorReducer";
import retailerReducer from "./retailerReducer";
import qrReducer from "./qrReducer";

const persistConfig = {
  key: "root",
  storage,
  whitelist: [],
};

// "supplier", "manufacture", "logistic", "distributor", "retailer"
// blacklist: ["supplier"],
const rootReducer = combineReducers({
  supplier: supplierReducer,
  manufacture: manufacturerReducer,
  logistic: logisticsReducer,
  distributor: distributorReducer,
  retailer: retailerReducer,
  qrOrder: qrReducer,
});

export default persistReducer(persistConfig, rootReducer);
