import React from "react";
import "./App.css";
import { withRouter } from "react-router-dom";
import Header from "./components/layout/Header";
import { BrowserRouter as Router } from "react-router-dom";
import Routes from "./Routes";
import Sidebar from "./components/layout/Sidebar";
import Home from "./components/layout/Home";

function App() {
  return (
    // <div className="layout layout-nav-side">
    //   <Sidebar />
    //   <div className="main-container">
    //     <Routes />
    //   </div>
    // </div>
    <Home />

    // <Routes />
  );
}

export default App;
