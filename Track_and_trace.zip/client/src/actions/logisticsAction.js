import axios from "axios";

import isEmpty from "../utils/isEmpty";

import {
  SET_LOGISTIC_BASIC_DETAILS,
  SET_LOGISTIC_BASIC_DETAILS_DELETE,
  SET_LOGISTIC_STORE_DETAILS,
  SET_LOGISTIC_STORE_DETAILS_DELETE,
  SET_LOGISTIC_EXISTING_SYSTEM_DETAILS,
  SET_LOGISTIC_SYSTEM_INTEGRATE_DETAILS,
  SET_LOGISTIC_SYSTEM_INTEGRATE_DETAILS_DELETE,
  SET_LOGISTIC_EXCEL_DETAILS,
  SET_LOGISTIC_PERVIEW_CONFIRM,
} from "./types";

export const logisticBasicDetails = (data) => async (dispatch) => {
  dispatch({ type: SET_LOGISTIC_BASIC_DETAILS, payload: data });
};

export const logisticBasicDetailsdelete = (data) => async (dispatch) => {
  dispatch({ type: SET_LOGISTIC_BASIC_DETAILS_DELETE, payload: data });
};

export const logisticStoreDetails = (data) => async (dispatch) => {
  dispatch({ type: SET_LOGISTIC_STORE_DETAILS, payload: data });
};

export const logisticStoreDetailsdelete = (data) => async (dispatch) => {
  dispatch({ type: SET_LOGISTIC_STORE_DETAILS_DELETE, payload: data });
};

export const logisticExistingSystem = (data) => async (dispatch) => {
  dispatch({ type: SET_LOGISTIC_EXISTING_SYSTEM_DETAILS, payload: data });
};

export const logisticSystemDetails = (data) => async (dispatch) => {
  dispatch({ type: SET_LOGISTIC_SYSTEM_INTEGRATE_DETAILS, payload: data });
};

export const logisticSystemDetailsdelete = (data) => async (dispatch) => {
  dispatch({
    type: SET_LOGISTIC_SYSTEM_INTEGRATE_DETAILS_DELETE,
    payload: data,
  });
};
export const logisticImportExcelSheet = (data) => async (dispatch) => {
  dispatch({ type: SET_LOGISTIC_EXCEL_DETAILS, payload: data });
};

export const logisticPerviewConfirm = () => async (dispatch) => {
  dispatch({ type: SET_LOGISTIC_PERVIEW_CONFIRM, payload: [] });
};

const headers = {
  "Content-Type": "application/json",
  Authorization: `Bearer ${localStorage.getItem("trackTraceJWToken")}`,
};

// Get Logistic details
export const setEditLogisticDetails = (logisticId) => async (dispatch) => {
  try {
    let result = await axios.get(
      `${process.env.REACT_APP_QR_API}/myInventories/logistics/${logisticId}`,
      { headers: headers }
    );

    let basicDetails = [];
    let storageDetails = [];

    if (!isEmpty(result.data.data)) {
      const logistic = result.data.data;

      if (!isEmpty(logistic.basicDetails)) {
        basicDetails.push(logistic.basicDetails);
      }

      if (!isEmpty(logistic.storageUnits)) {
        logistic.storageUnits.forEach((store) => {
          store.supplierName = logistic.basicDetails.emailId;
        });
        storageDetails = logistic.storageUnits;
      }
    }

    dispatch({ type: SET_LOGISTIC_BASIC_DETAILS, payload: basicDetails });
    dispatch({
      type: SET_LOGISTIC_STORE_DETAILS,
      payload: storageDetails,
    });
  } catch (err) {
    dispatch({ type: SET_LOGISTIC_PERVIEW_CONFIRM, payload: [] });
  }
};
