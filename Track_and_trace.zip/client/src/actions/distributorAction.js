import axios from "axios";

import isEmpty from "../utils/isEmpty";

import {
  SET_DISTRIBUTOR_BASIC_DETAILS,
  SET_DISTRIBUTOR_BASIC_DETAILS_DELETE,
  SET_DISTRIBUTOR_STORE_DETAILS,
  SET_DISTRIBUTOR_STORE_DETAILS_DELETE,
  SET_DISTRIBUTOR_EXISTING_SYSTEM_DETAILS,
  SET_DISTRIBUTOR_SYSTEM_INTEGRATE_DETAILS,
  SET_DISTRIBUTOR_SYSTEM_INTEGRATE_DETAILS_DELETE,
  SET_DISTRIBUTOR_EXCEL_DETAILS,
  SET_DISTRIBUTOR_PERVIEW_CONFIRM,
} from "./types";

export const distributorBasicDetails = (data) => async (dispatch) => {
  dispatch({ type: SET_DISTRIBUTOR_BASIC_DETAILS, payload: data });
};

export const distributorBasicDetailsdelete = (data) => async (dispatch) => {
  dispatch({ type: SET_DISTRIBUTOR_BASIC_DETAILS_DELETE, payload: data });
};

export const distributorStoreDetails = (data) => async (dispatch) => {
  dispatch({ type: SET_DISTRIBUTOR_STORE_DETAILS, payload: data });
};

export const distributorStoreDetailsdelete = (data) => async (dispatch) => {
  dispatch({ type: SET_DISTRIBUTOR_STORE_DETAILS_DELETE, payload: data });
};

export const distributorExistingSystem = (data) => async (dispatch) => {
  dispatch({ type: SET_DISTRIBUTOR_EXISTING_SYSTEM_DETAILS, payload: data });
};

export const distributorSystemDetails = (data) => async (dispatch) => {
  dispatch({ type: SET_DISTRIBUTOR_SYSTEM_INTEGRATE_DETAILS, payload: data });
};

export const distributorSystemDetailsdelete = (data) => async (dispatch) => {
  dispatch({
    type: SET_DISTRIBUTOR_SYSTEM_INTEGRATE_DETAILS_DELETE,
    payload: data,
  });
};

export const distributorImportExcelSheet = (data) => async (dispatch) => {
  dispatch({ type: SET_DISTRIBUTOR_EXCEL_DETAILS, payload: data });
};

export const distributorPerviewConfirm = () => async (dispatch) => {
  dispatch({ type: SET_DISTRIBUTOR_PERVIEW_CONFIRM, payload: [] });
};

const headers = {
  "Content-Type": "application/json",
  Authorization: `Bearer ${localStorage.getItem("trackTraceJWToken")}`,
};

// Get distributor details
export const setEditDistributorDetails = (distributorId) => async (
  dispatch
) => {
  try {
    let result = await axios.get(
      `${process.env.REACT_APP_QR_API}/myInventories/distributors/${distributorId}`,
      { headers: headers }
    );

    let basicDetails = [];
    let storageDetails = [];

    if (!isEmpty(result.data.data)) {
      const distributor = result.data.data;

      if (!isEmpty(distributor.basicDetails)) {
        basicDetails.push(distributor.basicDetails);
      }

      if (!isEmpty(distributor.storageUnits)) {
        distributor.storageUnits.forEach((store) => {
          store.distributorName = distributor.basicDetails.emailId;
        });
        storageDetails = distributor.storageUnits;
      }

      dispatch({ type: SET_DISTRIBUTOR_BASIC_DETAILS, payload: basicDetails });
      dispatch({
        type: SET_DISTRIBUTOR_STORE_DETAILS,
        payload: storageDetails,
      });
    }
  } catch (err) {
    dispatch({ type: SET_DISTRIBUTOR_PERVIEW_CONFIRM, payload: [] });
  }
};
