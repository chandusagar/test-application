import axios from "axios";

import isEmpty from "../utils/isEmpty";

import {
  SHOW_SUPPLIER_MODEL,
  SHOW_SUPPLIER_ACTIVE_LIST_CLEAR,
  SUPPLIER_MODEL_ACTIVE_LIST,
  SET_SUPPLIER_BASIC_DETAILS,
  SET_SUPPLIER_BASIC_DETAILS_DELETE,
  SET_SUPPLIER_STORE_DETAILS,
  SET_SUPPLIER_STORE_DETAILS_DELETE,
  SET_SUPPLIER_EXISTING_SYSTEM_DETAILS,
  SET_SUPPLIER_RAW_MATERIAL,
  SET_SUPPLIER_RAW_MATERIAL_DELETE,
  SET_SUPPLIER_EXCEL_DETAILS,
  SET_SUPPLIER_PERVIEW_CONFIRM,
} from "./types";

export const showSupplierModel = (data) => async (dispatch) => {
  dispatch({ type: SHOW_SUPPLIER_MODEL, payload: data });
};
export const showActiveTabsClear = () => async (dispatch) => {
  dispatch({ type: SHOW_SUPPLIER_ACTIVE_LIST_CLEAR, payload: [] });
};

export const showSupplierModelActive = (data) => async (dispatch) => {
  dispatch({ type: SUPPLIER_MODEL_ACTIVE_LIST, payload: data });
};

export const supplierBasicDetails = (data) => async (dispatch) => {
  dispatch({ type: SET_SUPPLIER_BASIC_DETAILS, payload: data });
};
export const supplierBasicDetailsDelete = (data) => async (dispatch) => {
  dispatch({ type: SET_SUPPLIER_BASIC_DETAILS_DELETE, payload: data });
};

export const supplierStoreDetails = (data) => async (dispatch) => {
  dispatch({ type: SET_SUPPLIER_STORE_DETAILS, payload: data });
};

export const supplierStoreDetailsDelete = (data) => async (dispatch) => {
  dispatch({ type: SET_SUPPLIER_STORE_DETAILS_DELETE, payload: data });
};

export const suppliereExistingSystem = (data) => async (dispatch) => {
  console.log(data);
  dispatch({ type: SET_SUPPLIER_EXISTING_SYSTEM_DETAILS, payload: data });
};

export const supplierRawMeterial = (data) => async (dispatch) => {
  dispatch({ type: SET_SUPPLIER_RAW_MATERIAL, payload: data });
};

export const supplierRawMeterialDelete = (data) => async (dispatch) => {
  dispatch({ type: SET_SUPPLIER_RAW_MATERIAL_DELETE, payload: data });
};

export const supplierImportExcelSheet = (data) => async (dispatch) => {
  dispatch({ type: SET_SUPPLIER_EXCEL_DETAILS, payload: data });
};

export const supplierPerviewConfirm = () => async (dispatch) => {
  dispatch({ type: SET_SUPPLIER_PERVIEW_CONFIRM, payload: [] });
};

const headers = {
  "Content-Type": "application/json",
  Authorization: `Bearer ${localStorage.getItem("trackTraceJWToken")}`,
};

// Get supplier details
export const setEditSupplierDetails = (supplierId) => async (dispatch) => {
  try {
    let result = await axios.get(
      `${process.env.REACT_APP_QR_API}/myInventories/suppliers/${supplierId}`,
      { headers: headers }
    );
    let basicDetails = [];
    let storageDetails = [];

    if (!isEmpty(result.data.data)) {
      const supplier = result.data.data;

      if (!isEmpty(supplier.basicDetails)) {
        basicDetails.push(supplier.basicDetails);
      }

      if (!isEmpty(supplier.storageUnits)) {
        supplier.storageUnits.forEach((store) => {
          store.supplierName = supplier.basicDetails.emailId;
        });
        storageDetails = supplier.storageUnits;
      }

      dispatch({ type: SET_SUPPLIER_BASIC_DETAILS, payload: basicDetails });
      dispatch({ type: SET_SUPPLIER_STORE_DETAILS, payload: storageDetails });
    }
  } catch (err) {
    dispatch({ type: SET_SUPPLIER_PERVIEW_CONFIRM, payload: [] });
  }
};
