import axios from "axios";

import isEmpty from "../utils/isEmpty";

import {
  SET_RETAILER_BASIC_DETAILS,
  SET_RETAILER_BASIC_DETAILS_DELETE,
  SET_RETAILER_STORE_DETAILS,
  SET_RETAILER_STORE_DETAILS_DELETE,
  SET_RETAILER_EXISTING_SYSTEM_DETAILS,
  SET_RETAILER_SYSTEM_INTEGRATE_DETAILS,
  SET_RETAILER_SYSTEM_INTEGRATE_DETAILS_DELETE,
  SET_RETAILER_EXCEL_DETAILS,
  SET_RETAILER_PERVIEW_CONFIRM,
} from "./types";

export const retailerBasicDetails = (data) => async (dispatch) => {
  dispatch({ type: SET_RETAILER_BASIC_DETAILS, payload: data });
};

export const retailerBasicDetailsdelete = (data) => async (dispatch) => {
  dispatch({ type: SET_RETAILER_BASIC_DETAILS_DELETE, payload: data });
};

export const retailerStoreDetails = (data) => async (dispatch) => {
  dispatch({ type: SET_RETAILER_STORE_DETAILS, payload: data });
};

export const retailerStoreDetailsdelete = (data) => async (dispatch) => {
  dispatch({ type: SET_RETAILER_STORE_DETAILS_DELETE, payload: data });
};
export const retailerExistingSystem = (data) => async (dispatch) => {
  dispatch({ type: SET_RETAILER_EXISTING_SYSTEM_DETAILS, payload: data });
};

export const retailerSystemDetails = (data) => async (dispatch) => {
  dispatch({ type: SET_RETAILER_SYSTEM_INTEGRATE_DETAILS, payload: data });
};

export const retailerSystemDetailsdelete = (data) => async (dispatch) => {
  dispatch({
    type: SET_RETAILER_SYSTEM_INTEGRATE_DETAILS_DELETE,
    payload: data,
  });
};

export const retailerImportExcelSheet = (data) => async (dispatch) => {
  dispatch({ type: SET_RETAILER_EXCEL_DETAILS, payload: data });
};

export const retailerPerviewConfirm = () => async (dispatch) => {
  dispatch({ type: SET_RETAILER_PERVIEW_CONFIRM, payload: [] });
};

const headers = {
  "Content-Type": "application/json",
  Authorization: `Bearer ${localStorage.getItem("trackTraceJWToken")}`,
};

// Get retailer details
export const setEditRetailerDetails = (retailerId) => async (dispatch) => {
  try {
    let result = await axios.get(
      `${process.env.REACT_APP_QR_API}/myInventories/retailers/${retailerId}`,
      { headers: headers }
    );

    let basicDetails = [];
    let storageDetails = [];

    if (!isEmpty(result.data.data)) {
      const retailer = result.data.data;

      if (!isEmpty(retailer.basicDetails)) {
        basicDetails.push(retailer.basicDetails);
      }

      if (!isEmpty(retailer.storageUnits)) {
        retailer.storageUnits.forEach((store) => {
          store.retailerName = retailer.basicDetails.emailId;
        });
        storageDetails = retailer.storageUnits;
      }

      dispatch({ type: SET_RETAILER_BASIC_DETAILS, payload: basicDetails });
      dispatch({ type: SET_RETAILER_STORE_DETAILS, payload: storageDetails });
    }
  } catch (err) {
    dispatch({ type: SET_RETAILER_PERVIEW_CONFIRM, payload: [] });
  }
};
