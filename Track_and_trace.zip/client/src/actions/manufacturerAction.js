import axios from "axios";

import isEmpty from "../utils/isEmpty";

import {
  SET_MANUFACTURER_BASIC_DETAILS,
  SET_MANUFACTURER_BASIC_DETAILS_DELETE,
  SET_MANUFACTURER_STORE_DETAILS,
  SET_MANUFACTURER_STORE_DETAILS_DELETE,
  SET_MANUFACTURER_EXISTING_SYSTEM_DETAILS,
  SET_MANUFACTURER_SYSTEM_INTEGRATE_DETAILS,
  SET_MANUFACTURER_SYSTEM_INTEGRATE_DETAILS_DELETE,
  SET_MANUFACTURER_EXCEL_DETAILS,
  SET_MANUFACTURER_PERVIEW_CONFIRM,
} from "./types";

export const manufactureBasicDetails = (data) => async (dispatch) => {
  dispatch({ type: SET_MANUFACTURER_BASIC_DETAILS, payload: data });
};

export const manufactureBasicDetailsdelete = (data) => async (dispatch) => {
  dispatch({ type: SET_MANUFACTURER_BASIC_DETAILS_DELETE, payload: data });
};

export const manufactureStoreDetails = (data) => async (dispatch) => {
  dispatch({ type: SET_MANUFACTURER_STORE_DETAILS, payload: data });
};

export const manufactureStoreDetailsdelete = (data) => async (dispatch) => {
  dispatch({ type: SET_MANUFACTURER_STORE_DETAILS_DELETE, payload: data });
};
export const manufactureExistingSystem = (data) => async (dispatch) => {
  dispatch({ type: SET_MANUFACTURER_EXISTING_SYSTEM_DETAILS, payload: data });
};

export const manufactureSystemDetails = (data) => async (dispatch) => {
  dispatch({ type: SET_MANUFACTURER_SYSTEM_INTEGRATE_DETAILS, payload: data });
};

export const manufactureSystemDetailsdelete = (data) => async (dispatch) => {
  dispatch({
    type: SET_MANUFACTURER_SYSTEM_INTEGRATE_DETAILS_DELETE,
    payload: data,
  });
};
export const manufactureImportExcelSheet = (data) => async (dispatch) => {
  dispatch({ type: SET_MANUFACTURER_EXCEL_DETAILS, payload: data });
};
export const manufacturePerviewConfirm = () => async (dispatch) => {
  dispatch({ type: SET_MANUFACTURER_PERVIEW_CONFIRM, payload: [] });
};

const headers = {
  "Content-Type": "application/json",
  Authorization: `Bearer ${localStorage.getItem("trackTraceJWToken")}`,
};

// Get manufacturer details
export const setEditManufacturerDetails = (manufacturerId) => async (
  dispatch
) => {
  try {
    let result = await axios.get(
      `${process.env.REACT_APP_QR_API}/myInventories/manufacturers/${manufacturerId}`,
      { headers: headers }
    );

    let basicDetails = [];
    let storageDetails = [];

    if (!isEmpty(result.data.data)) {
      const manufacturer = result.data.data;

      if (!isEmpty(manufacturer.basicDetails)) {
        basicDetails.push(manufacturer.basicDetails);
      }

      if (!isEmpty(manufacturer.storageUnits)) {
        manufacturer.storageUnits.forEach((store) => {
          store.manufacturerName = manufacturer.basicDetails.emailId;
        });
        storageDetails = manufacturer.storageUnits;
      }

      dispatch({ type: SET_MANUFACTURER_BASIC_DETAILS, payload: basicDetails });
      dispatch({
        type: SET_MANUFACTURER_STORE_DETAILS,
        payload: storageDetails,
      });
    }
  } catch (err) {
    dispatch({ type: SET_MANUFACTURER_PERVIEW_CONFIRM, payload: [] });
  }
};
