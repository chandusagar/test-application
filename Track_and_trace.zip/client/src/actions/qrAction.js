import {
  SET_QR_ORDER_ALERT_SUCCESS_MESSAGE,
  SET_QR_ORDER_ALERT_ERROR_MESSAGE,
  SET_QR_ORDER_TAB_ACTIVE,
} from "./types";

export const changeAlertSuccessMessage = (message) => (dispatch) => {
  dispatch({ type: SET_QR_ORDER_ALERT_SUCCESS_MESSAGE, payload: message });
};

export const changeAlertErrorMessage = (message) => (dispatch) => {
  dispatch({ type: SET_QR_ORDER_ALERT_ERROR_MESSAGE, payload: message });
};

export const changeQRActiveTabs = (tabName) => (dispatch) => {
  dispatch({ type: SET_QR_ORDER_TAB_ACTIVE, payload: tabName });
};
