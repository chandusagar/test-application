import axios from "axios";

import isEmpty from "../utils/isEmpty";

export const trackProducts = {};

const headers = {
  "Content-Type": "application/json",
  Authorization: `Bearer ${localStorage.getItem("trackTraceJWToken")}`,
};

// track product id get list
trackProducts.getProductId = async (id) => {
  try {
    let res = await axios.get(
      `${process.env.REACT_APP_TRACK_TRACE_MOBILE_API}/products/productDetails/${id}`,
      { headers: headers }
    );
    return !isEmpty(res.data) ? res.data.data : [];
  } catch (err) {
    throw err.response ? err.response.data : err;
  }
};

// track package id get list
trackProducts.getPackageId = async (id) => {
  try {
    let res = await axios.get(
      `${process.env.REACT_APP_QR_API}/orders/packages/${id}`,
      { headers: headers }
    );
    console.log(res);
    return !isEmpty(res.data.data) ? res.data.data : [];
  } catch (err) {
    throw err.response ? err.response.data : err;
  }
};
