import { onBoardInventoryServices } from "./onBoardInventoryService";
import { userManagementServices } from "./userManagementServices";

import { qrCodeServices } from "./qrCodeServices";

import { productLinkServices } from "./productLinkServices";

import { trackProducts } from "./trackProducts";

export default {
  onBoardInventoryServices,
  qrCodeServices,
  userManagementServices,
  productLinkServices,
  trackProducts,
};
