import axios from "axios";

export const onBoardInventoryServices = {};

const headers = {
  "Content-Type": "application/json",
  Authorization: `Bearer ${process.env.REACT_APP_TOKEN}`,
};

onBoardInventoryServices.storeSupplierBasicDetails = async (data) => {
  try {
    let res = await axios.post(
      `${process.env.REACT_APP_BLOCKCHAIN_API}/channels/mychannel/chaincodes/usecase`,
      data,
      { headers: headers }
    );
    return res.data;
  } catch (err) {
    throw err.response ? err.response.data : err;
    // throw new Error(err.response ? err.response.data : err);
  }
};
onBoardInventoryServices.storeManufacturerDetails = async (data) => {
  try {
    let res = await axios.post(
      `${process.env.REACT_APP_BLOCKCHAIN_API}/channels/mychannel/chaincodes/usecase `,
      data,
      { headers: headers }
    );
    return res.data;
  } catch (err) {
    throw err.response ? err.response.data : err;
    // throw new Error(err.response ? err.response.data : err);
  }
};

onBoardInventoryServices.storeLogisticDetails = async (data) => {
  try {
    let res = await axios.post(
      `${process.env.REACT_APP_BLOCKCHAIN_API}/channels/mychannel/chaincodes/usecase `,
      data,
      { headers: headers }
    );
    return res.data;
  } catch (err) {
    throw err.response ? err.response.data : err;
    // throw new Error(err.response ? err.response.data : err);
  }
};

onBoardInventoryServices.storeDistbutorDetails = async (data) => {
  try {
    let res = await axios.post(
      `${process.env.REACT_APP_BLOCKCHAIN_API}/channels/mychannel/chaincodes/usecase `,
      data,
      { headers: headers }
    );
    return res.data;
  } catch (err) {
    throw err.response ? err.response.data : err;
    // throw new Error(err.response ? err.response.data : err);
  }
};

onBoardInventoryServices.storeRetailerDetails = async (data) => {
  try {
    let res = await axios.post(
      `${process.env.REACT_APP_BLOCKCHAIN_API}/channels/mychannel/chaincodes/usecase `,
      data,
      { headers: headers }
    );
    return res.data;
  } catch (err) {
    throw err.response ? err.response.data : err;
    // throw new Error(err.response ? err.response.data : err);
  }
};

onBoardInventoryServices.integrateAPI = async (data) => {
  console.log(data);
  try {
    let res = await axios.post(`${data.url}`, data.body, {
      headers: data.header,
    });
    return res.data;
  } catch (err) {
    console.log(err.errors);
    throw new Error(err.response ? err.response.data : err);
  }
};
