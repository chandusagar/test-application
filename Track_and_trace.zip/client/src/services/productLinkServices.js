import axios from "axios";

import isEmpty from "../utils/isEmpty";

export const productLinkServices = {};

const headers = {
  "Content-Type": "application/json",
  Authorization: `Bearer ${localStorage.getItem("trackTraceJWToken")}`,
};

/**Block Chain Headers */
const blockChainheaders = {
  "Content-Type": "application/json",
  Authorization: `Bearer ${process.env.REACT_APP_TOKEN}`,
};

productLinkServices.productTypeList = async () => {
  try {
    let res = await axios.get(
      `${process.env.REACT_APP_QR_API}/products/getProductTypesOrCategories`,
      {
        headers: headers,
      }
    );
    return !isEmpty(res.data.data) ? res.data.data : [];
  } catch (err) {
    return [];
  }
};

productLinkServices.productType = async (id) => {
  try {
    let res = await axios.get(
      `${process.env.REACT_APP_QR_API}/products/getCategoriesWithCount?productType=${id}`,
      {
        headers: headers,
      }
    );
    return !isEmpty(res.data.data) ? res.data.data : [];
  } catch (err) {
    return [];
  }
};
// Product categories

productLinkServices.productCategories = async () => {
  try {
    let res = await axios.get(`${process.env.REACT_APP_QR_API}/suppliers`, {
      headers: headers,
    });
    return !isEmpty(res.data.data) ? res.data.data : [];
  } catch (err) {
    return [];
  }
};

productLinkServices.rawMaterialList = async (id) => {
  try {
    let res = await axios.get(
      `${process.env.REACT_APP_QR_API}/rawMaterials/bySupplierEmailId/${id}`,
      {
        headers: headers,
      }
    );
    return !isEmpty(res.data.data) ? res.data.data : [];
  } catch (err) {
    return [];
  }
};

productLinkServices.saveProductLink = async (data) => {
  try {
    let res = await axios.post(
      `${process.env.REACT_APP_BLOCKCHAIN_API}/channels/mychannel/chaincodes/usecase`,
      data,
      {
        headers: blockChainheaders,
      }
    );
    return res.data;
  } catch (err) {
    throw err.response ? err.response.data : err;
  }
};
