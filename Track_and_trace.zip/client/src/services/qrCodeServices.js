import axios from "axios";

import isEmpty from "../utils/isEmpty";

export const qrCodeServices = {};

const headers = {
  "Content-Type": "application/json",
  Authorization: `Bearer ${localStorage.getItem("trackTraceJWToken")}`,
};

// Get & Return the product types list
qrCodeServices.getProductTypes = async () => {
  try {
    let result = await axios.get(
      `${process.env.REACT_APP_QR_API}/products/getProductTypesOrCategories`,
      { headers: headers }
    );

    return !isEmpty(result.data.data) ? result.data.data : [];
  } catch (err) {
    return [];
  }
};

// Get & Return the product category types
qrCodeServices.getProductCatelogues = async (productType) => {
  try {
    let result = await axios.get(
      `${process.env.REACT_APP_QR_API}/products/getProductTypesOrCategories?productType=${productType}`,
      { headers: headers }
    );

    return !isEmpty(result.data.data) ? result.data.data : [];
  } catch (err) {
    return [];
  }
};

// Get & Return product ids range
qrCodeServices.getProductIdsRange = async (
  productType,
  category,
  totalQuantity
) => {
  try {
    let result = await axios.get(
      `${process.env.REACT_APP_QR_API}/products/getProductsRange?productType=${productType}&productCategory=${category}&totalQuantity=${totalQuantity}`,
      { headers: headers }
    );

    return result.data.data;
  } catch (err) {
    return [];
  }
};

// Save new order
qrCodeServices.saveOrder = async (formData) => {
  try {
    let result = await axios.post(
      `${process.env.REACT_APP_QR_API}/orders`,
      formData,
      { headers: headers }
    );

    if (!isEmpty(result.data)) {
      return result.data;
    } else {
      return { isError: true };
    }
  } catch (err) {
    return err.response ? err.response.data : err;
  }
};

// Get list of orders
qrCodeServices.getOrders = async () => {
  try {
    let result = await axios.get(`${process.env.REACT_APP_QR_API}/orders`, {
      headers: headers,
    });

    if (!isEmpty(result.data)) {
      return result.data.data;
    } else {
      return [];
    }
  } catch (err) {
    return [];
  }
};

// Get order details by id
qrCodeServices.getOrderDetails = async (id) => {
  try {
    let result = await axios.get(
      `${process.env.REACT_APP_QR_API}/orders/${id}`,
      { headers: headers }
    );

    if (!isEmpty(result.data)) {
      return result.data.data;
    } else {
      return {};
    }
  } catch (err) {
    return {};
  }
};

// Activate QR code by order id
qrCodeServices.activateQrCodes = async (id) => {
  try {
    let result = await axios.get(
      `${process.env.REACT_APP_QR_API}/orders/activateQRCodes/${id}`,
      { headers: headers }
    );

    if (!isEmpty(result.data)) {
      return result.data;
    } else {
      return { isError: true };
    }
  } catch (err) {
    return { isError: true };
  }
};

// Save new supplier order
qrCodeServices.saveSupplierOrder = async (formData) => {
  try {
    let result = await axios.post(
      `${process.env.REACT_APP_QR_API}/supplierOrders`,
      formData,
      { headers: headers }
    );

    if (!isEmpty(result.data)) {
      return result.data;
    } else {
      return { isError: true };
    }
  } catch (err) {
    return err.response ? err.response.data : err;
  }
};

// Get list of supplier orders
qrCodeServices.getSupplierOrders = async () => {
  try {
    let result = await axios.get(
      `${process.env.REACT_APP_QR_API}/supplierOrders`,
      { headers: headers }
    );

    if (!isEmpty(result.data)) {
      return result.data.data;
    } else {
      return [];
    }
  } catch (err) {
    return [];
  }
};

// Get supplier order details by id
qrCodeServices.getSupplierOrderDetails = async (id) => {
  try {
    let result = await axios.get(
      `${process.env.REACT_APP_QR_API}/supplierOrders/${id}`,
      { headers: headers }
    );

    if (!isEmpty(result.data)) {
      return result.data.data;
    } else {
      return {};
    }
  } catch (err) {
    return {};
  }
};

// Activate Supplier QR code by order id
qrCodeServices.activateSupplierQrCodes = async (id) => {
  try {
    let result = await axios.get(
      `${process.env.REACT_APP_QR_API}/supplierOrders/activateQRCodes/${id}`,
      { headers: headers }
    );

    if (!isEmpty(result.data)) {
      return result.data;
    } else {
      return { isError: true };
    }
  } catch (err) {
    return { isError: true };
  }
};

// Get order package qrcodes by order id
qrCodeServices.getOrderPackageQRCodes = async (id) => {
  try {
    let result = await axios.get(
      `${process.env.REACT_APP_QR_API}/orders/getOrderQRCodes/${id}`,
      { headers: headers }
    );

    if (!isEmpty(result.data)) {
      return result.data.data;
    } else {
      return {};
    }
  } catch (err) {
    return {};
  }
};

// Get & Return suppliers list
qrCodeServices.getSuppliers = async () => {
  try {
    let result = await axios.get(`${process.env.REACT_APP_QR_API}/suppliers`, {
      headers: headers,
    });
    return !isEmpty(result.data.data) ? result.data.data : [];
  } catch (err) {
    return [];
  }
};

// Get & Return supplier raw materials list
qrCodeServices.getSupplierRawMaterials = async (supplierMailId) => {
  try {
    let result = await axios.get(
      `${process.env.REACT_APP_QR_API}/suppliers/rawMaterials?supplierMailId=${supplierMailId}`,
      { headers: headers }
    );
    return !isEmpty(result.data.data) ? result.data.data : [];
  } catch (err) {
    return [];
  }
};

// Get & Return raw material ids range
qrCodeServices.getRawMaterialsRange = async (
  totalQuantity,
  supplierMailId,
  rawMaterial
) => {
  try {
    const urlString = `?totalQuantity=${totalQuantity}&supplierMailId=${supplierMailId}&rawMaterial=${rawMaterial}`;
    let result = await axios.get(
      `${process.env.REACT_APP_QR_API}/rawMaterials/getRawMaterialsRange${urlString}`,
      { headers: headers }
    );

    return result.data.data;
  } catch (err) {
    return [];
  }
};

// Get order package qrcodes by order id
qrCodeServices.getSupplierOrderPackageQRCodes = async (id) => {
  try {
    let result = await axios.get(
      `${process.env.REACT_APP_QR_API}/supplierOrders/getOrderQRCodes/${id}`,
      { headers: headers }
    );

    if (!isEmpty(result.data)) {
      return result.data.data;
    } else {
      return {};
    }
  } catch (err) {
    return {};
  }
};

// Get Supplier details by mailId
qrCodeServices.getSupplierDetailsByEmail = async (mailId) => {
  try {
    let result = await axios.get(
      `${process.env.REACT_APP_QR_API}/suppliers/detailsByMailId/${mailId}`,
      { headers: headers }
    );

    if (!isEmpty(result.data)) {
      return result.data.data;
    } else {
      return {};
    }
  } catch (err) {
    return {};
  }
};

// Get list of my inventories
qrCodeServices.getMyInventories = async () => {
  try {
    let result = await axios.get(
      `${process.env.REACT_APP_QR_API}/myInventories`,
      { headers: headers }
    );

    return !isEmpty(result.data) ? result.data.data : [];
  } catch (err) {
    return [];
  }
};

// Get list of my inventories data based on suppliers,manufacturers,logistics,distributers and retailers
qrCodeServices.getInventoriesDataForDelete = async (title) => {
  try {
    let result = await axios.get(
      `${
        process.env.REACT_APP_QR_API
      }/myInventories/${title.toLowerCase()}?delete=True`,
      { headers: headers }
    );

    return !isEmpty(result.data) ? result.data.data : [];
  } catch (err) {
    return [];
  }
};

// Delete selected inventories data based on suppliers,manufacturers,logistics,distributers and retailers
qrCodeServices.deleteSelectedInventoriesData = async (title, ids) => {
  const bodyData = { ids };

  try {
    let result = await axios.post(
      `${process.env.REACT_APP_QR_API}/myInventories/${title.toLowerCase()}`,
      bodyData,
      { headers: headers }
    );

    return !isEmpty(result.data) ? result.data : { isError: true };
  } catch (err) {
    return { isError: true };
  }
};

// Get list of my inventories data based on suppliers,manufacturers,logistics,distributers and retailers
qrCodeServices.getInventoriesDataForViewOrEdit = async (title) => {
  try {
    let result = await axios.get(
      `${process.env.REACT_APP_QR_API}/myInventories/${title.toLowerCase()}`,
      { headers: headers }
    );

    return !isEmpty(result.data) ? result.data.data : [];
  } catch (err) {
    return [];
  }
};

// Cancel Order
qrCodeServices.cancelOrder = async (from, orderId) => {
  let apiName = "orders";
  if (from === "Supplier") {
    apiName = "supplierOrders";
  }

  try {
    let result = await axios.post(
      `${process.env.REACT_APP_QR_API}/${apiName}/cancelOrder/${orderId}`,
      { headers: headers }
    );

    return !isEmpty(result.data) ? result.data : { isError: true };
  } catch (err) {
    return { isError: true };
  }
};
