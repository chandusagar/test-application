import axios from "axios";
import jwt_decode from "jwt-decode";

import isEmpty from "../utils/isEmpty";
import setAuthToken from "../utils/setAuthToken";

export const userManagementServices = {};

const headers = {
  "Content-Type": "application/json",
  Authorization: `Bearer ${localStorage.getItem("trackTraceJWToken")}`,
};

userManagementServices.createOrganizationUser = async (data) => {
  try {
    let res = await axios.post(
      `${process.env.REACT_APP_TRACK_TRACE_ACCOUNTS_API}/organizations/`,
      data
    );
    return res.data;
  } catch (err) {
    throw err.response ? err.response.data : err;
  }
};

userManagementServices.signupUser = async (data) => {
  try {
    let res = await axios.post(
      `${process.env.REACT_APP_TRACK_TRACE_ACCOUNTS_API}/users/signup`,
      data
    );
    return res.data;
  } catch (err) {
    throw err.response ? err.response.data : err;
  }
};

userManagementServices.addAdminUser = async (data) => {
  try {
    let res = await axios.post(
      `${process.env.REACT_APP_TRACK_TRACE_ACCOUNTS_API}/users/addAdminUser`,
      data
    );
    return res.data;
  } catch (err) {
    throw err.response ? err.response.data : err;
  }
};

userManagementServices.signinUser = async (data) => {
  try {
    let res = await axios.post(
      `${process.env.REACT_APP_TRACK_TRACE_ACCOUNTS_API}/users/signin`,
      data
    );
    let token = res.data.token;
    localStorage.setItem("trackTraceJWToken", token);
    headers.Authorization = `Bearer ${token}`;
    // set token to Auth header
    setAuthToken(token);
    const decode = jwt_decode(token);
    setCurrentUser(decode);
    // return res.data;
  } catch (err) {
    // throw new Error(err.response ? JSON.stringify(err.response.data) : err);
    throw err.response ? err.response.data : err;
  }
};

userManagementServices.verifyAccount = async (data) => {
  try {
    let res = await axios.post(
      `${process.env.REACT_APP_TRACK_TRACE_ACCOUNTS_API}/users/verify`,
      data
    );
    // return res;
  } catch (err) {
    throw err.response ? err.response.data : err;
    // throw new Error(err.response ? err.response.data : err);
  }
};

userManagementServices.resendVerificationCode = async (data) => {
  try {
    let res = await axios.post(
      `${process.env.REACT_APP_TRACK_TRACE_ACCOUNTS_API}/users/resend`,
      data
    );
  } catch (err) {
    throw err.response ? err.response.data : err;
  }
};

userManagementServices.signoutUser = async () => {
  try {
    let res = await axios.post(
      `${process.env.REACT_APP_TRACK_TRACE_ACCOUNTS_API}/users/signout`,
      {},
      { headers: headers }
    );
    localStorage.removeItem("trackTraceJWToken");
    setCurrentUser({});
    //remove the auth header for future requests
    setAuthToken(false);
    return res.data;
  } catch (err) {
    throw err.response ? err.response.data : err;
  }
};

userManagementServices.setCurrentUser = () => {
  // let user = {};
  let userInfo = localStorage.getItem("userInfo");
  return userInfo;
};

//set signedin user
const setCurrentUser = (decoded) => {
  console.log(decoded);
  let userData = JSON.stringify(decoded);
  localStorage.setItem("userInfo", userData);
};

// user Management apis
userManagementServices.addUser = async (data) => {
  try {
    let res = await axios.post(
      `${process.env.REACT_APP_TRACK_TRACE_ACCOUNTS_API}/users/addUser`,
      data,
      { headers: headers }
    );
    return res.data;
  } catch (err) {
    throw err.response ? err.response.data : err;
  }
};

userManagementServices.getUser = async () => {
  try {
    let res = await axios.get(
      `${process.env.REACT_APP_TRACK_TRACE_ACCOUNTS_API}/users`,
      {
        headers: headers,
      }
    );
    return !isEmpty(res.data.data) ? res.data.data : [];
  } catch (err) {
    return [];
  }
};

userManagementServices.editUser = async (id, data) => {
  try {
    let res = await axios.put(
      `${process.env.REACT_APP_TRACK_TRACE_ACCOUNTS_API}/users/${id}`,
      data,
      { headers: headers }
    );
    return res.data;
  } catch (err) {
    throw new Error(err.response ? err.response.data : err);
  }
};

userManagementServices.deleteUser = async (id) => {
  try {
    let res = await axios.delete(
      `${process.env.REACT_APP_TRACK_TRACE_ACCOUNTS_API}/users/${id}`,
      { headers: headers }
    );
    return res.data;
  } catch (err) {
    throw new Error(err.response ? err.response.data : err);
  }
};

userManagementServices.getCategory = async () => {
  try {
    let res = await axios.get(
      `${process.env.REACT_APP_TRACK_TRACE_ACCOUNTS_API}/users/getCategory`,
      { headers: headers }
    );
    return !isEmpty(res.data.data) ? res.data.data : [];
  } catch (err) {
    return [];
    // throw new Error(err.response ? err.response.data : err);
  }
};

userManagementServices.getRoles = async () => {
  try {
    let res = await axios.get(
      `${process.env.REACT_APP_TRACK_TRACE_ACCOUNTS_API}/roles`,
      {
        headers: headers,
      }
    );
    return !isEmpty(res.data.data) ? res.data.data : [];
  } catch (err) {
    return [];
    // throw new Error(err.response ? err.response.data : err);
  }
};

userManagementServices.companyList = async (name) => {
  try {
    let res = await axios.get(
      `${process.env.REACT_APP_TRACK_TRACE_ACCOUNTS_API}/company/${name}`,
      {
        headers: headers,
      }
    );
    return !isEmpty(res.data.data) ? res.data.data : [];
  } catch (err) {
    return [];
    // throw new Error(err.response ? err.response.data : err);
  }
};
