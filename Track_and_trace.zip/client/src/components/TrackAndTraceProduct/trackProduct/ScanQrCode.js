import React from "react";

class ScanQrCode extends React.Component {
  render() {
    return (
      <div class="qr-content">
        <div class="empty-track-screen">
          <img
            src="../assets/img/bar-code.png"
            alt="bar-code"
            style={{ width: "250px" }}
            class="mb-3"
          />
          <p class="text-danger">
            Open the QR Code reader on your phone.
            <br />
            Hold your device over a QR Code
            <br />
            so that it’s clearly visible within your
            <br />
            smart phone’s screen.
          </p>
        </div>
      </div>
    );
  }
}

export default ScanQrCode;
