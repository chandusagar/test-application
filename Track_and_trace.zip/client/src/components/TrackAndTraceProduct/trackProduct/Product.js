import React from "react";
import Gmap from "../../common/Gmap";

import isEmpty from "../../../utils/isEmpty";

import service from "../../../services";

class Product extends React.Component {
  state = {
    productId: "",
    listView: "",
    locationView: "",
    mapDetails: [],
    productData: {},
  };
  componentDidMount() {
    this.activeView("list");
  }

  /**view Current location function*/
  activeLocation = (show) => {
    if (!this.state.locationView) {
      this.setState({ locationView: show });
    } else {
      this.setState({ locationView: "" });
    }
  };

  /**list and map view function */
  activeView = (list) => {
    let mapDetails = JSON.parse(JSON.stringify(this.state.mapDetails));
    let arr = [];
    let trackLogs =
      this.state.productData && this.state.productData.trackLogs
        ? this.state.productData.trackLogs
        : [];
    trackLogs.forEach((item, i) => {
      let obj = {
        lat: Number(item.latitude),
        lng: Number(item.longitude),
        address: item,
      };
      arr.push(obj);
    });
    mapDetails = arr;
    this.setState({ listView: list, mapDetails });
  };

  onChange = (e) => {
    const { name, value } = e.target;
    this.setState({ [name]: value });
  };

  onSubmit = (e) => {
    e.preventDefault();
    let productId = this.state.productId;
    service.trackProducts
      .getProductId(productId)
      .then((success) => {
        let productData = success;
        this.setState({ productData });
      })
      .catch((error) => {
        console.log(error);
      });
  };

  clear = () => {
    this.setState((prevProps) => {
      prevProps.productId = "";
      return prevProps;
    });
  };

  /**product track details show function */
  liveLocation = () => {
    let listData = !isEmpty(this.state.productData)
      ? this.state.productData.trackLogs
      : [];

    let productList = [
      { docType: "Supplier", faIcon: "fa-truck" },
      { docType: "Manufacturer", faIcon: "fa-industry" },
      { docType: "Logistics", faIcon: "fa-truck-loading" },
      { docType: "Distributor", faIcon: "fa-warehouse" },
      { docType: "Retailer", faIcon: "fa-store" },
    ];

    return listData.map((item, index) => (
      <div
        className={
          productList[index].docType === item.docType
            ? // item.packageId
              "uc-supplyflow__item uc-supplyflow__item--active"
            : "uc-supplyflow__item uc-supplyflow__item--deactive"
        }
        key={index}
      >
        <div className="uc-supplyflow__item-section">
          <div className="uc-supplyflow__item-section-border">
            <div className="uc-supplyflow__item-section-icon">
              <i className={`fa ${productList[index].faIcon} uc-font-icon`}></i>
            </div>
          </div>
          {productList[index].docType === item.docType ? (
            <div className="uc-supplyflow__item-text">
              <span className="font-weight-bolder">{item.docType}</span>
              <div className="time-line-txt w-50">
                {item.previousDocType ? item.previousDocType : ""}
                {item.address ? (
                  <div className="time-line-txt m-0">
                    {`${item.address},${item.city},${item.state} ${item.zipCode},${item.country}`}
                  </div>
                ) : (
                  ""
                )}
              </div>
            </div>
          ) : (
            ""
          )}
        </div>
      </div>
    ));
  };

  render() {
    return (
      <>
        <div className="qr-content">
          <div className="row">
            <div className="col-md-6">
              <div className="form-row">
                <div className="form-group col-md-6">
                  <label for="product_id">Enter your Product Id</label>
                  <input
                    className="form-control"
                    type="text"
                    name="productId"
                    onChange={this.onChange}
                    value={this.state.productId}
                    placeholder="Product id"
                  />
                </div>
                <div className="pro-track-btn">
                  <button
                    type="submit"
                    className="btn btn-primary px-2 mr-2"
                    onClick={this.onSubmit}
                  >
                    Submit
                  </button>
                  <button
                    type="button"
                    className="btn btn-primary-ghost px-2"
                    onClick={this.clear}
                  >
                    Clear
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>

        {!isEmpty(this.state.productData) ? (
          <>
            <div className="pro-details-content">
              <div className="pro-image-l">
                <img
                  src={
                    !isEmpty(this.state.productData)
                      ? this.state.productData.productImage
                      : ""
                  }
                  alt="product-image"
                />
              </div>
              <div className="pro-details-r">
                <h4>
                  {!isEmpty(this.state.productData)
                    ? `${this.state.productData.productType}, ${this.state.productData.productCategory}`
                    : ""}
                  {/* Greek Yogurt, Blueberry{" "} */}
                </h4>
                <div className="pro-det-contain">
                  <div className="l-pro-det">
                    <div className="text-dark w-2 mb-3">Quantity</div>
                    <div className="text-dark w-2">Description</div>
                  </div>
                  <div className="r-pro-det">
                    <div className="mb-3 mt-2">
                      <span className="quat-box">
                        <span>90</span>
                        <span>gms</span>
                      </span>
                    </div>
                    <div className="pro-desc">
                      <p>
                        {!isEmpty(this.state.productData)
                          ? this.state.productData.productDescription
                          : ""}
                        {/* The most exotic of fruits makes a statement when blended
                        with our Greek yogurt. Being one of our most loved
                        flavours, Blueberry will make you scrape the bottom of
                        the cup for more! */}
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div className="qr-content m-0">
              <div className="pro-qr-details">
                <div className="qr-block">
                  <div className="text-muted">QR code date</div>
                  <div className="text-dark">
                    {" "}
                    {!isEmpty(this.state.productData)
                      ? this.state.productData.created
                      : ""}
                    {/* 29/05/2020 */}
                  </div>
                </div>
                <div className="qr-block">
                  <div className="text-muted">Product Id</div>
                  <div className="text-dark">
                    {!isEmpty(this.state.productData)
                      ? this.state.productData.productId
                      : ""}
                    {/* YP-U-MG-65758 */}
                  </div>
                </div>
                <div className="qr-block">
                  <div className="text-muted">QR code Batch ID</div>
                  <div className="text-dark">
                    {" "}
                    {!isEmpty(this.state.productData)
                      ? this.state.productData.parentQRCodeId
                      : ""}
                    {/* U-MG-095758 */}
                  </div>
                </div>
                <div className="qr-block">
                  <div className="text-muted">Current Loction</div>
                  {this.state.productData &&
                  this.state.productData.trackLogs ? (
                    <div
                      className="text-blue"
                      style={{ cursor: "pointer" }}
                      onClick={() =>
                        this.activeLocation(
                          this.state.productData.trackLogs[
                            this.state.productData.trackLogs.length - 1
                          ].docType
                        )
                      }
                    >
                      {this.state.productData &&
                      this.state.productData.trackLogs
                        ? this.state.productData.trackLogs[
                            this.state.productData.trackLogs.length - 1
                          ].docType
                        : ""}
                    </div>
                  ) : (
                    ""
                  )}
                </div>
              </div>
            </div>

            {this.state.locationView ? (
              <div className="scan-status-content">
                <div className="col col-lg-12 d-flex justify-content-end mt-2">
                  <div
                    className="btn-toolbar d-none d-md-block mb-1 btn-toggle"
                    role="toolbar"
                    aria-label="Toolbar with buttons"
                  >
                    <div
                      className="btn-group btn-group-toggle"
                      data-toggle="buttons"
                    >
                      <label
                        className={
                          this.state.listView === "list"
                            ? "btn btn-outline-secondary active"
                            : "btn btn-outline-secondary"
                        }
                        onClick={() => this.activeView("list")}
                      >
                        List view
                      </label>
                      <label
                        className={
                          this.state.listView === "map"
                            ? "btn btn-outline-secondary active"
                            : "btn btn-outline-secondary"
                        }
                        onClick={() => this.activeView("map")}
                      >
                        Map view
                      </label>
                    </div>
                  </div>
                </div>

                {this.state.listView === "list" ? (
                  <div className="scan-timeline">
                    <div className="uc-supplyflow">{this.liveLocation()}</div>
                  </div>
                ) : this.state.listView === "map" ? (
                  <div className="scan-map-timeline">
                    <Gmap
                      style={{
                        position: "relative",
                        width: "100%",
                        height: "365px",
                      }}
                      mapDetails={this.state.mapDetails}
                    />
                  </div>
                ) : (
                  ""
                )}
              </div>
            ) : (
              ""
            )}
          </>
        ) : (
          ""
        )}
      </>
    );
  }
}

export default Product;
