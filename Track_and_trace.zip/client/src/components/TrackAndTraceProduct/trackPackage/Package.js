import React from "react";
import Gmap from "../../common/Gmap";
import isEmpty from "../../../utils/isEmpty";

import service from "../../../services";

class Package extends React.Component {
  state = {
    packageId: "",
    listView: "",
    locationView: "",
    mapDetails: [],
    packageData: [],
  };
  componentDidMount() {
    this.activeView("list");
  }

  /**view Current location function*/
  activeLocation = (show) => {
    if (!this.state.locationView) {
      this.setState({ locationView: show });
    } else {
      this.setState({ locationView: "" });
    }
  };

  /**list and map view function */
  activeView = (list) => {
    let mapDetails = JSON.parse(JSON.stringify(this.state.mapDetails));
    let arr = [];
    var trackLogs = !isEmpty(this.state.packageData)
      ? this.state.packageData.trackLogs
      : [];
    trackLogs.forEach((item, i) => {
      let obj = {
        lat: Number(item.latitude),
        lng: Number(item.longitude),
        address: item,
      };
      arr.push(obj);
    });
    mapDetails = arr;
    this.setState({ listView: list, mapDetails });
  };

  onChange = (e) => {
    const { name, value } = e.target;
    this.setState({ [name]: value });
  };

  onSubmit = (e) => {
    e.preventDefault();
    let packageId = this.state.packageId;
    let packageData = JSON.parse(JSON.stringify(this.state.packageData));
    service.trackProducts
      .getPackageId(packageId)
      .then((success) => {
        packageData = success;
        this.setState({ packageData });
      })
      .catch((error) => {
        console.log(error);
      });
  };

  clear = () => {
    this.setState((prevProps) => {
      prevProps.packageId = "";
      return prevProps;
    });
  };

  /**product track details show function */
  liveLocation = () => {
    // const listData = this.state.packageList;
    let packageList = !isEmpty(this.state.packageData)
      ? this.state.packageData.trackLogs
      : [];

    let listData = [
      { docType: "Supplier", faIcon: "fa-truck" },
      { docType: "Manufacturer", faIcon: "fa-industry" },
      { docType: "Logistics", faIcon: "fa-truck-loading" },
      { docType: "Distributor", faIcon: "fa-warehouse" },
      { docType: "Retailer", faIcon: "fa-store" },
    ];

    return listData.map((item, index) => (
      <div
        className={
          packageList[index].docType === item.docType
            ? // packageList[index].productId
              "uc-supplyflow__item uc-supplyflow__item--active"
            : "uc-supplyflow__item uc-supplyflow__item--deactive"
        }
        key={index}
      >
        <div className="uc-supplyflow__item-section">
          <div className="uc-supplyflow__item-section-border">
            <div className="uc-supplyflow__item-section-icon">
              <i className={`fa ${item.faIcon} uc-font-icon`}></i>
            </div>
          </div>
          {packageList[index].docType === item.docType ? (
            <div className="uc-supplyflow__item-text">
              <span className="font-weight-bolder">
                {packageList[index].docType}
              </span>
              <div className="time-line-txt w-50">
                {/* {packageList[index].docType ? packageList[index].docType : ""} */}
                {packageList[index].address ? (
                  <address className="time-line-txt m-0">
                    {`${packageList[index].address},${packageList[index].city},${packageList[index].state} ${packageList[index].zipCode},${packageList[index].country}`}
                  </address>
                ) : (
                  ""
                )}
              </div>
            </div>
          ) : (
            ""
          )}
        </div>
      </div>
    ));
  };

  render() {
    return (
      <>
        <div className="qr-content">
          <div className="row">
            <div className="col-md-6">
              <div className="form-row">
                <div className="form-group col-md-6">
                  <label for="product_id">Enter your Package id</label>
                  <input
                    className="form-control"
                    type="text"
                    name="packageId"
                    onChange={this.onChange}
                    value={this.state.packageId}
                    placeholder="PackageId"
                  />
                </div>
                <div className="pro-track-btn">
                  <button
                    type="submit"
                    className="btn btn-primary px-2 mr-2"
                    onClick={this.onSubmit}
                  >
                    Submit
                  </button>
                  <button
                    type="button"
                    className="btn btn-primary-ghost px-2"
                    onClick={this.clear}
                  >
                    Clear
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>

        {!isEmpty(this.state.packageData) ? (
          <>
            <div className="pro-details-content">
              <div className="pro-image-l">
                <img
                  src={
                    !isEmpty(this.state.packageData.qrId)
                      ? this.state.packageData.qrId.qrCodeUrl
                      : ""
                  }
                  alt="product-image"
                />
              </div>
              <div className="pro-details-r">
                {/* <h4>Greek Yogurt, Blueberry </h4> */}
                <div className="pro-det-contain">
                  <div className="l-pro-det">
                    {/* <div className="text-dark w-2 mb-3">Quantity</div>
                    <div className="text-dark w-2">Description</div> */}
                    <div className="text-dark w-2 mb-3">QRcode Id</div>
                    <div className="text-dark w-2 mb-3">QRcode Type</div>
                  </div>
                  <div className="r-pro-det">
                    {/* <div className="mb-3 mt-2">
                      <span className="quat-box">
                        <span>90</span>
                        <span>gms</span>
                      </span>
                    </div> */}
                    <div className="pro-desc mb-3">
                      {!isEmpty(this.state.packageData.qrId) ? (
                        <p>{this.state.packageData.qrId._id}</p>
                      ) : (
                        ""
                      )}
                    </div>
                    <div className="pro-desc mb-3">
                      {!isEmpty(this.state.packageData.qrId) ? (
                        <p>{this.state.packageData.qrId.qrCodeType}</p>
                      ) : (
                        ""
                      )}
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div className="qr-content m-0">
              <div className="pro-qr-details">
                <div className="qr-block">
                  <div className="text-muted">QR code date</div>
                  {!isEmpty(this.state.packageData.qrId) ? (
                    <div className="text-dark">
                      {this.state.packageData.qrId.created}
                    </div>
                  ) : (
                    ""
                  )}
                  {/* <div className="text-dark">29/05/2020</div> */}
                </div>
                <div className="qr-block">
                  <div className="text-muted">Package Ids</div>
                  {!isEmpty(this.state.packageData.productIds) ? (
                    <div className="text-dark">
                      {`${this.state.packageData.productIds[0]} - ${this.state.packageData.productIds[1]}`}
                      {/* YP-U-MG-65758 */}
                    </div>
                  ) : (
                    ""
                  )}
                </div>
                <div className="qr-block">
                  <div className="text-muted">QR code Batch ID</div>
                  {!isEmpty(this.state.packageData) ? (
                    <div className="text-dark">
                      {this.state.packageData._id}
                    </div>
                  ) : (
                    ""
                  )}
                </div>
                <div className="qr-block">
                  <div className="text-muted">Current Loction</div>
                  {!isEmpty(this.state.packageData) ? (
                    <div
                      className="text-blue"
                      style={{ cursor: "pointer" }}
                      onClick={() =>
                        this.activeLocation(
                          // this.state.packageList[
                          //   this.state.packageList.length - 1
                          // ].name
                          this.state.packageData.trackLogs[
                            this.state.packageData.trackLogs.length - 1
                          ].docType
                        )
                      }
                    >
                      {
                        this.state.packageData.trackLogs[
                          this.state.packageData.trackLogs.length - 1
                        ].docType
                      }
                    </div>
                  ) : (
                    ""
                  )}
                </div>
              </div>
            </div>

            {this.state.locationView ? (
              <div className="scan-status-content">
                <div className="col col-lg-12 d-flex justify-content-end mt-2">
                  <div
                    className="btn-toolbar d-none d-md-block mb-1 btn-toggle"
                    role="toolbar"
                    aria-label="Toolbar with buttons"
                  >
                    <div
                      className="btn-group btn-group-toggle"
                      data-toggle="buttons"
                    >
                      <label
                        className={
                          this.state.listView === "list"
                            ? "btn btn-outline-secondary active"
                            : "btn btn-outline-secondary"
                        }
                        onClick={() => this.activeView("list")}
                      >
                        List view
                      </label>
                      <label
                        className={
                          this.state.listView === "map"
                            ? "btn btn-outline-secondary active"
                            : "btn btn-outline-secondary"
                        }
                        onClick={() => this.activeView("map")}
                      >
                        Map view
                      </label>
                    </div>
                  </div>
                </div>

                {this.state.listView === "list" ? (
                  <div className="scan-timeline">
                    <div className="uc-supplyflow">{this.liveLocation()}</div>
                  </div>
                ) : this.state.listView === "map" ? (
                  <div className="scan-map-timeline">
                    <Gmap
                      style={{
                        position: "relative",
                        width: "100%",
                        height: "365px",
                      }}
                      mapDetails={this.state.mapDetails}
                    />
                  </div>
                ) : (
                  ""
                )}
              </div>
            ) : (
              ""
            )}
          </>
        ) : (
          ""
        )}
      </>
    );
  }
}

export default Package;
