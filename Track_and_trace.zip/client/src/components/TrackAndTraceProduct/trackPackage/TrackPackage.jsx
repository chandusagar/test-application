import React from "react";

import Header from "../../layout/Header";
import Package from "./Package";
import ScanQrCode from "../trackProduct/ScanQrCode";

class TrackPackage extends React.Component {
  state = {
    activeTab: "",
  };

  componentDidMount() {
    this.setState({ activeTab: "manuval" });
  }

  activeTab = (step) => {
    this.setState({ activeTab: step });
  };

  render() {
    return (
      <div className="main-container">
        <Header name="Track Product" />
        <div className="qr-content-container">
          <div className="uc-step-module">
            <div className="uc-step-module-top">
              <div className="row">
                <div className="col-lg-6 col-xl-6 order-lg-1 order-xl-1">
                  <div
                    className="btn-toolbar d-none d-md-block mb-1 btn-toggle"
                    role="toolbar"
                    aria-label="Toolbar with buttons"
                  >
                    <div
                      className="btn-group btn-group-toggle"
                      data-toggle="buttons"
                    >
                      <label
                        className={
                          this.state.activeTab === "manuval"
                            ? "btn btn-outline-secondary active"
                            : "btn btn-outline-secondary"
                        }
                        onClick={() => this.activeTab("manuval")}
                      >
                        Manual Entry
                      </label>
                      <label
                        className={
                          this.state.activeTab === "ScanQr"
                            ? "btn btn-outline-secondary active"
                            : "btn btn-outline-secondary"
                        }
                        onClick={() => this.activeTab("ScanQr")}
                      >
                        Scan QR code
                      </label>
                    </div>
                  </div>
                </div>
              </div>
              {this.state.activeTab === "manuval" ? (
                <Package />
              ) : this.state.activeTab === "ScanQr" ? (
                <ScanQrCode />
              ) : (
                ""
              )}
            </div>
          </div>
        </div>
      </div>
    );
  }
}

export default TrackPackage;
