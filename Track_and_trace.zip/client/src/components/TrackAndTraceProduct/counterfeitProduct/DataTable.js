import React from "react";
import { DataTable } from "primereact/datatable";
import { Column } from "primereact/column";
import { Button } from "primereact/button";

class DefaultTable extends React.Component {
  render() {
    const dynamicColumns = this.props.column.map((col, index) => {
      return (
        <Column
          key={col.field}
          field={col.field}
          header={col.header}
          body={
            this.props.modifyColums
              ? (rowData, col) => this.props.modifyColums(rowData, col)
              : ""
          }
        />
      );
    });

    return (
      <div className="custom-table mt-1">
        <DataTable
          expandedRows={this.props.expandedRowId}
          rowExpansionTemplate={(e) => this.props.rowExpansionTemplate(e)}
          dataKey="_id"
          className="table table-bordered table-sm mb-1"
          value={this.props.respData}
          emptyMessage="No records found"
          paginator={true}
          rows={10}
          rowsPerPageOptions={[10, 25, 50, 100]}
        >
          {dynamicColumns}
        </DataTable>
      </div>
    );
  }
}

export default DefaultTable;
