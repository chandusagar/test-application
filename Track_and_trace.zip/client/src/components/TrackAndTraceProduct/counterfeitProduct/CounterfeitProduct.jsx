import React from "react";

import Header from "../../layout/Header";
import DataTable from "./DataTable";
import isEmpty from "../../../utils/isEmpty";

import Gmap from "../../common/Gmap";

class CounterfeitProduct extends React.Component {
  state = {
    expandedRowId: null,
    column: [
      { field: "_id", header: "S No" },
      { field: "ProductId", header: "Product / Package Id" },
      { field: "ProductType", header: "Type of product / package" },
      { field: "Located", header: "Located at" },
      { field: "Date", header: "Date & time" },
      { field: "Issuse", header: "Issuse" },
      { field: "Actions", header: "Actions" },
    ],
    details: [
      {
        _id: 1,
        ProductId: "04845",
        ProductType: "Yogurt Packet",
        Located: "Vipra Deepa Super Market",
        Date: "03/6/2020 11:30 am",
        Issuse: "Duplicate of QR code",
      },
      {
        _id: 2,
        ProductId: "04855",
        ProductType: "Yogurt Packet",
        Located: "Heritage Fresh - Sainikpuri",
        Date: "03/6/2020 11:30 am",
        Issuse: "Duplicate of QR code",
      },
      {
        _id: 3,
        ProductId: "04855",
        ProductType: "Yogurt Packet",
        Located: "Heritage Fresh - Sainikpuri",
        Date: "03/6/2020 11:30 am",
        Issuse: "Duplicate of QR code",
      },
    ],

    productList: [
      {
        name: "Retailer",
        qrcodedate: "29/05/2020",
        packageId: "YP- U-MG-65758",
        qrcodeBatchId: "U-MG-095758",
        locationDetails: [
          {
            packageId: "YP- U-MG-65758",
            comapnyName: "Agri Fram house",
            address: "National Highway 7, Zoo Park Main Road, Hasan Nagar",
            city: "Hyderabad,",
            state: "Telangana",
            zipCode: "500052",
            country: "India",
            date: "22/05/2020",
            time: " 05:00  PM",
            latitude: "17.385044",
            longitude: "78.486671",
          },
          {
            packageId: "",
            comapnyName: "Dodla Dairy",
            address:
              "Plot No 20, MMTS Railway Station, Sreenagar colony, Allapur, Borabanda",
            city: "Hyderabad",
            state: "Telangana",
            zipCode: "500018",
            country: "India",
            date: "28/05/2020",
            time: "10:00 AM",
            latitude: "16.505329",
            longitude: "80.661209",
          },
          {
            packageId: "",
            comapnyName: "Haril Logistics Private Limited",
            address:
              "Plot No 20, MMTS Railway Station, Sreenagar colony, Allapur, Borabanda,",
            city: "Hyderabad",
            state: "Telangana",
            zipCode: "500018",
            country: "India",
            date: "28/05/2020",
            time: "06:00 PM",
            latitude: "16.737509",
            longitude: "78.008125",
          },
        ],
      },
      {
        name: "Distributor",
        qrcodedate: "15/05/2020",
        packageId: "YP- U-MG-65758",
        qrcodeBatchId: "U-MGA-095422",
        locationDetails: [
          {
            packageId: "YP- U-MG-65758",
            comapnyName: "Agri Fram house",
            address: "National Highway 7, Zoo Park Main Road, Hasan Nagar",
            city: "Hyderabad,",
            state: "Telangana",
            zipCode: "500052",
            country: "India",
            date: "22/05/2020",
            time: " 05:00  PM",
            latitude: "17.385044",
            longitude: "78.486671",
          },
          {
            packageId: "",
            comapnyName: "Dodla Dairy",
            address:
              "Plot No 20, MMTS Railway Station, Sreenagar colony, Allapur, Borabanda",
            city: "Hyderabad",
            state: "Telangana",
            zipCode: "500018",
            country: "India",
            date: "28/05/2020",
            time: "10:00 AM",
            latitude: "16.505329",
            longitude: "80.661209",
          },
        ],
      },

      {
        name: "Manufacturer",
        qrcodedate: "15/05/2020",
        packageId: "YP- U-MG-65758",
        qrcodeBatchId: "U-MGA-095422",
        locationDetails: [
          {
            packageId: "YP- U-MG-65758",
            comapnyName: "Agri Fram house",
            address: "National Highway 7, Zoo Park Main Road, Hasan Nagar",
            city: "Hyderabad,",
            state: "Telangana",
            zipCode: "500052",
            country: "India",
            date: "22/05/2020",
            time: " 05:00  PM",
            latitude: "17.385044",
            longitude: "78.486671",
          },
          {
            packageId: "",
            comapnyName: "Dodla Dairy",
            address:
              "Plot No 20, MMTS Railway Station, Sreenagar colony, Allapur, Borabanda",
            city: "Hyderabad",
            state: "Telangana",
            zipCode: "500018",
            country: "India",
            date: "28/05/2020",
            time: "10:00 AM",
            latitude: "16.505329",
            longitude: "80.661209",
          },
        ],
      },
    ],
  };

  componentDidMount() {
    this.activeView("list");
  }

  modifyColums = (rowData, col) => {
    switch (col.field) {
      case "Actions":
        return (
          <span>
            <button
              className="btn action-button"
              onClick={(e) => this.viewDetails(e, rowData)}
            >
              <i className="fa fa-eye"></i>
            </button>
          </span>
        );

      default:
        return rowData[col.field];
    }
  };

  viewDetails = (e, rowData) => {
    let expandedRowId = {};
    if (rowData && isEmpty(this.state.expandedRowId)) {
      expandedRowId[`${rowData._id}`] = true;
    } else if (!isEmpty(this.state.expandedRowId)) {
      expandedRowId = null;
    }
    // console.log(rowData._id === expandedRowId[`${rowData._id}`]);
    this.setState({ expandedRowId });
  };

  /**list and map view function */
  activeView = (list) => {
    this.setState({ listView: list });
  };

  /**table data expression function */
  rowExpansionTemplate = (data) => {
    return (
      <div className="orders-subtable">
        <div class="accordian-body ">
          <div class="pro-qr-details">
            <div class="qr-block">
              <div class="text-muted">QR code date</div>
              <div class="text-dark">
                {this.state.productList[data._id - 1].qrcodedate}
              </div>
            </div>
            <div class="qr-block">
              <div class="text-muted">Package Id</div>
              <div class="text-dark">
                {this.state.productList[data._id - 1].packageId}
              </div>
            </div>
            <div class="qr-block">
              <div class="text-muted">QR code Batch ID</div>
              <div class="text-dark">
                {this.state.productList[data._id - 1].qrcodeBatchId}
              </div>
            </div>
            <div class="qr-block">
              <div class="text-muted">Current Loction</div>
              <div class="text-blue">
                {this.state.productList[data._id - 1].name}
              </div>
            </div>
          </div>
          <div class="counter-status-content">
            <div class="col col-lg-12 d-flex justify-content-end mt-2">
              <div
                class="btn-toolbar d-none d-md-block mb-1 btn-toggle"
                role="toolbar"
                aria-label="Toolbar with buttons"
              >
                <div class="btn-group btn-group-toggle" data-toggle="buttons">
                  <label
                    className={
                      this.state.listView === "list"
                        ? "btn btn-outline-secondary active"
                        : "btn btn-outline-secondary"
                    }
                    onClick={() => this.activeView("list")}
                  >
                    List view
                  </label>
                  <label
                    className={
                      this.state.listView === "map"
                        ? "btn btn-outline-secondary active"
                        : "btn btn-outline-secondary"
                    }
                    onClick={() => this.activeView("map")}
                  >
                    Map view
                  </label>
                </div>
              </div>
            </div>

            <div className="scan-timeline">
              {this.state.listView === "list" ? (
                <div className="row scrolling-wrapper flex-row flex-nowrap mb-1 pb-3">
                  {this.state.productList[data._id - 1].locationDetails.map(
                    (item, i) => (
                      <div className="col-md-6" key={i}>
                        <div className="uc-supplyflow">
                          <div
                            className={
                              item.packageId
                                ? "uc-supplyflow__item uc-supplyflow__item--active"
                                : "uc-supplyflow__item uc-supplyflow__item--deactive"
                            }
                          >
                            <div
                              className={
                                item.packageId
                                  ? "locate-txt-header disable"
                                  : "dup-locate-txt-header"
                              }
                            >
                              {item.packageId
                                ? `Original QR code Located at`
                                : ` Duplicate QR code Located at`}
                            </div>
                            <div className="uc-supplyflow__item-section">
                              <div className="uc-supplyflow__item-section-border">
                                <div className="uc-supplyflow__item-section-icon">
                                  <i className="fas fa-store uc-font-icon"></i>
                                </div>
                              </div>
                              <div className="uc-supplyflow__item-text">
                                <span className="font-weight-bolder">
                                  {item.comapnyName}
                                </span>
                                <div className="time-line-txt w-50">
                                  <address className="time-line-txt m-0">
                                    {`${item.address},${item.city},${item.state} ${item.zipCode},${item.country}.`}
                                  </address>
                                </div>
                                <div className="text-small">
                                  Scanned Date & time: :
                                  <date className="mr-1">
                                    &nbsp;{item.date}
                                  </date>
                                  <span className="text-muted">at&nbsp;</span>
                                  <span>{item.time}</span>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    )
                  )}
                </div>
              ) : this.state.listView === "map" ? (
                <div className="act-map-container">
                  <Gmap
                    style={{
                      position: "relative",
                      width: "100%",
                      height: "310px",
                    }}
                    // mapDetails={this.state.mapDetails}
                  />
                </div>
              ) : (
                ""
              )}
            </div>
          </div>
        </div>
      </div>
    );
  };

  render() {
    return (
      <div className="main-container">
        <Header name="Counterfeit Product/Package" />
        <div className="qr-content-container">
          <div className="uc-step-module">
            <div className="uc-step-module-top">
              <div className="custom-table counter-pro-content mt-1">
                <DataTable
                  respData={this.state.details}
                  column={this.state.column}
                  modifyColums={(rowData, col) =>
                    this.modifyColums(rowData, col)
                  }
                  expandedRowId={this.state.expandedRowId}
                  rowExpansionTemplate={(e) => this.rowExpansionTemplate(e)}
                />
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }
}

export default CounterfeitProduct;
