/** Import Depency modules */
import React, { Component } from "react";
import { withRouter, Link } from "react-router-dom";
import { connect } from "react-redux";
import SweetAlert from "react-bootstrap-sweetalert";

/** Import util components */
import isEmpty from "../../../utils/isEmpty";

/**Import qr actions */
import {
  changeAlertSuccessMessage,
  changeQRActiveTabs,
  changeAlertErrorMessage,
} from "../../../actions/qrAction";

/** Import Services */
import { qrCodeServices } from "../../../services/qrCodeServices";

import quantityList from "../common/quantityData.json";

class CreateQROrders extends Component {
  constructor() {
    super();
    this.state = {
      productType: "",
      productCategory: "",
      orderType: "Package",
      quantity: "",
      noOfPackages: "",
      minProductId: "",
      maxProductId: "",
      productIds: "",
      stickerSize: "",
      sizeMeasurement: "",
      productTypesList: [],
      productCategoriesList: [],
      errors: {},
      successpopup: {},
    };
  }

  componentDidMount() {
    this.getProductTypes();
  }

  // Get product types list
  getProductTypes = async () => {
    const productTypesList = await qrCodeServices.getProductTypes();
    if (!isEmpty(productTypesList)) {
      this.setState({ productTypesList });
    } else {
      this.setState({ errors: { productType: "Product types not found" } });
    }
  };

  // Get product catelogues list
  getProductCatelogues = async (productType) => {
    const productCategoriesList = await qrCodeServices.getProductCatelogues(
      productType
    );
    this.setState({ productCategoriesList });
  };

  //onChange action
  onChange = async (e) => {
    const { name, value } = e.target;

    this.setState({ [name]: value, errors: {} }, async () => {
      this.validateCreateOrderForm({ key: name });

      if (name === "productType" && !isEmpty(this.state.productType)) {
        await this.getProductCatelogues(this.state.productType);
      }

      if (!isEmpty(this.state.quantity) && !isEmpty(this.state.noOfPackages)) {
        const productsData = await qrCodeServices.getProductIdsRange(
          this.state.productType,
          this.state.productCategory,
          this.state.quantity * this.state.noOfPackages
        );

        if (!isEmpty(productsData)) {
          this.setState({
            minProductId: productsData.minProductId,
            maxProductId: productsData.maxProductId,
            productIds: productsData.productIds,
          });
        } else {
          this.setState({
            minProductId: "",
            maxProductId: "",
            productIds: [],
            errors: {
              minProductId:
                "Products not found with selected Quantity and No.of Packages",
            },
          });
        }
      }
    });
  };

  // Save new order
  saveOrder = async (e) => {
    e.preventDefault();
    // check form validations
    if (this.validateCreateOrderForm({ submitted: true })) {
      const formData = Object.assign({}, this.state);
      delete formData.productCategoriesList;
      delete formData.productTypesList;

      const saveResult = await qrCodeServices.saveOrder(formData);
      if (!isEmpty(saveResult) && saveResult.isError === false) {
        let successpopup = saveResult;
        this.setState({ successpopup });
      } else {
        let successpopup = saveResult;
        let errors = saveResult;
        this.setState({ errors, successpopup });
      }
    }
  };

  // return validations
  validateCreateOrderForm = ({ key = null, submitted = false }) => {
    const errors = {};

    const {
      productType,
      productCategory,
      quantity,
      noOfPackages,
      minProductId,
      maxProductId,
      stickerSize,
      sizeMeasurement,
    } = this.state;

    if (isEmpty(productType) && (key === "productType" || submitted)) {
      errors.productType = `Product type is required`;
    }

    if (isEmpty(productCategory) && (key === "productCategory" || submitted)) {
      errors.productCategory = `Product catalogue is required`;
    }

    if (isEmpty(quantity) && (key === "quantity" || submitted)) {
      errors.quantity = `Quantity type is required`;
    }

    if (isEmpty(noOfPackages) && (key === "noOfPackages" || submitted)) {
      errors.noOfPackages = `No.of packages is required`;
    } else if (
      parseInt(noOfPackages) < 1 &&
      (key === "noOfPackages" || submitted)
    ) {
      errors.noOfPackages = `Please enter minimum one value`;
    }

    if (isEmpty(minProductId) && (key === "minProductId" || submitted)) {
      errors.minProductId = `Min productId is required`;
    }

    if (isEmpty(maxProductId) && (key === "maxProductId" || submitted)) {
      errors.maxProductId = `Max productId is required`;
    }

    if (isEmpty(stickerSize) && (key === "stickerSize" || submitted)) {
      errors.stickerSize = `Sticker size is required`;
    }

    if (isEmpty(sizeMeasurement) && (key === "sizeMeasurement" || submitted)) {
      errors.sizeMeasurement = `Size Measurement is required`;
    }

    this.setState({ errors });

    return isEmpty(errors);
  };

  // Clear form data
  clearFormData = () => {
    const clearData = {
      productType: "",
      productCategory: "",
      orderType: "Package",
      quantity: "",
      noOfPackages: "",
      minProductId: "",
      maxProductId: "",
      productIds: "",
      stickerSize: "",
      sizeMeasurement: "",
      productCategoriesList: [],
      errors: {},
    };

    this.setState(clearData);
  };

  /**hide sweet alert popup */
  hideAlert = () => {
    if (!isEmpty(this.state.successpopup) && !this.state.successpopup.isError) {
      this.props.changeQRActiveTabs("Active");
    }
    this.setState({ successpopup: {} });
  };

  /**show sweet alert popup */
  getAlert = () => {
    if (!isEmpty(this.state.successpopup) && !this.state.successpopup.isError) {
      return (
        <SweetAlert
          success
          title="Success"
          onConfirm={() => this.hideAlert()}
          btnSize="md"
        >
          {this.state.successpopup.message}
        </SweetAlert>
      );
    } else if (
      !isEmpty(this.state.successpopup) &&
      this.state.successpopup.isError
    ) {
      return (
        <SweetAlert
          error
          title="Error"
          onConfirm={() => this.hideAlert()}
          btnSize="md"
        >
          {this.state.successpopup.message}
        </SweetAlert>
      );
    }
  };

  render() {
    const { errors } = this.state;
    const stickerSizes = this.state.stickerSize.split("X");

    const returnproductTypes = this.state.productTypesList.map(
      (product, idx) => (
        <option value={product._id} key={idx}>
          {product._id}
        </option>
      )
    );

    const returnProductCategories = this.state.productCategoriesList.map(
      (cat, idx) => (
        <option value={cat._id} key={idx}>
          {cat._id}
        </option>
      )
    );

    const returnQuantityList = quantityList.data.map((number, idx) => (
      <option value={number} key={idx}>
        {number}
      </option>
    ));

    const activeTab = this.props.qrOrder.qrTab;

    return (
      <div
        className={
          !isEmpty(activeTab) && activeTab === "Create"
            ? "tab-pane fade show active"
            : "tab-pane fade show"
        }
        id="pills-qr"
        role="tabpanel"
        aria-labelledby="pills-qr-tab"
      >
        {/* sweet alert popup */}
        {!isEmpty(this.state.successpopup) ? this.getAlert() : ""}
        {/* End sweet alert popup */}
        <div className="row">
          <div className="col-4 col-md-4">
            <div className="qr-content">
              <div className="row">
                <div className="col-md-12">
                  <div className="form-row">
                    <div className="form-group col-md-12">
                      <label htmlFor="Company Name" className="col-form-label">
                        Type of product<span className="astric">*</span>
                      </label>
                      <select
                        id="inputState"
                        className="form-control"
                        name="productType"
                        onChange={this.onChange}
                        value={this.state.productType}
                      >
                        <option value="">Select the type</option>
                        {returnproductTypes}
                      </select>
                      {errors && (
                        <p className="text-danger text-small">
                          {errors.productType}
                        </p>
                      )}
                    </div>
                  </div>
                </div>
              </div>
              <div className="row">
                <div className="col-md-12">
                  <div className="form-row">
                    <div className="form-group col-md-12">
                      <label htmlFor="Company Name" className="col-form-label">
                        Product catalogue<span className="astric">*</span>
                      </label>
                      <select
                        id="inputState"
                        className="form-control"
                        name="productCategory"
                        onChange={this.onChange}
                        value={this.state.productCategory}
                      >
                        <option value="">Select a product</option>
                        {returnProductCategories}
                      </select>
                      {errors && (
                        <p className="text-danger text-small">
                          {errors.productCategory}
                        </p>
                      )}
                    </div>
                  </div>
                </div>
              </div>
              <hr className="my-1" />
              <div className="row">
                <div className="col-md-12">
                  <div className="form-row">
                    <div className="form-group col-md-6">
                      <label
                        htmlFor="Package Quantity"
                        className="col-form-label"
                      >
                        Package Quantity<span className="astric">*</span>
                      </label>
                      <select
                        id="inputState"
                        className="form-control"
                        name="quantity"
                        onChange={this.onChange}
                        value={this.state.quantity}
                      >
                        <option value="">Select</option>
                        {returnQuantityList}
                      </select>
                    </div>
                    <div className="form-group col-md-6">
                      <label htmlFor="Role" className="col-form-label">
                        Number of Package<span className="astric">*</span>
                      </label>
                      <input
                        type="text"
                        className="form-control"
                        placeholder="Package"
                        type="number"
                        name="noOfPackages"
                        onChange={this.onChange}
                        value={this.state.noOfPackages}
                      />
                    </div>
                  </div>
                  {errors && (
                    <p className="text-danger text-small">
                      {errors.quantity ? errors.quantity : ""}
                      {errors.noOfPackages ? errors.noOfPackages : ""}
                    </p>
                  )}
                </div>
              </div>
              <hr className="my-1" />
              <div className="row">
                <div className="col-md-12 form-m-group">
                  <label htmlFor="Package Quantity" className="col-form-label">
                    Product ID range<span className="astric">*</span>
                  </label>
                  <div className="form-row">
                    <div className="form-group col-md-6">
                      <input
                        type="text"
                        className="form-control"
                        placeholder="Min"
                        name="minProductId"
                        onChange={this.onChange}
                        value={this.state.minProductId}
                      />
                    </div>
                    <div className="form-group col-md-6">
                      <input
                        type="text"
                        className="form-control"
                        placeholder="Max"
                        name="maxProductId"
                        onChange={this.onChange}
                        value={this.state.maxProductId}
                      />
                    </div>
                  </div>
                  {errors && (
                    <p className="text-danger text-small">
                      {errors.minProductId ? errors.minProductId : ""}
                      {errors.maxProductId ? errors.maxProductId : ""}
                    </p>
                  )}
                </div>
              </div>
              <hr className="my-1" />
              <div className="row">
                <div className="col-md-12 form-m-group">
                  <label htmlFor="Package Quantity" className="col-form-label">
                    QR code sticker Size<span className="astric">*</span>
                  </label>
                  <div className="form-row">
                    <div className="form-group col-md-6">
                      <select
                        id="inputState"
                        className="form-control"
                        name="stickerSize"
                        onChange={this.onChange}
                        value={this.state.stickerSize}
                      >
                        <option value="">Select</option>
                        <option value="1X1">1X1</option>
                        <option value="2X2">2X2</option>
                        <option value="3X3">3X3</option>
                        <option value="4X4">4X4</option>
                        <option value="5X5">5X5</option>
                      </select>
                    </div>
                    <div className="form-group col-md-6">
                      <select
                        id="inputState"
                        className="form-control"
                        name="sizeMeasurement"
                        onChange={this.onChange}
                        value={this.state.sizeMeasurement}
                      >
                        <option value="">Select</option>
                        <option value="CM">CM</option>
                      </select>
                    </div>
                  </div>

                  {errors && (
                    <p className="text-danger text-small">
                      {errors.stickerSize ? errors.stickerSize : ""}
                      {errors.sizeMeasurement ? errors.sizeMeasurement : ""}
                    </p>
                  )}
                </div>
              </div>
              <hr className="my-1" />
              <div className="row">
                <div className="col-md-12">
                  <div className="form-check">
                    <input
                      className="form-check-input"
                      type="checkbox"
                      defaultValue
                      id="Check1"
                    />
                    <label className="form-check-label h6" htmlFor="Check1">
                      Add your logo company on the QR sticker
                    </label>
                  </div>
                </div>
              </div>
              <hr className="my-1" />
            </div>
          </div>
          {!isEmpty(this.state.productType) ? (
            <div className="col-md-8">
              <div className="qr-content">
                <div className="text-small"> Order Summary </div>
                <hr className="my-1" />
                <div className="row">
                  <div className="col-md-6">
                    {this.state.productType ? (
                      <div>
                        <div className="text-small">Type of product </div>
                        <div className="q-sub-text">
                          {this.state.productType}
                        </div>
                        <hr className="my-2" />
                      </div>
                    ) : (
                      ""
                    )}
                    {this.state.productCategory ? (
                      <div>
                        <div className="text-small">Product name</div>
                        <div className="q-sub-text">
                          {this.state.productCategory}
                        </div>
                        <hr className="my-2" />
                      </div>
                    ) : (
                      ""
                    )}
                    {this.state.quantity ? (
                      <div>
                        <div className="text-small">Package Quantity</div>
                        <div className="q-sub-text">{this.state.quantity}</div>
                        <hr className="my-2" />
                      </div>
                    ) : (
                      ""
                    )}
                    {this.state.noOfPackages ? (
                      <div>
                        <div className="text-small">Number of Package </div>
                        <div className="q-sub-text">
                          {this.state.noOfPackages}
                        </div>
                        <hr className="my-2" />
                      </div>
                    ) : (
                      ""
                    )}
                    {this.state.minProductId ? (
                      <div>
                        <div className="text-small">Product Id Range </div>
                        <div className="q-sub-text">
                          {this.state.minProductId} - {this.state.maxProductId}
                        </div>
                        <hr className="my-2" />
                      </div>
                    ) : (
                      ""
                    )}
                    {this.state.stickerSize ? (
                      <div>
                        <div className="text-small">QR code sticker Size </div>
                        <div className="q-sub-text">
                          {this.state.stickerSize} {this.state.sizeMeasurement}
                        </div>
                        <hr className="my-2" />
                      </div>
                    ) : (
                      ""
                    )}
                  </div>
                  {this.state.stickerSize && this.state.sizeMeasurement ? (
                    <div className="col-md-6">
                      <div className="p-box mb-4">
                        <img src="assets/img/Product.png" />
                        <div>Product Package box</div>
                      </div>
                      <div className="p-qr-bkp" style={{ textAlign: "center" }}>
                        <img
                          src="assets/img/qr-code.png"
                          width={stickerSizes[0] * 37.79}
                          height={stickerSizes[1] * 37.79}
                        />
                        <div>QR code perview</div>
                      </div>
                    </div>
                  ) : (
                    ""
                  )}
                </div>
                {this.state.productType &&
                this.state.productCategory &&
                this.state.quantity &&
                this.state.noOfPackages &&
                this.state.minProductId &&
                this.state.maxProductId &&
                this.state.stickerSize &&
                this.state.sizeMeasurement ? (
                  <div className="row">
                    <div className="col-md-12">
                      <div className="qr-bottom-btn">
                        <button
                          type="button"
                          className="btn btn-primary-ghost px-3 mr-2"
                          data-toggle="modal"
                          data-target="#modal_01"
                          onClick={this.clearFormData}
                        >
                          Cancel
                        </button>
                        <button
                          type="button"
                          className="btn btn-primary px-2"
                          data-toggle="modal"
                          data-target="#modal_02"
                          onClick={this.saveOrder}
                        >
                          Confirm
                        </button>
                      </div>
                    </div>
                  </div>
                ) : (
                  ""
                )}
              </div>
            </div>
          ) : (
            <div className="col-md-8">
              <div className="qr-content">
                <div className="empty-qr-screen">
                  {/* <svg className="manage-nav-icon">
                  <use xlinkHref="assets/img/up-sprite.svg#onboard" />
                </svg> */}
                  <p>To Create a QR code Order,Click on the Type of Product</p>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    );
  }
}

const mapStateToProps = (state) => ({
  qrOrder: state.qrOrder,
});

export default connect(mapStateToProps, {
  changeAlertSuccessMessage,
  changeQRActiveTabs,
  changeAlertErrorMessage,
})(withRouter(CreateQROrders));
