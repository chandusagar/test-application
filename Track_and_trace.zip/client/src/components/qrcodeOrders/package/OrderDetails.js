/** Import Depency modules */
import React, { Component } from "react";
import { withRouter, Link } from "react-router-dom";
import { connect } from "react-redux";
import Moment from "moment";
import SweetAlert from "react-bootstrap-sweetalert";

import Gmap from "../../common/Gmap";

/** Import Services */
import { qrCodeServices } from "../../../services/qrCodeServices";

/** Import Components */
import CancelOrderModal from "../common/CancelOrderModal";

/** Import Util files */
import isEmpty from "../../../utils/isEmpty";

/**Import qr actions */
import {
  changeAlertSuccessMessage,
  changeAlertErrorMessage,
} from "../../../actions/qrAction";

class OrderDetails extends Component {
  constructor() {
    super();
    this.state = {
      details: {},
      manufacturerDetails: {},
      supplierDetails: [],
      showCancelOrderModal: false,
      mapDetails: [],
      successpopup: {},
    };
  }

  componentDidMount() {
    this.getOrderDetails();
  }

  componentDidUpdate(prevProps) {
    if (
      prevProps.qrOrder.alertSuccessMessage !==
      this.props.qrOrder.alertSuccessMessage
    ) {
      this.setState({
        alertSuccessMessage: this.props.qrOrder.alertSuccessMessage,
      });
    }

    if (
      prevProps.qrOrder.alertErrorMessage !==
      this.props.qrOrder.alertErrorMessage
    ) {
      this.setState({
        alertErrorMessage: this.props.qrOrder.alertErrorMessage,
      });
    }
  }

  // Get list of orders
  getOrderDetails = async () => {
    const orderDetails = await qrCodeServices.getOrderDetails(
      this.props.match.params.orderId
    );

    const details = orderDetails.Order ? orderDetails.Order : {};

    const manufacturerDetails = orderDetails.Manufacturer
      ? orderDetails.Manufacturer.basicDetails
      : {};

    const supplierDetails =
      orderDetails.Supplier.length > 0 ? orderDetails.Supplier : [];
    let mapDetails = JSON.parse(JSON.stringify(this.state.mapDetails));

    supplierDetails.forEach((item, i) => {
      console.log(item.basicDetails, i);
      let obj = {
        lat: Number(item.basicDetails.latitude),
        lng: Number(item.basicDetails.longitude),
        label: "S",
        address: item.basicDetails,
      };
      mapDetails.push(obj, {
        lat: Number(manufacturerDetails.latitude),
        lng: Number(manufacturerDetails.longitude),
        label: "M",
        address: manufacturerDetails,
      });
    });

    console.log(mapDetails, manufacturerDetails);
    this.setState({
      details,
      manufacturerDetails,
      supplierDetails,
      mapDetails,
    });
  };

  // Open cancel order modal popup
  openCancelOrderModal = () => {
    this.setState({ showCancelOrderModal: true });
  };

  // Close cancel order modal popup
  closeCancelOrderModal = () => {
    this.setState({ showCancelOrderModal: false });
  };

  // Activate qr codes
  activateQrcodes = async () => {
    const saveResult = await qrCodeServices.activateQrCodes(
      this.props.match.params.orderId
    );

    if (!isEmpty(saveResult) && saveResult.isError === false) {
      let successpopup = saveResult;
      this.setState({ successpopup });
    } else {
      let successpopup = saveResult;
      let errors = saveResult;
      this.setState({ errors, successpopup });
    }
  };

  // Navigate to orders list page
  navigationToBackPage = () => {
    this.props.history.push("/packageqrcodeorders");
  };

  /**hide sweet alert popup */
  hideAlert = () => {
    if (!isEmpty(this.state.successpopup) && !this.state.successpopup.isError) {
      this.props.history.push("/packageqrcodeorders");
    }
    this.setState({ successpopup: {} });
  };

  /**show sweet alert popup */
  getAlert = () => {
    if (!isEmpty(this.state.successpopup) && !this.state.successpopup.isError) {
      return (
        <SweetAlert
          success
          title="Success"
          onConfirm={() => this.hideAlert()}
          btnSize="md"
        >
          {this.state.successpopup.message}
        </SweetAlert>
      );
    } else if (
      !isEmpty(this.state.successpopup) &&
      this.state.successpopup.isError
    ) {
      return (
        <SweetAlert
          error
          title="Error"
          onConfirm={() => this.hideAlert()}
          btnSize="md"
        >
          {this.state.successpopup.message}
        </SweetAlert>
      );
    }
  };

  render() {
    const succes = {
      paddingLeft: "35%",
      paddingRight: "36%",
    };

    let displayData = <div></div>;

    if (!isEmpty(this.state.supplierDetails)) {
      displayData = this.state.supplierDetails.map((supplier, index) => (
        <div className="card-body ">
          <div className="title-header">
            <h6 className="title-bg">Supplier_{index + 1} Details</h6>
          </div>
          <div className="text-small">Supplier Type</div>
          <div className="sub-text">
            {supplier.basicDetails.type ? supplier.basicDetails.type : ""}
          </div>
          <hr className="my-1" />
          <div className="text-small">Supplier Name</div>
          <div className="sub-text">
            {supplier.basicDetails.name ? supplier.basicDetails.name : ""}
          </div>
          <hr className="my-1" />
          <div className="text-small">Email id</div>
          <div className="sub-text">
            {supplier.basicDetails.emailId ? supplier.basicDetails.emailId : ""}
          </div>
          <hr className="my-1" />
          <div className="text-small">Phone / Mobile Number</div>
          <div className="sub-text">
            {supplier.basicDetails.phoneNo ? supplier.basicDetails.phoneNo : ""}
          </div>
          <hr className="my-1" />
          <div className="text-small">Supplier Address</div>
          <div className="sub-text">
            <p>
              {supplier.basicDetails.address
                ? supplier.basicDetails.address
                : ""}{" "}
              {supplier.basicDetails.city
                ? `, ${supplier.basicDetails.city}`
                : ""}{" "}
              {supplier.basicDetails.state
                ? `, ${supplier.basicDetails.state}`
                : ""}{" "}
              {supplier.basicDetails.zipCode
                ? ` - ${supplier.basicDetails.zipCode}`
                : ""}
              {supplier.basicDetails.country
                ? `, ${supplier.basicDetails.country}.`
                : ""}{" "}
            </p>
          </div>
        </div>
      ));
    } else {
      displayData = "Suppliers are not linked for these products";
    }

    return (
      <div>
        {/* sweet alert popup */}
        {!isEmpty(this.state.successpopup) ? this.getAlert() : ""}
        {/* End sweet alert popup */}
        {!isEmpty(this.state.alertSuccessMessage) ? (
          <div className="alert alert-success bg-success text-white alert-dismissible success_popup">
            <button type="button" className="close">
              &times;
            </button>
            <div className="text-center" style={succes}>
              {this.state.alertSuccessMessage}
            </div>
          </div>
        ) : !isEmpty(this.state.alertErrorMessage) ? (
          <div className="alert alert-danger bg-danger text-white alert-dismissible success_popup">
            <button type="button" className="close">
              &times;
            </button>
            <div className="text-center" style={succes}>
              {this.state.alertErrorMessage}
            </div>
          </div>
        ) : (
          ""
        )}

        <div className="layout active-qr-code-layout ">
          <div className="container-fluid">
            <div className="qr-act-header">
              <div className="l-act-content">
                {this.state.details.orderStatus === "Available"
                  ? "Activative QR codes"
                  : "QR Codes Generated - Details"}
              </div>
              <div className="r-act-content">
                {this.state.details.orderStatus === "Available" ? (
                  <div>
                    <button
                      type="button"
                      className="btn btn-primary-ghost px-3 mr-2"
                      // data-toggle="modal"
                      // data-target="#modal_01"
                      onClick={this.openCancelOrderModal}
                    >
                      Cancel
                    </button>

                    <button
                      type="button"
                      className="btn btn-primary px-2"
                      onClick={this.activateQrcodes}
                    >
                      Generate QR codes{" "}
                    </button>
                  </div>
                ) : (
                  ""
                  // <button
                  //   type="button"
                  //   className="btn btn-primary-ghost px-3 mr-2"
                  //   onClick={this.navigationToBackPage}
                  // >
                  //   Back
                  // </button>
                )}
              </div>
            </div>
            <div className="act-header-title mt-2">
              <span>Summary : </span>
              <span>Order Number</span>
              <span>- {this.state.details._id}</span>
            </div>
            <div className="row mt-2">
              <div className="col-md-6">
                <div className="text-small d-flex">
                  <span className="text-dark w-2">Type of product :</span>
                  <span>
                    {this.state.details.productType
                      ? this.state.details.productType
                      : ""}
                  </span>
                </div>
                <hr className="my-1" />
                <div className="text-small d-flex">
                  <span className="text-dark w-2">Type of QR codes :</span>
                  <span>
                    {this.state.details.orderType
                      ? this.state.details.orderType
                      : ""}
                  </span>
                </div>
                <hr className="my-1" />
                <div className="text-small d-flex">
                  <span className="text-dark w-2">Product ID range :</span>
                  <span>
                    {this.state.details.minProductId
                      ? this.state.details.minProductId
                      : ""}{" "}
                    -{" "}
                    {this.state.details.maxProductId
                      ? this.state.details.maxProductId
                      : ""}
                  </span>
                </div>
                <hr className="my-1" />
                <div className="text-small d-flex">
                  <span className="text-dark w-2">Package Quantity:</span>
                  <span>
                    {this.state.details.quantity
                      ? this.state.details.quantity
                      : ""}
                  </span>
                </div>
                <hr className="my-1" />
                <div className="text-small d-flex">
                  <span className="text-dark w-2">Number of Package:</span>
                  <span>
                    {this.state.details.noOfPackages
                      ? this.state.details.noOfPackages
                      : ""}
                  </span>
                </div>
                <hr className="my-1" />
                {this.state.details.orderStatus === "Active" ? (
                  <div>
                    <div className="text-small d-flex">
                      <span className="text-dark w-2">Order on:</span>
                      <span>
                        {this.state.details.created
                          ? Moment(this.state.details.created).format(
                              "MM/DD/YYYY"
                            )
                          : ""}
                      </span>
                    </div>
                    <hr className="my-1" />
                    <div className="text-small d-flex">
                      <span className="text-dark w-2">Order created by:</span>
                      <span>
                        {this.state.details.createdBy
                          ? this.state.details.createdBy.firstName
                          : ""}{" "}
                        {this.state.details.createdBy
                          ? this.state.details.createdBy.lastName
                          : ""}
                      </span>
                    </div>
                    <hr className="my-1" />
                    <div className="text-small d-flex">
                      <span className="text-dark w-2">Activated on:</span>
                      <span>
                        {this.state.details.qrCodesGeneratedAt
                          ? Moment(
                              this.state.details.qrCodesGeneratedAt
                            ).format("MM/DD/YYYY")
                          : ""}
                      </span>
                    </div>
                    <hr className="my-1" />
                    <div className="text-small d-flex">
                      <span className="text-dark w-2">Activated by:</span>
                      <span>
                        {this.state.details.activatedBy
                          ? this.state.details.activatedBy.firstName
                          : ""}{" "}
                        {this.state.details.activatedBy
                          ? this.state.details.activatedBy.lastName
                          : ""}
                      </span>
                    </div>
                    <hr className="my-1" />
                    <div className="text-small d-flex">
                      <span className="text-dark w-2">Generated on:</span>
                      <span>
                        {this.state.details.qrCodesGeneratedAt
                          ? Moment(
                              this.state.details.qrCodesGeneratedAt
                            ).format("MM/DD/YYYY")
                          : ""}
                      </span>
                    </div>
                    <hr className="my-1" />
                    <div className="text-small d-flex">
                      <span className="text-dark w-2">Delivery status:</span>
                      <span>{""}</span>
                    </div>
                    <hr className="my-1" />
                    <div className="text-small d-flex">
                      <span className="text-dark w-2">Delivery to:</span>
                      <span>{""}</span>
                    </div>
                    <hr className="my-1" />
                  </div>
                ) : (
                  ""
                )}
              </div>
              <div className="col-md-3 p-box">
                {" "}
                <img src="/assets/img/Product.png" />
                <div>Product Package box</div>{" "}
              </div>
              <div
                className="col-md-3 p-qr-bkp"
                style={{ textAlign: "center" }}
              >
                {" "}
                <img
                  src="/assets/img/qr-code.png"
                  width={
                    !isEmpty(this.state.details.stickerSize)
                      ? this.state.details.stickerSize.split("X")[0] * 37.79
                      : ""
                  }
                  height={
                    !isEmpty(this.state.details.stickerSize)
                      ? this.state.details.stickerSize.split("X")[1] * 37.79
                      : ""
                  }
                />
                <div>QR code perview</div>{" "}
              </div>
            </div>
            <div className="act-header-title mt-2">
              <span>
                Supplier &amp; Manufacturer Details of the above Product
              </span>
            </div>
            <div className="text-small mt-2">
              <p>
                If your find any discrepancy in the Supplier or Manufacturer
                Details , You can rise a ticket to our support team, by clicking
                this link : <a href="#">Rise a issue</a>{" "}
              </p>
            </div>
            <div className="row mt-2">
              <div className="col-12 col-lg-6 col-xl-3 ">
                <div className="card flex-fill w-100">
                  <div className="card-header d-flex">
                    <h6 className="card-title mb-0">Supplier Details</h6>
                  </div>
                  <div
                    className={
                      this.state.supplierDetails.length > 1 ? "m-content" : ""
                    }
                  >
                    {displayData}
                  </div>
                </div>
              </div>
              <div className="col-12 col-lg-6 col-xl-3">
                <div className="card flex-fill w-100">
                  <div className="card-header d-flex">
                    <h6 className="card-title mb-0">Manufacturer Details</h6>
                  </div>
                  <div className="card-body">
                    <div className="text-small">Manufacturer Type</div>
                    <div className="sub-text">
                      {this.state.manufacturerDetails.type
                        ? this.state.manufacturerDetails.type
                        : ""}
                    </div>
                    <hr className="my-1" />
                    <div className="text-small">Manufacturer Name</div>
                    <div className="sub-text">
                      {this.state.manufacturerDetails.name
                        ? this.state.manufacturerDetails.name
                        : ""}
                    </div>
                    <hr className="my-1" />
                    <div className="text-small">Email id</div>
                    <div className="sub-text">
                      {this.state.manufacturerDetails.emailId
                        ? this.state.manufacturerDetails.emailId
                        : ""}
                    </div>
                    <hr className="my-1" />
                    <div className="text-small">Phone / Mobile Number</div>
                    <div className="sub-text">
                      {this.state.manufacturerDetails.phoneNo
                        ? this.state.manufacturerDetails.phoneNo
                        : ""}
                    </div>
                    <hr className="my-1" />
                    <div className="text-small">Manufacturer Address</div>
                    <div className="sub-text">
                      <p>
                        {this.state.manufacturerDetails.address
                          ? this.state.manufacturerDetails.address
                          : ""}{" "}
                        {this.state.manufacturerDetails.city
                          ? `, ${this.state.manufacturerDetails.city}`
                          : ""}{" "}
                        {this.state.manufacturerDetails.state
                          ? `, ${this.state.manufacturerDetails.state}`
                          : ""}{" "}
                        {this.state.manufacturerDetails.zipCode
                          ? ` - ${this.state.manufacturerDetails.zipCode}`
                          : ""}
                        {this.state.manufacturerDetails.country
                          ? `, ${this.state.manufacturerDetails.country}.`
                          : ""}{" "}
                      </p>
                    </div>
                  </div>
                </div>
              </div>
              <div className="col-12 col-lg-6 col-xl-6">
                <div className="act-map-container">
                  <Gmap
                    style={{
                      position: "relative",
                      width: "100%",
                      height: "310px",
                    }}
                    mapDetails={this.state.mapDetails}
                  />
                </div>
              </div>
            </div>
          </div>
        </div>

        {this.state.showCancelOrderModal ? (
          <CancelOrderModal
            show={this.state.showCancelOrderModal}
            onClose={this.closeCancelOrderModal}
            cancelUrlFrom="Package"
            orderId={this.props.match.params.orderId}
          />
        ) : (
          ""
        )}
      </div>
    );
  }
}

const mapStateToProps = (state) => ({
  qrOrder: state.qrOrder,
});

export default connect(mapStateToProps, {
  changeAlertSuccessMessage,
  changeAlertErrorMessage,
})(withRouter(OrderDetails));
