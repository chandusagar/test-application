/** Import Depency modules */
import React, { Component } from "react";
import { withRouter, Link } from "react-router-dom";
import { connect } from "react-redux";

/** Import Components */
import HeaderText from "../common/HeaderText";
import CustomTabs from "../common/CustomTabs";
import CreateQROrders from "../package/CreateQROrders";
import ActivateQRCodes from "../package/ActivateQRCodes";
import DeliverQRCodes from "../package/DeliverQRCodes";
import MyOrderHistory from "../package/MyOrderHistory";

/** Import util components */
import isEmpty from "../../../utils/isEmpty";

class PackageQRCodeorders extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      alertSuccessMessage: "",
      alertErrorMessage: "",
    };
  }

  componentDidUpdate(prevProps) {
    if (
      prevProps.qrOrder.alertSuccessMessage !==
      this.props.qrOrder.alertSuccessMessage
    ) {
      this.setState({
        alertSuccessMessage: this.props.qrOrder.alertSuccessMessage,
      });
    }

    if (
      prevProps.qrOrder.alertErrorMessage !==
      this.props.qrOrder.alertErrorMessage
    ) {
      this.setState({
        alertErrorMessage: this.props.qrOrder.alertErrorMessage,
      });
    }
  }

  render() {
    const succes = {
      paddingLeft: "35%",
      paddingRight: "36%",
    };

    const activeTab = this.props.qrOrder.qrTab;

    return (
      <div>
        <HeaderText textName="Package QR Code" />

        <div className="qr-content-container">
          <div className="uc-step-module">
            <div className="uc-step-module-top">
              {!isEmpty(this.state.alertSuccessMessage) ? (
                <div className="alert alert-success bg-success text-white alert-dismissible success_popup">
                  <button type="button" className="close">
                    &times;
                  </button>
                  <div className="text-center" style={succes}>
                    {this.state.alertSuccessMessage}
                  </div>
                </div>
              ) : !isEmpty(this.state.alertErrorMessage) ? (
                <div className="alert alert-danger bg-danger text-white alert-dismissible success_popup">
                  <button type="button" className="close">
                    &times;
                  </button>
                  <div className="text-center" style={succes}>
                    {this.state.alertErrorMessage}
                  </div>
                </div>
              ) : (
                ""
              )}

              <CustomTabs />

              <hr className="m-0" />
              <div className="tab-content" id="pills-tabContent">
                {activeTab === "Create" ? (
                  <CreateQROrders />
                ) : activeTab === "Active" ? (
                  <ActivateQRCodes />
                ) : activeTab === "Deliver" ? (
                  <DeliverQRCodes />
                ) : activeTab === "History" ? (
                  <MyOrderHistory />
                ) : (
                  ""
                )}
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }
}

const mapStateToProps = (state) => ({
  qrOrder: state.qrOrder,
});

export default connect(mapStateToProps, {})(withRouter(PackageQRCodeorders));
