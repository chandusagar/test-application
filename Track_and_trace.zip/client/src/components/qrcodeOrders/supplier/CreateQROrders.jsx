/** Import Depency modules */
import React, { Component } from "react";
import { withRouter, Link } from "react-router-dom";
import { connect } from "react-redux";
import SweetAlert from "react-bootstrap-sweetalert";

/** Import util components */
import isEmpty from "../../../utils/isEmpty";

/** Import Services */
import { qrCodeServices } from "../../../services/qrCodeServices";
/**Import qr actions */
import {
  changeAlertSuccessMessage,
  changeQRActiveTabs,
  changeAlertErrorMessage,
} from "../../../actions/qrAction";

import quantityList from "../common/quantityData.json";

class CreateQROrders extends Component {
  constructor() {
    super();
    this.state = {
      supplierMailId: "",
      rawMaterial: "",
      quantity: "",
      noOfPackages: "",
      minRawMaterialId: "",
      maxRawMaterialId: "",
      rawMaterialIds: "",
      stickerSize: "",
      sizeMeasurement: "",
      suppliersList: [],
      rawMaterialsLIst: [],
      errors: {},
      successpopup: {},
    };
  }

  componentDidMount() {
    this.getSuppliers();
  }

  // Get suppliers list
  getSuppliers = async () => {
    const suppliersList = await qrCodeServices.getSuppliers();
    if (!isEmpty(suppliersList)) {
      this.setState({ suppliersList });
    } else {
      this.setState({
        errors: {
          supplierMailId: "Suppliers not found. Please create Supplier",
        },
      });
    }
  };

  // Get supplier raw materials list
  getSupplierRawMaterials = async (supplierMailId) => {
    const rawMaterialsLIst = await qrCodeServices.getSupplierRawMaterials(
      supplierMailId
    );

    if (!isEmpty(rawMaterialsLIst)) {
      this.setState({ rawMaterialsLIst });
    } else {
      this.setState({
        rawMaterial: "",
        rawMaterialsLIst: [],
        errors: {
          rawMaterial: "Raw Materials not found with selected Supplier",
        },
      });
    }
  };

  //onChange action
  onChange = async (e) => {
    const { name, value } = e.target;

    this.setState({ [name]: value, errors: {} }, async () => {
      this.validateCreateOrderForm({ key: name });

      if (name === "supplierMailId" && !isEmpty(this.state.supplierMailId)) {
        this.getSupplierRawMaterials(this.state.supplierMailId);
        const supplier = this.state.suppliersList.find(
          (supplier) =>
            supplier.basicDetails.emailId === this.state.supplierMailId
        );
        this.setState({ supplierDetails: supplier.basicDetails });
      }

      if (!isEmpty(this.state.quantity) && !isEmpty(this.state.noOfPackages)) {
        const rawMaterialsData = await qrCodeServices.getRawMaterialsRange(
          this.state.quantity * this.state.noOfPackages,
          this.state.supplierMailId,
          this.state.rawMaterial
        );

        if (!isEmpty(rawMaterialsData)) {
          this.setState({
            minRawMaterialId: rawMaterialsData.minRawMaterialId,
            maxRawMaterialId: rawMaterialsData.maxRawMaterialId,
            rawMaterialIds: rawMaterialsData.rawMaterialIds,
          });
        } else {
          this.setState({
            minRawMaterialId: "",
            maxRawMaterialId: "",
            rawMaterialIds: [],
            errors: {
              minRawMaterialId:
                "Raw Materials not found with selected Quantity and No.of Packages",
            },
          });
        }
      }
    });
  };

  // Save new supplier order
  saveOrder = async (e) => {
    e.preventDefault();
    // check form validations
    if (this.validateCreateOrderForm({ submitted: true })) {
      const formData = Object.assign({}, this.state);

      const saveResult = await qrCodeServices.saveSupplierOrder(formData);
      if (!isEmpty(saveResult) && saveResult.isError === false) {
        let successpopup = saveResult;
        this.setState({ successpopup });
      } else {
        let successpopup = saveResult;
        let errors = saveResult;
        this.setState({ errors, successpopup });
      }
    }
  };

  // return validations
  validateCreateOrderForm = ({ key = null, submitted = false }) => {
    const errors = {};

    const {
      supplierMailId,
      rawMaterial,
      quantity,
      noOfPackages,
      minRawMaterialId,
      maxRawMaterialId,
      stickerSize,
      sizeMeasurement,
    } = this.state;

    if (isEmpty(supplierMailId) && (key === "supplierMailId" || submitted)) {
      errors.supplierMailId = `Supplier Details required`;
    }
    if (isEmpty(rawMaterial) && (key === "rawMaterial" || submitted)) {
      errors.rawMaterial = `Raw Material required`;
    }

    if (isEmpty(quantity) && (key === "quantity" || submitted)) {
      errors.quantity = `Quantity type is required`;
    }

    if (isEmpty(noOfPackages) && (key === "noOfPackages" || submitted)) {
      errors.noOfPackages = `No.of packages is required`;
    } else if (
      parseInt(noOfPackages) < 1 &&
      (key === "noOfPackages" || submitted)
    ) {
      errors.noOfPackages = `Please enter minimum one value`;
    }

    if (
      isEmpty(minRawMaterialId) &&
      (key === "minRawMaterialId" || submitted)
    ) {
      errors.minRawMaterialId = `Min raw material Id is required`;
    }

    if (
      isEmpty(maxRawMaterialId) &&
      (key === "maxRawMaterialId" || submitted)
    ) {
      errors.maxRawMaterialId = `Max raw materil Id is required`;
    }

    if (isEmpty(stickerSize) && (key === "stickerSize" || submitted)) {
      errors.stickerSize = `Sticker size is required`;
    }

    if (isEmpty(sizeMeasurement) && (key === "sizeMeasurement" || submitted)) {
      errors.sizeMeasurement = `Size Measurement is required`;
    }

    this.setState({ errors });

    return isEmpty(errors);
  };

  // Clear form data
  clearFormData = () => {
    const clearData = {
      supplierMailId: "",
      rawMaterial: "",
      quantity: "",
      noOfPackages: "",
      minRawMaterialId: "",
      maxRawMaterialId: "",
      rawMaterialIds: "",
      stickerSize: "",
      sizeMeasurement: "",
      rawMaterialsLIst: [],
      errors: {},
    };

    this.setState(clearData);
  };

  /**hide sweet alert popup */
  hideAlert = () => {
    if (!isEmpty(this.state.successpopup) && !this.state.successpopup.isError) {
      this.props.changeQRActiveTabs("Active");
    }
    this.setState({ successpopup: {} });
  };

  /**show sweet alert popup */
  getAlert = () => {
    if (!isEmpty(this.state.successpopup) && !this.state.successpopup.isError) {
      return (
        <SweetAlert
          success
          title="Success"
          onConfirm={() => this.hideAlert()}
          btnSize="md"
        >
          {this.state.successpopup.message}
        </SweetAlert>
      );
    } else if (
      !isEmpty(this.state.successpopup) &&
      this.state.successpopup.isError
    ) {
      return (
        <SweetAlert
          error
          title="Error"
          onConfirm={() => this.hideAlert()}
          btnSize="md"
        >
          {this.state.successpopup.message}
        </SweetAlert>
      );
    }
  };

  render() {
    const { errors } = this.state;
    const stickerSizes = this.state.stickerSize.split("X");

    const basicDetails = !isEmpty(this.state.supplierDetails)
      ? this.state.supplierDetails
      : {};

    const returnSuppliersList = this.state.suppliersList.map(
      (supplier, idx) => (
        <option value={supplier.basicDetails.emailId} key={idx}>
          {supplier.basicDetails.name} - {supplier.basicDetails.emailId}
        </option>
      )
    );

    const returnRawMaterials = this.state.rawMaterialsLIst.map(
      (material, idx) => (
        <option value={material._id} key={idx}>
          {material._id}
        </option>
      )
    );

    const returnQuantityList = quantityList.data.map((number, idx) => (
      <option value={number} key={idx}>
        {number}
      </option>
    ));

    const activeTab = this.props.qrOrder.qrTab;

    return (
      <div
        className={
          !isEmpty(activeTab) && activeTab === "Create"
            ? "tab-pane fade show active"
            : "tab-pane fade show"
        }
        id="pills-qr"
        role="tabpanel"
        aria-labelledby="pills-qr-tab"
      >
        {/* sweet alert popup */}
        {!isEmpty(this.state.successpopup) ? this.getAlert() : ""}
        {/* End sweet alert popup */}
        <div className="row">
          <div className="col-4 col-md-4">
            <div className="qr-content">
              <div className="row">
                <div className="col-md-12">
                  <div className="form-row">
                    <div className="form-group col-md-12">
                      <label htmlFor="Company Name" className="col-form-label">
                        Supplier Detail<span className="astric">*</span>
                      </label>
                      <select
                        id="inputState"
                        className="form-control"
                        name="supplierMailId"
                        onChange={this.onChange}
                        value={this.state.supplierMailId}
                      >
                        <option value="">Select</option>
                        {returnSuppliersList}
                      </select>
                    </div>
                  </div>
                  {errors && (
                    <p className="text-danger text-small">
                      {errors.supplierMailId}
                    </p>
                  )}
                </div>
              </div>
              <div className="row">
                <div className="col-md-12">
                  <div className="form-row">
                    <div className="form-group col-md-12">
                      <label htmlFor="Company Name" className="col-form-label">
                        Raw Material<span className="astric">*</span>
                      </label>
                      <select
                        id="inputState"
                        className="form-control"
                        name="rawMaterial"
                        onChange={this.onChange}
                        value={this.state.rawMaterial}
                      >
                        <option value="">Select</option>
                        {returnRawMaterials}
                      </select>
                    </div>
                  </div>
                  {errors && (
                    <p className="text-danger text-small">
                      {errors.rawMaterial}
                    </p>
                  )}
                </div>
              </div>
              <hr className="my-1" />
              <div className="row">
                <div className="col-md-12">
                  <div className="form-row">
                    <div className="form-group col-md-6">
                      <label
                        htmlFor="Package Quantity"
                        className="col-form-label"
                      >
                        Package Quantity<span className="astric">*</span>
                      </label>
                      <select
                        id="inputState"
                        className="form-control"
                        name="quantity"
                        onChange={this.onChange}
                        value={this.state.quantity}
                      >
                        <option value="">Select</option>
                        {returnQuantityList}
                      </select>
                    </div>
                    <div className="form-group col-md-6">
                      <label htmlFor="Role" className="col-form-label">
                        Number of Package<span className="astric">*</span>
                      </label>
                      <input
                        type="text"
                        className="form-control"
                        placeholder="Package"
                        type="number"
                        min="1"
                        name="noOfPackages"
                        onChange={this.onChange}
                        value={this.state.noOfPackages}
                      />
                    </div>
                  </div>
                  {errors && (
                    <p className="text-danger text-small">
                      {errors.quantity ? errors.quantity : ""}{" "}
                      {errors.noOfPackages ? errors.noOfPackages : ""}
                    </p>
                  )}
                </div>
              </div>
              <hr className="my-1" />
              <div className="row">
                <div className="col-md-12 form-m-group">
                  <label htmlFor="Package Quantity" className="col-form-label">
                    Raw Material ID range<span className="astric">*</span>
                  </label>
                  <div className="form-row">
                    <div className="form-group col-md-6">
                      <input
                        type="text"
                        className="form-control"
                        placeholder="Min"
                        name="minRawMaterialId"
                        onChange={this.onChange}
                        value={this.state.minRawMaterialId}
                      />
                    </div>
                    <div className="form-group col-md-6">
                      <input
                        type="text"
                        className="form-control"
                        placeholder="Max"
                        name="maxRawMaterialId"
                        onChange={this.onChange}
                        value={this.state.maxRawMaterialId}
                      />
                    </div>
                  </div>
                  {errors && (
                    <p className="text-danger text-small">
                      {errors.minRawMaterialId ? errors.minRawMaterialId : ""}
                      {errors.maxRawMaterialId ? errors.maxRawMaterialId : ""}
                    </p>
                  )}
                </div>
              </div>
              <hr className="my-1" />
              <div className="row">
                <div className="col-md-12 form-m-group">
                  <label htmlFor="Package Quantity" className="col-form-label">
                    QR code sticker Size<span className="astric">*</span>
                  </label>
                  <div className="form-row">
                    <div className="form-group col-md-6">
                      <select
                        id="inputState"
                        className="form-control"
                        name="stickerSize"
                        onChange={this.onChange}
                        value={this.state.stickerSize}
                      >
                        <option value="">Select</option>
                        <option value="1X1">1X1</option>
                        <option value="2X2">2X2</option>
                        <option value="3X3">3X3</option>
                        <option value="4X4">4X4</option>
                        <option value="5X5">5X5</option>
                      </select>
                    </div>
                    <div className="form-group col-md-6">
                      <select
                        id="inputState"
                        className="form-control"
                        name="sizeMeasurement"
                        onChange={this.onChange}
                        value={this.state.sizeMeasurement}
                      >
                        <option value="">Select</option>
                        <option value="CM">CM</option>
                      </select>
                    </div>
                  </div>
                  {errors && (
                    <p className="text-danger text-small">
                      {errors.stickerSize ? errors.stickerSize : ""}
                      {errors.sizeMeasurement ? errors.sizeMeasurement : ""}
                    </p>
                  )}
                </div>
              </div>
              <hr className="my-1" />
              <div className="row">
                <div className="col-md-12">
                  <div className="form-check">
                    <input
                      className="form-check-input"
                      type="checkbox"
                      defaultValue
                      id="Check1"
                    />
                    <label className="form-check-label h6" htmlFor="Check1">
                      {" "}
                      Add your logo company on the QR sticker{" "}
                    </label>
                  </div>
                </div>
              </div>
              <hr className="my-1" />
            </div>
          </div>

          {!isEmpty(this.state.supplierMailId) ? (
            <div className="col-md-8">
              <div className="qr-content">
                <div className="text-small"> Order Summary </div>
                <hr className="my-1" />
                <div className="row">
                  <div className="col-md-6">
                    {this.state.supplierMailId ? (
                      <div>
                        <div className="text-small">Supplier Detail </div>
                        <div className="q-sub-text">
                          {!isEmpty(basicDetails.name) ? basicDetails.name : ""}

                          {!isEmpty(basicDetails.address)
                            ? `, ${basicDetails.address}`
                            : ""}
                          {!isEmpty(basicDetails.city)
                            ? `, ${basicDetails.city}`
                            : ""}
                          {!isEmpty(basicDetails.state)
                            ? `, ${basicDetails.state}`
                            : ""}
                          {!isEmpty(basicDetails.zipCode)
                            ? `, ${basicDetails.zipCode}`
                            : ""}

                          {/* {this.state.supplierMailId} */}
                        </div>
                        <hr className="my-2" />
                      </div>
                    ) : (
                      ""
                    )}
                    {this.state.rawMaterial ? (
                      <div>
                        <div className="text-small">Raw Material</div>
                        <div className="q-sub-text">
                          {this.state.rawMaterial}
                        </div>
                        <hr className="my-2" />
                      </div>
                    ) : (
                      ""
                    )}
                    {this.state.quantity ? (
                      <div>
                        <div className="text-small">Package Quantity</div>
                        <div className="q-sub-text">{this.state.quantity}</div>
                        <hr className="my-2" />
                      </div>
                    ) : (
                      ""
                    )}
                    {this.state.noOfPackages ? (
                      <div>
                        <div className="text-small">Number of Package </div>
                        <div className="q-sub-text">
                          {this.state.noOfPackages}
                        </div>
                        <hr className="my-2" />
                      </div>
                    ) : (
                      ""
                    )}
                    {this.state.minRawMaterialId ? (
                      <div>
                        <div className="text-small">Raw Material Id Range </div>
                        <div className="q-sub-text">
                          {this.state.minRawMaterialId} -{" "}
                          {this.state.maxRawMaterialId}
                        </div>
                        <hr className="my-2" />
                      </div>
                    ) : (
                      ""
                    )}
                    {this.state.stickerSize ? (
                      <div>
                        <div className="text-small">QR code sticker Size </div>
                        <div className="q-sub-text">
                          {this.state.stickerSize}
                          {this.state.sizeMeasurement}
                        </div>
                        <hr className="my-2" />
                      </div>
                    ) : (
                      ""
                    )}
                  </div>
                  {this.state.stickerSize && this.state.sizeMeasurement ? (
                    <div className="col-md-6">
                      <div
                        className="p-qr-bkp mt-3"
                        style={{ textAlign: "center" }}
                      >
                        {" "}
                        <img
                          src="assets/img/qr-code.png"
                          width={stickerSizes[0] * 37.79}
                          height={stickerSizes[1] * 37.79}
                        />
                        <div>QR code perview</div>
                      </div>
                    </div>
                  ) : (
                    ""
                  )}
                </div>
                {this.state.supplierMailId &&
                this.state.rawMaterial &&
                this.state.quantity &&
                this.state.noOfPackages &&
                this.state.minRawMaterialId &&
                this.state.minRawMaterialId &&
                this.state.stickerSize &&
                this.state.sizeMeasurement ? (
                  <div className="row">
                    <div className="col-md-12">
                      <div className="qr-bottom-btn">
                        <button
                          type="submit"
                          className="btn btn-primary-ghost px-3 mr-2"
                          data-toggle="modal"
                          data-target="#modal_01"
                          onClick={this.clearFormData}
                        >
                          Cancel
                        </button>
                        <button
                          type="submit"
                          className="btn btn-primary px-2"
                          data-toggle="modal"
                          data-target="#modal_02"
                          onClick={this.saveOrder}
                        >
                          Confirm
                        </button>
                      </div>
                    </div>
                  </div>
                ) : (
                  ""
                )}
              </div>
            </div>
          ) : (
            <div className="col-md-8">
              <div className="qr-content">
                <div className="empty-qr-screen">
                  {/* <svg className="manage-nav-icon">
                  <use xlinkHref="assets/img/up-sprite.svg#onboard" />
                </svg> */}
                  <p>
                    To Create a QR code Order,Click on the Type of Raw Material
                  </p>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    );
  }
}

const mapStateToProps = (state) => ({
  qrOrder: state.qrOrder,
});

export default connect(mapStateToProps, {
  changeAlertSuccessMessage,
  changeQRActiveTabs,
  changeAlertErrorMessage,
})(withRouter(CreateQROrders));
