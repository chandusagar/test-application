import React, { Component } from "react";
import { withRouter, Link } from "react-router-dom";
import { connect } from "react-redux";
import Moment from "moment";
import jsPDF from "jspdf";
import * as html2canvas from "html2canvas";

/** Import util components */
import isEmpty from "../../../utils/isEmpty";

/** Import Services */
import { qrCodeServices } from "../../../services/qrCodeServices";

class PreviewSupplierPackageDetails extends Component {
  constructor(props) {
    super(props);
    this.state = {
      packagesList: [],
    };
  }

  componentDidMount() {
    this.getOrderDetails();
  }

  // Get list of order packages
  getOrderDetails = async () => {
    const packagesList = await qrCodeServices.getSupplierOrderPackageQRCodes(
      this.props.match.params.orderId
    );

    this.setState({ packagesList });
  };

  downloadPdf = (e) => {
    const input = document.getElementById("pdfpreview");

    html2canvas(input).then((canvas) => {
      const imgData = canvas.toDataURL("image/png");
      const pdf = new jsPDF("a4");
      var width = pdf.internal.pageSize.getWidth();

      var height = pdf.internal.pageSize.getHeight();
      pdf.addImage(imgData, "JPEG", 0, 0, width, height);
      pdf.save(new Date() + ".pdf");
    });
  };

  printPreview = () => {
    window.print();
  };

  render() {
    const { packagesList } = this.state;

    let displayPackagesList = (
      <tr>
        <td colSpan="2">Data not found</td>
      </tr>
    );

    if (!isEmpty(packagesList)) {
      displayPackagesList = packagesList.packages.map((item, index) => (
        <tr className="font-weight-bolder">
          <td>{index + 1}</td>
          <td>{item._id}</td>
          <td>
            <img src={item.qrId.qrCodeUrl} />
          </td>
        </tr>
      ));
    }

    return (
      <div className="layout active-qr-code-layout " id="pdfpreview">
        <div className="container">
          <div className="content d-flex flex-column flex-column-fluid">
            <div className="row mt-2">
              <div className="col-md-12">
                <div className="d-flex justify-content-end">
                  <Link to="/supplierqrcodeorders">
                    <button
                      type="submit"
                      className="btn p-0"
                      onclick="window.location.href='package-qr-code.html'"
                    >
                      {" "}
                      <i className="material-icons">close</i>{" "}
                    </button>
                  </Link>
                </div>
              </div>
            </div>
            <div className="border-bottom w-100" />
            <div className="row py-2 px-2 py-md-2 px-md-0">
              <div className="col-md-12">
                <div className="d-flex justify-content-end">
                  <button
                    type="button"
                    className="btn btn-light-primary font-weight-bold mr-4"
                    download="newfilename"
                    onClick={this.downloadPdf}
                  >
                    Download as PDF
                  </button>
                  <button
                    type="button"
                    className="btn btn-primary font-weight-bold"
                    onClick={this.printPreview}
                  >
                    Print Invoice
                  </button>
                </div>
              </div>
            </div>
            <div className="border-bottom w-100" />
            {/* begin: Invoice*/}
            <div className="row justify-content-center py-4 px-4 py-md-5 px-md-0">
              <div className="col-md-12">
                <div className="d-flex justify-content-between pb-5 pb-md-5 flex-column flex-md-row">
                  <h1 className="display-6 font-weight-boldest m-0">INVOICE</h1>
                  <div className="d-flex flex-column align-items-md-end px-0">
                    {" "}
                    <span className="d-flex flex-column align-items-md-end opacity-70">
                      {" "}
                      <span className="font-weight-bolder">Order ID</span>{" "}
                      <span className="font-weight-bolder">
                        {this.state.packagesList._id}
                      </span>{" "}
                    </span>{" "}
                  </div>
                </div>
                <div className="border-bottom w-100" />
                <div className="invoice-title h4 font-weight-bolder py-3 m-0">
                  MSR COSMOS
                </div>
                <div className="d-flex justify-content-between py-2">
                  <div className="d-flex flex-column flex-root">
                    {" "}
                    <span className="font-weight-bolder">Order Date</span>{" "}
                    <span className="opacity-70">
                      {Moment(this.state.packagesList.created).format(
                        "MM/DD/YYYY"
                      )}
                    </span>
                  </div>
                  <div className="d-flex flex-column flex-root">
                    <span className="font-weight-bolder">Activated Date </span>{" "}
                    <span className="opacity-70">
                      {Moment(
                        this.state.packagesList.qrCodesGeneratedAt
                      ).format("MM/DD/YYYY")}
                    </span>
                  </div>
                  <div className="d-flex flex-column flex-root">
                    {" "}
                    <span className="font-weight-bolder">Total Cost</span>{" "}
                    <span className="opacity-70">14000.00</span>{" "}
                  </div>
                </div>
                <div className="d-flex justify-content-between py-2">
                  <div className="d-flex flex-column flex-root">
                    {" "}
                    <span className="font-weight-bolder">Name</span>{" "}
                    <span className="opacity-70">
                      {!isEmpty(this.state.packagesList.createdBy) &&
                      !isEmpty(this.state.packagesList.createdBy.firstName)
                        ? this.state.packagesList.createdBy.firstName
                        : ""}{" "}
                      {!isEmpty(this.state.packagesList.createdBy) &&
                      !isEmpty(this.state.packagesList.createdBy.lastName)
                        ? this.state.packagesList.createdBy.lastName
                        : ""}
                    </span>{" "}
                  </div>
                  <div className="d-flex flex-column flex-root">
                    {" "}
                    <span className="font-weight-bolder">Email</span>{" "}
                    <span className="opacity-70">
                      {!isEmpty(this.state.packagesList.createdBy) &&
                      !isEmpty(this.state.packagesList.createdBy.email)
                        ? this.state.packagesList.createdBy.email
                        : ""}
                    </span>{" "}
                  </div>
                  <div className="d-flex flex-column flex-root">
                    {" "}
                    <span className="font-weight-bolder">Phone</span>{" "}
                    <span className="opacity-70">
                      {!isEmpty(this.state.packagesList.createdBy) &&
                      !isEmpty(this.state.packagesList.createdBy.phone)
                        ? this.state.packagesList.createdBy.phone
                        : ""}
                    </span>{" "}
                  </div>
                </div>
              </div>
            </div>
            {/* end: Invoice header*/}
            {/* begin: Invoice body*/}
            <div className="row justify-content-center py-4 px-4 py-md-2 px-md-0">
              <div className="col-md-12">
                <div className="table-responsive invoice-table">
                  <table className="table table-striped">
                    <thead>
                      <tr>
                        <th className=" font-weight-bold  text-uppercase">
                          S.No
                        </th>
                        <th className="font-weight-bold text-uppercase">
                          Package ID
                        </th>
                        <th className="font-weight-bold text-uppercase">
                          QR Code
                        </th>
                      </tr>
                    </thead>
                    <tbody>{displayPackagesList}</tbody>
                  </table>
                </div>
              </div>
            </div>
            {/* end: Invoice body*/}
          </div>
        </div>
      </div>
    );
  }
}

const mapStateToProps = (state) => ({});

export default connect(
  mapStateToProps,
  {}
)(withRouter(PreviewSupplierPackageDetails));
