/** Import Depency modules */
import React, { Component } from "react";
import { withRouter, Link } from "react-router-dom";
import { connect } from "react-redux";
import Moment from "moment";
import SweetAlert from "react-bootstrap-sweetalert";

import Gmap from "../../common/Gmap";

/** Import Services */
import { qrCodeServices } from "../../../services/qrCodeServices";

/** Import Components */
import CancelOrderModal from "../common/CancelOrderModal";

/** Import Util files */
import isEmpty from "../../../utils/isEmpty";

/**Import qr actions */
import {
  changeAlertSuccessMessage,
  changeAlertErrorMessage,
} from "../../../actions/qrAction";

class SupplierOrderDetails extends Component {
  constructor() {
    super();
    this.state = {
      orderDetails: {},
      supplierDetails: {},
      showCancelOrderModal: false,
      successpopup: {},
    };
  }

  componentDidMount() {
    this.getOrderDetails();
  }

  componentDidUpdate(prevProps) {
    if (
      prevProps.qrOrder.alertSuccessMessage !==
      this.props.qrOrder.alertSuccessMessage
    ) {
      this.setState({
        alertSuccessMessage: this.props.qrOrder.alertSuccessMessage,
      });
    }

    if (
      prevProps.qrOrder.alertErrorMessage !==
      this.props.qrOrder.alertErrorMessage
    ) {
      this.setState({
        alertErrorMessage: this.props.qrOrder.alertErrorMessage,
      });
    }
  }

  // Get list of orders
  getOrderDetails = async () => {
    const orderDetails = await qrCodeServices.getSupplierOrderDetails(
      this.props.match.params.orderId
    );

    if (!isEmpty(orderDetails)) {
      this.setState({ orderDetails }, async () => {
        const supplierDetails = await qrCodeServices.getSupplierDetailsByEmail(
          orderDetails.supplierMailId
        );

        if (!isEmpty(supplierDetails)) {
          this.setState({ supplierDetails });
        }
      });
    }
  };

  // Open cancel order modal
  openCancelOrderModal = () => {
    this.setState({ showCancelOrderModal: true });
  };

  // Close cancel order modal
  closeCancelOrderModal = () => {
    this.setState({ showCancelOrderModal: false });
  };

  // Activate supplier qr codes
  activateQrcodes = async () => {
    const saveResult = await qrCodeServices.activateSupplierQrCodes(
      this.props.match.params.orderId
    );

    if (!isEmpty(saveResult) && saveResult.isError === false) {
      let successpopup = saveResult;
      this.setState({ successpopup });
    } else {
      let successpopup = saveResult;
      let errors = saveResult;
      this.setState({ errors, successpopup });
    }
  };

  // Navigate to supplier qr code orders list
  navigationToBackPage = () => {
    this.props.history.push("/supplierqrcodeorders");
  };

  /**hide sweet alert popup */
  hideAlert = () => {
    if (!isEmpty(this.state.successpopup) && !this.state.successpopup.isError) {
      this.props.history.push("/supplierqrcodeorders");
    }
    this.setState({ successpopup: {} });
  };

  /**show sweet alert popup */
  getAlert = () => {
    if (!isEmpty(this.state.successpopup) && !this.state.successpopup.isError) {
      return (
        <SweetAlert
          success
          title="Success"
          onConfirm={() => this.hideAlert()}
          btnSize="md"
        >
          {this.state.successpopup.message}
        </SweetAlert>
      );
    } else if (
      !isEmpty(this.state.successpopup) &&
      this.state.successpopup.isError
    ) {
      return (
        <SweetAlert
          error
          title="Error"
          onConfirm={() => this.hideAlert()}
          btnSize="md"
        >
          {this.state.successpopup.message}
        </SweetAlert>
      );
    }
  };

  render() {
    const basicDetails = !isEmpty(this.state.supplierDetails.basicDetails)
      ? this.state.supplierDetails.basicDetails
      : {};

    const succes = {
      paddingLeft: "35%",
      paddingRight: "36%",
    };

    return (
      <div>
        {/* sweet alert popup */}
        {!isEmpty(this.state.successpopup) ? this.getAlert() : ""}
        {/* End sweet alert popup */}
        {!isEmpty(this.state.alertSuccessMessage) ? (
          <div className="alert alert-success bg-success text-white alert-dismissible success_popup">
            <button type="button" className="close">
              &times;
            </button>
            <div className="text-center" style={succes}>
              {this.state.alertSuccessMessage}
            </div>
          </div>
        ) : !isEmpty(this.state.alertErrorMessage) ? (
          <div className="alert alert-danger bg-danger text-white alert-dismissible success_popup">
            <button type="button" className="close">
              &times;
            </button>
            <div className="text-center" style={succes}>
              {this.state.alertErrorMessage}
            </div>
          </div>
        ) : (
          ""
        )}

        <div className="layout active-qr-code-layout ">
          <div className="container-fluid">
            <div className="qr-act-header">
              <div className="l-act-content">
                {this.state.orderDetails.orderStatus === "Available"
                  ? "Activative QR codes"
                  : "QR Codes Generated - Details"}
              </div>
              <div className="r-act-content">
                {this.state.orderDetails.orderStatus === "Available" ? (
                  <div>
                    <button
                      type="button"
                      className="btn btn-primary-ghost px-3 mr-2"
                      // data-toggle="modal"
                      // data-target="#modal_01"
                      onClick={this.openCancelOrderModal}
                    >
                      Cancel
                    </button>

                    <button
                      type="button"
                      className="btn btn-primary px-2"
                      onClick={this.activateQrcodes}
                    >
                      Generate QR codes{" "}
                    </button>
                  </div>
                ) : (
                  ""
                  // <button
                  //   type="button"
                  //   className="btn btn-primary-ghost px-3 mr-2"
                  //   onClick={this.navigationToBackPage}
                  // >
                  //   Back
                  // </button>
                )}
              </div>
            </div>
            <div className="act-header-title mt-2">
              <span>Summary : </span>
              <span>Order Number</span>
              <span>- {this.state.orderDetails._id}</span>
            </div>
            <div className="row mt-2">
              <div className="col-md-6">
                <div className="text-small d-flex">
                  <span className="text-dark w-2">Supplier Details :</span>
                  <span>
                    {this.state.orderDetails.supplierMailId
                      ? this.state.orderDetails.supplierMailId
                      : ""}
                  </span>
                </div>
                <hr className="my-1" />
                <div className="text-small d-flex">
                  <span className="text-dark w-2">Raw Material :</span>
                  <span>
                    {this.state.orderDetails.rawMaterial
                      ? this.state.orderDetails.rawMaterial
                      : ""}
                  </span>
                </div>
                <hr className="my-1" />
                <div className="text-small d-flex">
                  <span className="text-dark w-2">RawMaterial ID range :</span>
                  <span>
                    {this.state.orderDetails.minRawMaterialId
                      ? this.state.orderDetails.minRawMaterialId
                      : ""}
                    -
                    {this.state.orderDetails.maxRawMaterialId
                      ? this.state.orderDetails.maxRawMaterialId
                      : ""}
                  </span>
                </div>
                <hr className="my-1" />
                <div className="text-small d-flex">
                  <span className="text-dark w-2">Package Quantity:</span>
                  <span>
                    {this.state.orderDetails.quantity
                      ? this.state.orderDetails.quantity
                      : ""}
                  </span>
                </div>
                <hr className="my-1" />
                <div className="text-small d-flex">
                  <span className="text-dark w-2">Number of Package:</span>
                  <span>
                    {this.state.orderDetails.noOfPackages
                      ? this.state.orderDetails.noOfPackages
                      : ""}
                  </span>
                </div>
                <hr className="my-1" />
                {this.state.orderDetails.orderStatus === "Active" ? (
                  <div>
                    <div className="text-small d-flex">
                      <span className="text-dark w-2">Order on:</span>
                      <span>
                        {this.state.orderDetails.created
                          ? Moment(this.state.orderDetails.created).format(
                              "MM/DD/YYYY"
                            )
                          : ""}
                      </span>
                    </div>
                    <hr className="my-1" />
                    <div className="text-small d-flex">
                      <span className="text-dark w-2">Order created by:</span>
                      <span>
                        {this.state.orderDetails.createdBy
                          ? this.state.orderDetails.createdBy.firstName
                          : ""}{" "}
                        {this.state.orderDetails.createdBy
                          ? this.state.orderDetails.createdBy.lastName
                          : ""}
                      </span>
                    </div>
                    <hr className="my-1" />
                    <div className="text-small d-flex">
                      <span className="text-dark w-2">Activated on:</span>
                      <span>
                        {this.state.orderDetails.qrCodesGeneratedAt
                          ? Moment(
                              this.state.orderDetails.qrCodesGeneratedAt
                            ).format("MM/DD/YYYY")
                          : ""}
                      </span>
                    </div>
                    <hr className="my-1" />
                    <div className="text-small d-flex">
                      <span className="text-dark w-2">Activated by:</span>
                      <span>
                        {this.state.orderDetails.activatedBy
                          ? this.state.orderDetails.activatedBy.firstName
                          : ""}{" "}
                        {this.state.orderDetails.activatedBy
                          ? this.state.orderDetails.activatedBy.lastName
                          : ""}
                      </span>
                    </div>
                    <hr className="my-1" />
                    <div className="text-small d-flex">
                      <span className="text-dark w-2">Generated on:</span>
                      <span>
                        {this.state.orderDetails.qrCodesGeneratedAt
                          ? Moment(
                              this.state.orderDetails.qrCodesGeneratedAt
                            ).format("MM/DD/YYYY")
                          : ""}
                      </span>
                    </div>
                    <hr className="my-1" />
                    <div className="text-small d-flex">
                      <span className="text-dark w-2">Delivery status:</span>
                      <span>{""}</span>
                    </div>
                    <hr className="my-1" />
                    <div className="text-small d-flex">
                      <span className="text-dark w-2">Delivery to:</span>
                      <span>{""}</span>
                    </div>
                    <hr className="my-1" />
                  </div>
                ) : (
                  ""
                )}
              </div>
              <div className="col-md-3 p-box">
                {" "}
                <img src="/assets/img/Product.png" />
                <div>Product Package box</div>{" "}
              </div>
              <div
                className="col-md-3 p-qr-bkp"
                style={{ textAlign: "center" }}
              >
                {" "}
                <img
                  src="/assets/img/qr-code.png"
                  width={
                    !isEmpty(this.state.orderDetails.stickerSize)
                      ? this.state.orderDetails.stickerSize.split("X")[0] *
                        37.79
                      : ""
                  }
                  height={
                    !isEmpty(this.state.orderDetails.stickerSize)
                      ? this.state.orderDetails.stickerSize.split("X")[1] *
                        37.79
                      : ""
                  }
                />
                <div>QR code perview</div>{" "}
              </div>
            </div>
            <div className="act-header-title mt-2">
              <span>Supplier Details of the above Raw Material</span>
            </div>
            <div className="text-small mt-2">
              <p>
                If your find any discrepancy in the Supplier or Manufacturer
                Details , You can rise a ticket to our support team, by clicking
                this link : <a href="#">Rise a issue</a>{" "}
              </p>
            </div>
            <div className="row mt-2">
              <div className="col-12 col-lg-6 col-xl-3 ">
                <div className="card flex-fill w-100">
                  <div className="card-header d-flex">
                    <h6 className="card-title mb-0">Supplier Details</h6>
                  </div>
                  <div className="card-body">
                    <div className="text-small">Supplier Type</div>
                    <div className="sub-text">Dairy products</div>
                    <hr className="my-1" />
                    <div className="text-small">Supplier Name</div>
                    <div className="sub-text">
                      {!isEmpty(basicDetails.name) ? basicDetails.name : ""}
                    </div>
                    <hr className="my-1" />
                    <div className="text-small">Email id</div>
                    <div className="sub-text">
                      {!isEmpty(basicDetails.emailId)
                        ? basicDetails.emailId
                        : ""}
                    </div>
                    <hr className="my-1" />
                    <div className="text-small">Phone / Mobile Number</div>
                    <div className="sub-text">
                      {!isEmpty(basicDetails.phoneNo)
                        ? basicDetails.phoneNo
                        : ""}
                    </div>
                    <hr className="my-1" />
                    <div className="text-small">Supplier Address</div>
                    <div className="sub-text">
                      <p>
                        {!isEmpty(basicDetails.address)
                          ? basicDetails.address
                          : ""}
                      </p>
                    </div>
                  </div>
                </div>
              </div>

              <div className="col-12 col-lg-6 col-xl-9">
                <div className="act-map-container">
                  <Gmap
                    style={{
                      position: "relative",
                      width: "100%",
                      height: "310px",
                    }}
                    address={basicDetails}
                    location={{
                      lat: basicDetails.latitude
                        ? Number(basicDetails.latitude)
                        : "",
                      lng: basicDetails.longitude
                        ? Number(basicDetails.longitude)
                        : "",
                    }}
                  />
                </div>
              </div>
            </div>
          </div>
        </div>

        {this.state.showCancelOrderModal ? (
          <CancelOrderModal
            show={this.state.showCancelOrderModal}
            onClose={this.closeCancelOrderModal}
            cancelUrlFrom="Supplier"
            orderId={this.props.match.params.orderId}
          />
        ) : (
          ""
        )}
      </div>
    );
  }
}

const mapStateToProps = (state) => ({
  qrOrder: state.qrOrder,
});

export default connect(mapStateToProps, {
  changeAlertSuccessMessage,
  changeAlertErrorMessage,
})(withRouter(SupplierOrderDetails));
