/** Import Depency modules */
import React, { Component } from "react";
import { withRouter, Link } from "react-router-dom";
import { connect } from "react-redux";
import { DataTable } from "primereact/datatable";
import { Column } from "primereact/column";
import Moment from "moment";

/** Import util components */
import isEmpty from "../../../utils/isEmpty";

/** Import Services */
import { qrCodeServices } from "../../../services/qrCodeServices";

class DeliverQRCodes extends Component {
  constructor() {
    super();
    this.state = {
      customers: [{ name: "ram" }],
      ordersList: [],
    };
  }

  componentDidMount() {
    this.getOrders();
  }

  // Get list of supplier orders
  getOrders = async () => {
    const ordersList = await qrCodeServices.getSupplierOrders();
    this.setState({ ordersList });
  };

  // Add dynamic columns to datatables
  dynamicColumns = () => {
    const columns = [
      { field: "_id", header: "Order.No" },
      { field: "supplierMailId", header: "Supplier Details" },
      { field: "rawMaterial", header: "Raw Material" },
      { field: "minRawMaterialId", header: "Product Id Range" },
      { field: "qrCodesGeneratedAt", header: "QR Codes Generated on" },
      { field: "Actions", header: "Actions" },
    ];

    return columns.map((col, i) => (
      <Column
        key={col.field}
        field={col.field}
        header={col.header}
        body={(rowData, col) => this.modifyColumns(rowData, col)}
      />
    ));
  };

  // Modify columns data
  modifyColumns = (rowData, column) => {
    if (column.field === "Actions") {
      if (rowData.orderStatus === "Active") {
        return (
          <div>
            <button className="btn">
              {" "}
              <i className="fa fa-envelope" />{" "}
            </button>
            <button
              className="btn"
              onClick={() => this.navigateToPrintPackages(rowData._id)}
            >
              <i className="fa fa-print" />{" "}
            </button>
          </div>
        );
      } else {
        return "";
      }
    } else if (column.field === "qrCodesGeneratedAt") {
      return Moment(rowData[column.field]).format("MM/DD/YYYY");
    } else if (column.field === "minRawMaterialId") {
      return rowData[column.field] + " - " + rowData.maxRawMaterialId;
    } else if (column.field === "_id") {
      return (
        <a
          style={
            rowData.orderStatus === "Active"
              ? { textDecoration: "underline" }
              : {}
          }
          onClick={
            rowData.orderStatus === "Active"
              ? () => this.supplierOrderetailsPage(rowData._id)
              : ""
          }
        >
          {rowData[column.field]}
        </a>
      );
    } else {
      return rowData[column.field];
    }
  };

  // Navigate to order details print/preview page
  navigateToPrintPackages = (id) => {
    this.props.history.push(`previewSupplierPackageDetails/${id}`);
  };

  navigateToOrderetailsPage = (rowData) => {
    this.props.history.push(`orderDetails/${rowData._id}`);
  };

  // Navigate to order details page
  supplierOrderetailsPage = (id) => {
    this.props.history.push(`supplierOrderDetails/${id}`);
  };

  render() {
    const activeTab = this.props.qrOrder.qrTab;

    return (
      <div
        className={
          !isEmpty(activeTab) && activeTab === "Deliver"
            ? "tab-pane fade show active"
            : "tab-pane fade show"
        }
        id="pills-deliver"
        role="tabpanel"
        aria-labelledby="pills-deliver-tab"
      >
        <div className="card">
          <DataTable
            className="table-custom"
            value={this.state.ordersList}
            emptyMessage="No records found"
            paginator={true}
            rows={10}
            rowsPerPageOptions={[10, 25, 50, 100]}
          >
            {this.dynamicColumns()}
          </DataTable>
        </div>
      </div>
    );
  }
}

const mapStateToProps = (state) => ({
  qrOrder: state.qrOrder,
});

export default connect(mapStateToProps, {})(withRouter(DeliverQRCodes));
