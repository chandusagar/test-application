/** Import Depency modules */
import React, { Component } from "react";
import { withRouter, Link } from "react-router-dom";
import { connect } from "react-redux";
import { DataTable } from "primereact/datatable";
import { Column } from "primereact/column";
import Moment from "moment";

/** Import util components */
import isEmpty from "../../../utils/isEmpty";

/** Import Services */
import { qrCodeServices } from "../../../services/qrCodeServices";

class MyOrderHistory extends Component {
  constructor() {
    super();
    this.state = {
      ordersList: [],
    };
  }

  componentDidMount() {
    this.getOrders();
  }

  // Get list of supplier orders
  getOrders = async () => {
    const ordersList = await qrCodeServices.getSupplierOrders();
    this.setState({ ordersList });
  };

  // Add dynamic columns to datatables
  dynamicColumns = () => {
    const columns = [
      // { field: "", header: "S.No" },
      { field: "_id", header: "Order.No" },
      { field: "supplierMailId", header: "Supplier details" },
      { field: "created", header: "Ordered on" },
      { field: "createdBy", header: "Order created by" },
      { field: "qrCodesGeneratedAt", header: "Activated on" },
      { field: "activatedBy", header: "Activated by" },
      { field: "qrCodesGeneratedAt", header: "Generated on" },
      { field: "Actions", header: "Send to" },
    ];

    return columns.map((col, i) => (
      <Column
        key={col.field}
        field={col.field}
        header={col.header}
        body={(rowData, col) => this.modifyColumns(rowData, col)}
      />
    ));
  };

  // Modify columns data
  modifyColumns = (rowData, column) => {
    if (column.field === "qrCodesGeneratedAt" || column.field === "created") {
      return Moment(rowData[column.field]).format("MM/DD/YYYY");
    } else if (column.field === "_id") {
      return (
        <span className="token-anchor" title="">
          {rowData._id}
        </span>
      );
    } else if (column.field === "createdBy") {
      return (
        <span>
          {rowData.createdBy ? rowData.createdBy.firstName : ""}{" "}
          {rowData.createdBy ? rowData.createdBy.lastName : ""}
        </span>
      );
    } else if (column.field === "activatedBy") {
      return (
        <span>
          {rowData.activatedBy ? rowData.activatedBy.firstName : ""}{" "}
          {rowData.activatedBy ? rowData.activatedBy.lastName : ""}
        </span>
      );
    } else {
      return rowData[column.field];
    }
  };

  render() {
    const activeTab = this.props.qrOrder.qrTab;

    return (
      <div
        className={
          !isEmpty(activeTab) && activeTab === "History"
            ? "tab-pane fade show active"
            : "tab-pane fade show"
        }
        id="pills-order"
        role="tabpanel"
        aria-labelledby="pills-order-tab"
      >
        <DataTable
          className="table table-bordered table-sm mb-1 qr-datatable"
          value={this.state.ordersList}
          emptyMessage="No records found"
          paginator={true}
          rows={10}
          rowsPerPageOptions={[10, 25, 50, 100]}
        >
          {this.dynamicColumns()}
        </DataTable>
      </div>
    );
  }
}

const mapStateToProps = (state) => ({
  qrOrder: state.qrOrder,
});

export default connect(mapStateToProps, {})(withRouter(MyOrderHistory));
