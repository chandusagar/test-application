import React, { Component } from "react";
import { withRouter, Link } from "react-router-dom";
import { connect } from "react-redux";

/** Import util components */
import isEmpty from "../../../utils/isEmpty";

/** Import Services */
import { qrCodeServices } from "../../../services/qrCodeServices";

/** Import Components */
import HeaderText from "../common/HeaderText";
import DeleteMyInventoriesModal from "./DeleteMyInventoriesModal";
import ViewMyInventoriesModal from "./ViewMyInventoriesModal";

class myInventoriesList extends Component {
  constructor() {
    super();
    this.state = {
      myInventories: [],
      deleteInventoryModal: false,
      viewInventoryModal: false,
      inventoryTitle: "",
    };
  }

  componentDidMount() {
    this.getMyInventories();
  }

  // Get list of inventories
  getMyInventories = async () => {
    const myInventories = await qrCodeServices.getMyInventories();
    this.setState({ myInventories });
  };

  // Open delete Inventory modal
  openDeleteInventoryModal = (inventoryTitle) => {
    this.setState({ deleteInventoryModal: true, inventoryTitle });
  };

  // Close delete Inventory modal
  closeDeleteInventoryModal = () => {
    this.setState(
      {
        deleteInventoryModal: false,
        inventoryTitle: "",
      },
      () => {
        this.getMyInventories();
      }
    );
  };

  // Navigate to onboard screens
  addInventory = (title) => {
    let inventoryTitle =
      title === "Logistics" ? "logistics" : title.toLowerCase().slice(0, -1);

    this.props.history.push(inventoryTitle);
  };

  // Open View Inventory modal
  openViewInventoryModal = (inventoryTitle) => {
    this.setState({ viewInventoryModal: true, inventoryTitle });
  };

  // Close View Inventory modal
  closeViewInventoryModal = () => {
    this.setState({ viewInventoryModal: false });
  };

  editInventory = (title) => {
    let inventoryTitle =
      title === "Logistics" ? "logistics" : title.toLowerCase().slice(0, -1);

    inventoryTitle = "edit" + inventoryTitle;

    this.props.history.push(inventoryTitle);
  };

  render() {
    let appendMyInventoriesData = (
      <tr>
        <td colSpan="2">Data not found</td>
      </tr>
    );

    if (!isEmpty(this.state.myInventories)) {
      appendMyInventoriesData = this.state.myInventories.map((row) => (
        <tr>
          <td>{row.title}</td>
          <td className="text-center">{row.count}</td>
          <td className="text-center">{row.storageUnits}</td>
          <td className="text-center">{row.systemIntegrate} </td>
          <td className="text-center">
            <button
              onClick={
                row.count > 0
                  ? () => this.openViewInventoryModal(row.title)
                  : ""
              }
              className="btn"
              data-toggle="modal"
              data-target="#modal_01"
            >
              <i className="fa fa-eye" />
            </button>
          </td>
          <td className="text-center">
            <div className="dropup">
              <button
                className="btn"
                role="button"
                data-toggle="dropdown"
                aria-expanded="false"
              >
                <i className="fa fa-ellipsis-h" />
              </button>
              <div className="dropdown-menu">
                <a
                  onClick={() => this.addInventory(row.title)}
                  className="dropdown-item"
                >
                  Add {row.title.slice(0, -1)}
                </a>
                {/* <a
                  className="dropdown-item"
                  data-toggle="modal"
                  data-target="#modal_03"
                  onClick={() => this.editInventory(row.title)}
                >
                  Edit {row.title.slice(0, -1)}
                </a> */}
                <a
                  className="dropdown-item"
                  data-toggle="modal"
                  data-target="#modal_04"
                  onClick={
                    row.count > 0
                      ? () => this.openDeleteInventoryModal(row.title)
                      : ""
                  }
                >
                  Delete {row.title.slice(0, -1)}
                </a>
              </div>
            </div>
          </td>
        </tr>
      ));
    }

    return (
      <div>
        <HeaderText textName="My Inventories" />

        <div className="qr-content-container">
          <div className="uc-step-module">
            <div className="uc-step-module-top">
              <div className="my-invert-content">
                <div className="custom-table mt-1">
                  <table className="table  mb-1">
                    <thead>
                      <tr>
                        <th>Title</th>
                        <th className="text-center">On Board Inventories</th>
                        <th className="text-center">No.of Storage Units </th>
                        <th className="text-center">No.of System Integrate</th>
                        <th className="text-center">View Details</th>
                        <th className="text-center">Actions</th>
                      </tr>
                    </thead>
                    <tbody>{appendMyInventoriesData}</tbody>
                  </table>
                </div>
              </div>
            </div>
          </div>
        </div>
        {this.state.deleteInventoryModal ? (
          <DeleteMyInventoriesModal
            show={this.state.deleteInventoryModal}
            onClose={this.closeDeleteInventoryModal}
            title={this.state.inventoryTitle}
          />
        ) : (
          ""
        )}

        {this.state.viewInventoryModal ? (
          <ViewMyInventoriesModal
            show={this.state.viewInventoryModal}
            onClose={this.closeViewInventoryModal}
            title={this.state.inventoryTitle}
          />
        ) : (
          ""
        )}
      </div>
    );
  }
}

const mapStateToProps = (state) => ({});

export default connect(mapStateToProps, {})(withRouter(myInventoriesList));
