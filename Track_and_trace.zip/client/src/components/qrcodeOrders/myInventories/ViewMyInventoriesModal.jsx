import React, { Component } from "react";
import { Link } from "react-router-dom";

/** Import util components */
import isEmpty from "../../../utils/isEmpty";

/** Import Services */
import { qrCodeServices } from "../../../services/qrCodeServices";

export default class ViewMyInventoriesModal extends Component {
  constructor() {
    super();
    this.state = {
      inventoryData: [],
      accordianIndex: null,
    };
  }

  componentDidMount() {
    this.getInventoriesDataForViewOrEdit();
  }

  /**Get suppliers/manufacturers/logistics/distributors/retailers data */
  getInventoriesDataForViewOrEdit = async () => {
    const inventoryData = await qrCodeServices.getInventoriesDataForViewOrEdit(
      this.props.title
    );
    this.setState({ inventoryData });
  };

  showAccordian = (index) => {
    let accordianIndex = index;
    if (index === this.state.accordianIndex) {
      accordianIndex = null;
    }
    this.setState({ accordianIndex });
  };

  render() {
    let displayData = (
      <div>
        <span>Data not found</span>
      </div>
    );

    if (!isEmpty(this.state.inventoryData)) {
      displayData = this.state.inventoryData.map((row, index) => (
        <div className="accordion mt-1" id="accordion-1" key={index}>
          <div className="card m-0">
            <div
              className="card-header"
              id="headingOne"
              onClick={() => this.showAccordian(index)}
            >
              <h2 className="mb-0">
                <button
                  className="btn accordionBtn ml-1 p-0"
                  type="button"
                  data-toggle="collapse"
                  // data-target="#collapseOne"
                  aria-expanded="true"
                  aria-controls="collapseOne"
                >
                  {this.props.title.slice(0, -1)}_{index + 1}
                </button>
                <label className="ml-1">
                  Name of the {this.props.title.slice(0, -1)} :{" "}
                  <span className="sub-txt-header">
                    {row.basicDetails.name}
                  </span>
                </label>
              </h2>
            </div>
            <div
              id="collapseOne"
              className={
                index === this.state.accordianIndex ? "show" : "collapse"
              }
              aria-labelledby="headingOne"
              data-parent="#accordion-1"
              style={{}}
            >
              <div className="stepper-content p-2 ">
                <div className="row">
                  <div className="col-md-11"></div>
                  <div className="col-md-1">
                    <div className="card-actions expand-icon-txt mb-2 pull-right">
                      <Link
                        to={
                          this.props.title === "Logistics"
                            ? `/editlogistics/${row._id}`
                            : `/edit${this.props.title
                                .toLowerCase()
                                .slice(0, -1)}/${row._id}`
                        }
                      >
                        <button className="btn p-0">
                          <i className="fas fa-edit" />
                        </button>
                      </Link>
                    </div>
                  </div>
                </div>

                <div className="row perview">
                  <div className="col-12 col-lg-6 col-xl-4 d-flex">
                    <div className="card flex-fill w-100">
                      <div className="card-header d-flex">
                        <h6 className="card-title mb-0">Basic Details</h6>
                      </div>
                      <div className="card-body">
                        <div className="text-small">Supplier Type</div>
                        <div className="sub-text">
                          {row.basicDetails.type ? row.basicDetails.type : ""}
                        </div>
                        <hr className="my-1" />
                        <div className="text-small">Supplier Name</div>
                        <div className="sub-text">
                          {row.basicDetails.name ? row.basicDetails.name : ""}
                        </div>
                        <hr className="my-1" />
                        <div className="text-small">Email id</div>
                        <div className="sub-text">
                          {row.basicDetails.emailId
                            ? row.basicDetails.emailId
                            : ""}
                        </div>
                        <hr className="my-1" />
                        <div className="text-small">Phone / Mobile Number</div>
                        <div className="sub-text">
                          {row.basicDetails.phoneNo
                            ? row.basicDetails.phoneNo
                            : ""}
                        </div>
                        <hr className="my-1" />
                        <div className="text-small">Supplier Address</div>
                        <div className="sub-text">
                          <p>
                            {row.basicDetails.address
                              ? row.basicDetails.address
                              : ""}

                            {row.basicDetails.city
                              ? `, ${row.basicDetails.city}`
                              : ""}
                            {row.basicDetails.state
                              ? `, ${row.basicDetails.state}`
                              : ""}
                            {row.basicDetails.zipCode
                              ? ` - ${row.basicDetails.zipCode}`
                              : ""}
                            {row.basicDetails.country
                              ? `, ${row.basicDetails.country}.`
                              : ""}
                          </p>
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="col-12 col-lg-6 col-xl-4 d-flex">
                    <div className="card flex-fill w-100">
                      <div className="card-header d-flex">
                        <h6 className="card-title mb-0">
                          Storage Units - {row.storageUnits.length}
                        </h6>
                      </div>
                      <div
                        className={
                          row.storageUnits.length > 2 ? "m-content" : ""
                        }
                      >
                        {row.storageUnits.map((storage, sindex) => (
                          <div className="card-body" key={sindex}>
                            <div className="title-header">
                              <h6 className="title-bg">
                                Storage Unit_{sindex + 1} Details
                              </h6>
                            </div>
                            <div className="text-small">
                              Name of the Storage
                            </div>
                            <div className="sub-text">
                              {storage.name ? storage.name : ""}
                            </div>
                            <hr className="my-1" />
                            <div className="text-small">
                              Storage Unit Address
                            </div>
                            <div className="sub-text">
                              <p>
                                {storage.address ? storage.address : ""}{" "}
                                {storage.city ? `, ${storage.city}` : ""}
                                {storage.state ? `, ${storage.state}` : ""}
                                {storage.zipCode ? ` - ${storage.zipCode}` : ""}
                                {storage.country ? `, ${storage.country}.` : ""}
                              </p>
                            </div>
                            <hr className="my-1" />
                            {/* <div className="loction-image">
                              <div
                                className="map-container"
                                style={{ height: "160px" }}
                              >
                                <iframe
                                  src="https://maps.google.com/maps?q=manhatan&t=&z=13&ie=UTF8&iwloc=&output=embed"
                                  frameBorder={0}
                                  style={{
                                    border: 0,
                                    width: "320px",
                                    height: "160px",
                                  }}
                                  allowFullScreen
                                />
                              </div>
                            </div> */}
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>

                  <div className="col-12 col-lg-6 col-xl-4 d-flex">
                    <div className="card flex-fill w-100">
                      <div className="card-header d-flex">
                        <h6 className="card-title mb-0">
                          Manually Integrate -{" "}
                          {!isEmpty(row.rawMaterials) &&
                            row.rawMaterials.excelData.fileData.length}
                          {!isEmpty(row.products) &&
                            row.products.excelData.fileData.length}
                        </h6>
                      </div>
                      <div className="m-content">
                        {this.props.title === "Suppliers" &&
                          row.rawMaterials.excelData.fileData.map(
                            (rawMaterial, rindex) => (
                              <div className="card-body" key={rindex}>
                                <div className="title-header">
                                  <h6 className="title-bg">
                                    Import excel sheet {rindex + 1}
                                  </h6>
                                </div>
                                <div className="text-small">
                                  Name of Raw Material
                                </div>
                                <div className="sub-text">
                                  {rawMaterial.name ? rawMaterial.name : ""}
                                </div>
                                <hr className="my-1" />

                                <div className="text-small">
                                  Raw Material Id
                                </div>
                                <div className="sub-text">
                                  {rawMaterial.rawMaterialId
                                    ? rawMaterial.rawMaterialId
                                    : ""}
                                </div>
                                <hr className="my-1" />
                                <div className="text-small">
                                  Uploaded Raw Material image
                                </div>
                                <div className="sub-text">
                                  Stabilizers - gelatin
                                </div>
                                <hr className="my-1" />

                                <div className="text-small">
                                  Raw Material Units
                                </div>
                                <div className="sub-text">
                                  {rawMaterial.units}
                                </div>
                                <hr className="my-1" />
                                <div className="text-small">Quantity</div>
                                <div className="sub-text">
                                  {rawMaterial.quantity
                                    ? rawMaterial.quantity
                                    : ""}
                                </div>
                                <hr className="my-1" />
                                <div className="text-small">Date</div>
                                <div className="sub-text">
                                  {rawMaterial.date ? rawMaterial.date : ""}
                                </div>
                                {/* <hr className="my-1" />
                              <div className="text-small">Time</div>
                              <div className="sub-text">10 AM</div> */}
                              </div>
                            )
                          )}

                        {(this.props.title === "Manufacturers" ||
                          this.props.title === "Logistics" ||
                          this.props.title === "Distributors" ||
                          this.props.title === "Retailers") &&
                          row.products.excelData.fileData.map(
                            (product, rindex) => (
                              <div className="card-body" key={rindex}>
                                <div className="title-header">
                                  <h6 className="title-bg">
                                    Import excel sheet {rindex + 1}
                                  </h6>
                                </div>
                                <div className="text-small">Product Name</div>
                                <div className="sub-text">
                                  {product.productName
                                    ? product.productName
                                    : ""}
                                </div>
                                <hr className="my-1" />

                                <div className="text-small">Product Id</div>
                                <div className="sub-text">
                                  {product.productId ? product.productId : ""}
                                </div>
                                <hr className="my-1" />

                                <div className="text-small">Product Type</div>
                                <div className="sub-text">
                                  {product.productType}
                                </div>
                                <hr className="my-1" />
                                <div className="text-small">
                                  Product Category
                                </div>
                                <div className="sub-text">
                                  {product.productCategory}
                                </div>
                                <hr className="my-1" />
                                <div className="text-small">
                                  Uploaded Product image
                                </div>
                                <div className="sub-text">
                                  Stabilizers - gelatin
                                </div>
                              </div>
                            )
                          )}
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      ));
    }

    return (
      <div>
        <div
          className={this.props.show ? "modal fade show" : "modal fade hide"}
          tabIndex={-1}
          role="dialog"
          style={{ display: "block", overflowY: "visible" }}
        >
          <div
            className="modal-dialog modal-xl modal-dialog-top"
            role="document"
          >
            <div className="modal-content">
              <div className="modal-header">
                <h5 className="modal-title">
                  View {this.props.title.slice(0, -1)} Details
                </h5>
                <button
                  type="button"
                  className="close btn btn-round"
                  data-dismiss="modal"
                  aria-label="Close"
                  onClick={this.props.onClose}
                >
                  {" "}
                  <i className="material-icons">close</i>{" "}
                </button>
              </div>
              <div className="modal-body pt-1">
                <div className="text-dark font-weight-bolder">
                  Total {this.props.title} in your Inventory :{" "}
                  <span>{this.state.inventoryData.length}</span>{" "}
                </div>
                <div
                  className={
                    this.state.inventoryData.length > 4 ||
                    !isEmpty(this.state.accordianIndex)
                      ? "m-content"
                      : ""
                  }
                >
                  {displayData}
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Required vendor scripts (Do not remove) */}
        {/* Autosize - resizes textarea inputs as user types */}
        {/* Required theme scripts (Do not remove) */}
      </div>
    );
  }
}
