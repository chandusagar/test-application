import React, { Component } from "react";
import { withRouter } from "react-router-dom";
import { connect } from "react-redux";
import SweetAlert from "react-bootstrap-sweetalert";

/** Import util components */
import isEmpty from "../../../utils/isEmpty";

/** Import Services */
import { qrCodeServices } from "../../../services/qrCodeServices";
/**Import qr actions */
import {
  changeAlertSuccessMessage,
  changeAlertErrorMessage,
} from "../../../actions/qrAction";

class DeleteMyInventoriesModal extends Component {
  constructor() {
    super();
    this.state = {
      showCancelOrderModal: false,
      inventoryData: [],
      alertSuccessMessage: "",
      alertErrorMessage: "",
      successpopup: {},
    };
  }

  componentDidMount() {
    this.getInventoriesDataForDelete();
  }

  componentDidUpdate(prevProps) {
    if (
      prevProps.qrOrder.alertSuccessMessage !==
      this.props.qrOrder.alertSuccessMessage
    ) {
      this.setState({
        alertSuccessMessage: this.props.qrOrder.alertSuccessMessage,
      });
    }

    if (
      prevProps.qrOrder.alertErrorMessage !==
      this.props.qrOrder.alertErrorMessage
    ) {
      this.setState({
        alertErrorMessage: this.props.qrOrder.alertErrorMessage,
      });
    }
  }

  /**Get suppliers/manufacturers/logistics/distributors/retailers data */
  getInventoriesDataForDelete = async () => {
    const inventoryData = await qrCodeServices.getInventoriesDataForDelete(
      this.props.title
    );
    this.setState({ inventoryData });
  };

  // Select inventory
  handleCheckBox = async (index, checked) => {
    const inventoryData = this.state.inventoryData;
    inventoryData[index].isChecked = checked;

    this.setState(inventoryData);
  };

  // Delete selected inventory data
  deleteSelectedData = async () => {
    const ids = [];
    this.state.inventoryData.forEach((inventory) => {
      if (!isEmpty(inventory.isChecked) && inventory.isChecked) {
        ids.push(inventory._id);
      }
    });

    if (ids.length > 0) {
      const saveResult = await qrCodeServices.deleteSelectedInventoriesData(
        this.props.title,
        ids
      );

      if (!isEmpty(saveResult) && saveResult.isError === false) {
        let successpopup = saveResult;
        this.setState({ successpopup });
      } else {
        let successpopup = saveResult;
        let errors = saveResult;
        this.setState({ errors, successpopup });
      }
    } else {
      let errors = {
        isError: true,
        message: `Please select atleast one ${this.props.title.slice(0, -1)}`,
      };

      let successpopup = errors;
      this.setState({ errors, successpopup });
    }
  };

  hideAlert = () => {
    if (!isEmpty(this.state.successpopup) && !this.state.successpopup.isError) {
      this.props.onClose();
    }
    this.setState({ successpopup: {} });
  };

  /**show sweet alert popup */
  getAlert = () => {
    if (!isEmpty(this.state.successpopup) && !this.state.successpopup.isError) {
      return (
        <SweetAlert
          success
          title="Success"
          onConfirm={() => this.hideAlert()}
          btnSize="md"
        >
          {this.state.successpopup.message}
        </SweetAlert>
      );
    } else if (
      !isEmpty(this.state.successpopup) &&
      this.state.successpopup.isError
    ) {
      return (
        <SweetAlert
          error
          title="Error"
          onConfirm={() => this.hideAlert()}
          btnSize="md"
        >
          {this.state.successpopup.message}
        </SweetAlert>
      );
    }
  };

  render() {
    const succes = {
      paddingLeft: "35%",
      paddingRight: "36%",
    };

    let displayData = (
      <div>
        <span>Data not found</span>
      </div>
    );

    if (!isEmpty(this.state.inventoryData)) {
      displayData = this.state.inventoryData.map((row, index) => (
        <div className="accordion mt-1" id="accordion-7" key={index}>
          <div className="card m-0">
            <div className="card-header" id="headingOne">
              <div className="checkbox">
                <label
                  data-toggle="collapse"
                  data-target="#collapseOne"
                  aria-expanded="false"
                  aria-controls="collapseOne"
                >
                  <input
                    type="checkbox"
                    value={row.isChecked}
                    onChange={() => this.handleCheckBox(index, !row.isChecked)}
                    checked={row.isChecked}
                  />
                </label>
                {this.props.title.slice(0, -1)}_{index + 1}
                <div className="sup-details-del">
                  <label className="ml-7">
                    Name of the {this.props.title.slice(0, -1)} :{" "}
                    <span className="sub-txt-header">
                      {row.basicDetails.name} ({row.basicDetails.emailId})
                    </span>
                  </label>
                </div>
              </div>
            </div>
          </div>
        </div>
      ));
    }

    return (
      <div
        className={this.props.show ? "modal fade show" : "modal fade hide"}
        tabIndex={-1}
        role="dialog"
        style={{ display: "block", overflowY: "visible" }}
      >
        {/* sweet alert popup */}
        {!isEmpty(this.state.successpopup) ? this.getAlert() : ""}
        {/* End sweet alert popup */}
        <div className="modal-dialog modal-xl modal-dialog-top" role="document">
          {!isEmpty(this.state.alertSuccessMessage) ? (
            <div className="alert alert-success bg-success text-white alert-dismissible success_popup">
              <button type="button" className="close">
                &times;
              </button>
              <div className="text-center" style={succes}>
                {this.state.alertSuccessMessage}
              </div>
            </div>
          ) : !isEmpty(this.state.alertErrorMessage) ? (
            <div className="alert alert-danger bg-danger text-white alert-dismissible success_popup">
              <button type="button" className="close">
                &times;
              </button>
              <div className="text-center" style={succes}>
                {this.state.alertErrorMessage}
              </div>
            </div>
          ) : (
            ""
          )}
          <div className="modal-content">
            <div className="modal-header">
              <h5 className="modal-title">
                Delete {this.props.title.slice(0, -1)} Details
              </h5>
              <button
                type="button"
                className="close btn btn-round"
                data-dismiss="modal"
                aria-label="Close"
                onClick={this.props.onClose}
              >
                {" "}
                <i className="material-icons">close</i>{" "}
              </button>
            </div>
            <div className="modal-body del-cont pt-1">
              <div className="text-dark font-weight-bolder">
                Total {this.props.title} in your Inventory :{" "}
                <span>{this.state.inventoryData.length}</span>{" "}
              </div>
              {/*		  <div class="text-danger font-weight-bold text-small">You haved Selected <span>2</span>&nbsp;supplier to delete</div>*/}
              <div
                className={
                  this.state.inventoryData.length > 4 ? "m-content" : ""
                }
              >
                {displayData}
              </div>

              <div className="" style={{ padding: "0.5rem 0 1rem 0" }}>
                <button
                  type="submit"
                  onClick={this.deleteSelectedData}
                  className="btn btn-danger px-3"
                >
                  Delete
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }
}

const mapStateToProps = (state) => ({
  qrOrder: state.qrOrder,
});

export default connect(mapStateToProps, {
  changeAlertSuccessMessage,
  changeAlertErrorMessage,
})(withRouter(DeleteMyInventoriesModal));
