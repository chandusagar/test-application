import React, { Component } from "react";
import { withRouter } from "react-router-dom";
import { connect } from "react-redux";

/** Import util components */
import isEmpty from "../../../utils/isEmpty";

/** Import Services */
import { qrCodeServices } from "../../../services/qrCodeServices";

class CancelOrderModal extends Component {
  constructor(props) {
    super(props);
  }

  cancelOrder = async () => {
    const result = await qrCodeServices.cancelOrder(
      this.props.cancelUrlFrom,
      this.props.orderId
    );
    if (!isEmpty(result) && result.isError === false) {
      alert("Your Order has been cancelled successfully!");
      if (this.props.cancelUrlFrom === "Package") {
        this.props.history.push("/packageqrcodeorders");
      } else {
        this.props.history.push("/supplierqrcodeorders");
      }
    } else {
      alert("Something wrong, Please try again!");
    }
  };

  render() {
    return (
      // <div className="modal fade" id="modal_01" tabIndex={-1} role="dialog">
      <div
        className={this.props.show ? "modal fade show" : "modal fade hide"}
        tabIndex={-1}
        role="dialog"
        style={{ display: "block", overflowY: "visible" }}
      >
        <div className="modal-dialog modal-dialog-centered" role="document">
          <div className="modal-content">
            <div className="modal-header">
              <h5 className="modal-title">Cancel Order</h5>
              <button
                type="button"
                className="close btn btn-round"
                data-dismiss="modal"
                aria-label="Close"
                onClick={this.props.onClose}
              >
                {" "}
                <i className="material-icons">close</i>{" "}
              </button>
            </div>
            <div className="modal-body">
              <p>Are you sure you want to cancel this order?</p>
            </div>
            <div className="modal-footer">
              <button
                type="button"
                className="btn btn-primary-ghost"
                data-dismiss="modal"
                onClick={this.props.onClose}
              >
                No
              </button>
              <button
                onClick={this.cancelOrder}
                type="button"
                className="btn btn-danger"
              >
                Yes
              </button>
            </div>
          </div>
        </div>
      </div>
    );
  }
}

const mapStateToProps = (state) => ({});

export default connect(mapStateToProps, {})(withRouter(CancelOrderModal));
