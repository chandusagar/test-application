import React, { Component } from "react";
import { withRouter, Link } from "react-router-dom";
import { connect } from "react-redux";

import { changeQRActiveTabs } from "../../../actions/qrAction";

class CustomTabs extends Component {
  constructor(props) {
    super(props);
  }

  componentDidMount() {
    this.props.changeQRActiveTabs("Create");
  }

  //Change tab navigation
  changeActiveTabs = (tabName) => {
    this.props.changeQRActiveTabs(tabName);
  };

  render() {
    const activeTab = this.props.qrOrder.qrTab;

    return (
      <div className="qr-custom-tabs">
        <ul className="nav nav-pills" id="pills-tab" role="tablist">
          <li className="nav-item">
            <a
              onClick={() => this.changeActiveTabs("Create")}
              className={
                activeTab === "Create" ? "nav-link active" : "nav-link"
              }
              id="pills-qr-tab"
              data-toggle="pill"
              role="tab"
              aria-controls="pills-qr"
              aria-selected="true"
            >
              Order QR codes
            </a>
          </li>
          <li className="nav-item">
            <a
              onClick={() => this.changeActiveTabs("Active")}
              className={
                activeTab === "Active" ? "nav-link active" : "nav-link"
              }
              id="pills-active-tab"
              data-toggle="pill"
              role="tab"
              aria-controls="pills-active"
              aria-selected="false"
            >
              Activate QR codes
            </a>
          </li>
          <li className="nav-item">
            <a
              onClick={() => this.changeActiveTabs("Deliver")}
              className={
                activeTab === "Deliver" ? "nav-link active" : "nav-link"
              }
              id="pills-deliver-tab"
              data-toggle="pill"
              role="tab"
              aria-controls="pills-deliver"
              aria-selected="false"
            >
              Deliver QR codes
            </a>
          </li>
          <li className="nav-item">
            <a
              onClick={() => this.changeActiveTabs("History")}
              className={
                activeTab === "History" ? "nav-link active" : "nav-link"
              }
              id="pills-order-tab"
              data-toggle="pill"
              role="tab"
              aria-controls="pills-order"
              aria-selected="false"
            >
              My Order History
            </a>
          </li>
        </ul>
      </div>
    );
  }
}

const mapStateToProps = (state) => ({
  qrOrder: state.qrOrder,
});

export default connect(mapStateToProps, { changeQRActiveTabs })(
  withRouter(CustomTabs)
);
