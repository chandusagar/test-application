import React, { Component } from "react";
import { Link } from "react-router-dom";

export default class HeaderText extends Component {
  render() {
    return (
      <div className="main-container">
        <div className="breadcrumb-bar navbar bg-white sticky-top">
          <nav aria-label="breadcrumb">
            <ol className="breadcrumb">
              <li className="breadcrumb-item">
                <Link to="/dashboard">
                  <a href="home-page.html">Home</a>{" "}
                </Link>
              </li>
              <li className="breadcrumb-item active" aria-current="page">
                {this.props.textName}
              </li>
            </ol>
          </nav>
          {this.props.textName === "My Inventories" ? (
            <Link to="/supplier">
              <button className="btn p-1 green-btn">
                <i className="fa fa-plus-circle mr-1" />
                On Board Inventory
              </button>
            </Link>
          ) : (
            ""
          )}
        </div>
      </div>
    );
  }
}
