import React from "react";

class Settings extends React.Component {
  render() {
    return (
      <div className="">
        <div className="row">
          <div className="col-12">
            <div className="mt-3">Settings</div>
          </div>
        </div>
      </div>
    );
  }
}

export default Settings;
