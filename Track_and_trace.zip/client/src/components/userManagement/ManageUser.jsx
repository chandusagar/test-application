import React from "react";
import { withRouter, Link } from "react-router-dom";
import Adduser from "./users/Adduser";
import Userlist from "./users/UserList";
import DashBoardHeader from "../layout/DashBoardHeader";

import services from "../../services";

import isEmpty from "../../utils/isEmpty";

class Manageuser extends React.Component {
  state = {
    activeStep: 1,
    user: {},
    userName: "Ravi",
    teamFirstName: "Dodla dairy",
    teamLastName: "Team",
  };

  componentDidMount() {
    this.setData();
  }

  setData = () => {
    let respData = services.userManagementServices.setCurrentUser();
    let user = JSON.parse(respData);
    this.setState({ user });
  };

  activeTab = (step) => {
    this.setState({
      activeStep: step,
    });
  };

  render() {
    const organizationId = (string) => {
      return string.charAt(0).toUpperCase() + string.slice(0, 0);
    };

    return (
      <div className="wrapper">
        <div className="content-page">
          <div className="content">
            <div className="topnav-navbar topnav-navbar-dark">
              <DashBoardHeader />
            </div>
            <div className="sub-tabs">
              <div className="container">
                <div className="py-3">Manage Users</div>
                <div className="team-title">
                  <span className="team-badge">
                    {this.state.user && this.state.user.organizationId
                      ? organizationId(
                          this.state.user.organizationId.companyName
                        )
                      : ""}
                  </span>
                  {/* Dodla dairy Team */}
                  <span className="team-name">
                    {this.state.user && this.state.user.organizationId
                      ? `${this.state.user.organizationId.companyName}`
                      : ""}
                  </span>
                </div>
                <div className="custom-tabs">
                  <ul className="nav nav-pills" id="pills-tab" role="tablist">
                    <li className="nav-item">
                      <a
                        className={
                          this.state.activeStep === 1
                            ? "nav-link active"
                            : "nav-link"
                        }
                        id="pills-user-tab"
                        onClick={() => this.activeTab(1)}
                      >
                        User
                      </a>
                    </li>
                    <li className="nav-item">
                      <a
                        className={
                          this.state.activeStep === 2
                            ? "nav-link active"
                            : "nav-link"
                        }
                        id="pills-add-tab"
                        onClick={() => this.activeTab(2)}
                      >
                        Add Users
                      </a>
                    </li>
                  </ul>
                </div>
              </div>
            </div>
            <div className="container">
              <div className="tab-content" id="pills-tabContent">
                {this.state.activeStep === 1 ? (
                  <Userlist />
                ) : this.state.activeStep === 2 ? (
                  <Adduser onSave={() => this.activeTab(1)} />
                ) : (
                  ""
                )}
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }
}

export default Manageuser;
