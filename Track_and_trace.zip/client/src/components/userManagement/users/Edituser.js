import React from "react";
import Validator from "validator";
import SweetAlert from "react-bootstrap-sweetalert";

import SelectComponent from "../../common/SelectComponent";
import TextFieldGroup from "../../common/TextFieldGroup";

import isEmpty from "../../../utils/isEmpty";

import services from "../../../services";

class Edituser extends React.Component {
  state = {
    firstName: "",
    lastName: "",
    email: "",
    assignTo: "",
    roleId: "",
    categoryName: "",
    phone: "",
    data: {},
    errors: {},
    successpopup: {},
  };

  componentDidMount() {
    this.setUser();
    this.allServiceList();
  }

  setUser = () => {
    this.setState((prevState) => {
      prevState = this.props.editDetails ? this.props.editDetails : "";
      prevState.phone = this.props.editDetails.phone.toString();
      return prevState;
    });
  };

  allServiceList = async () => {
    let data = JSON.parse(JSON.stringify(this.state.data));

    await services.userManagementServices.getCategory().then((resp) => {
      data.category = resp;
      this.setState({ data });
    });

    await services.userManagementServices.getRoles().then((resp) => {
      data.roles = resp;
      this.setState({ data });
    });

    if (!isEmpty(this.state.categoryName)) {
      this.comapyLists(this.state.categoryName);
    }
  };

  /**role names list function */
  roleNames = () => {
    let roleArr = [];
    let roles =
      this.state.data && this.state.data.roles ? this.state.data.roles : [];

    roles.forEach((item) => {
      let obj = {
        name: item.name,
        value: item._id,
        rolePermissions: item.rolePermissions,
        created: item.created,
      };
      roleArr.push(obj);
    });
    return roleArr;
  };

  /**catagiry names list function */
  categoryNames = () => {
    let categoryArr = [];
    let category =
      this.state.data && this.state.data.category
        ? this.state.data.category
        : [];
    category.forEach((item) => {
      let obj = {
        value: item.category_name,
        name: item.category_name,
      };
      categoryArr.push(obj);
    });
    return categoryArr;
  };

  /**AsignTo names list function */
  assignToList = () => {
    let companyArr = [];
    let assignNames =
      this.state.data && this.state.data.companyList
        ? this.state.data.companyList
        : [];
    assignNames.forEach((item) => {
      let obj = {
        value: item._id,
        name: `${item.basicDetails.name} (${item.basicDetails.emailId})`,
      };
      companyArr.push(obj);
    });
    return companyArr;
  };

  comapyLists = (name) => {
    let data = JSON.parse(JSON.stringify(this.state.data));
    services.userManagementServices.companyList(name).then((resp) => {
      data.companyList = resp;
      this.setState({ data });
    });
  };

  onChange = (e) => {
    const { name, value } = e.target;
    if (name === "categoryName") {
      this.comapyLists(value);
    }

    this.setState({ [name]: value, errors: {} }, async () => {
      this.validateForm({ key: name });
    });
  };

  saveDetails = async (e) => {
    e.preventDefault();
    if (this.validateForm({ submitted: true })) {
      const formData = Object.assign({}, this.state);
      delete formData.errors;
      delete formData.data;
      let _id = this.props.editDetails._id;
      services.userManagementServices
        .editUser(_id, formData)
        .then((success) => {
          let successpopup = success;
          this.setState({ successpopup });
          // alert(success.message);
        })
        .catch((err) => {
          let errors = err;
          let successpopup = err;
          this.setState({ errors, successpopup });
        });
    }
  };

  hideAlert = () => {
    if (!isEmpty(this.state.successpopup) && !this.state.successpopup.isError) {
      this.allServiceList();
      this.props.onCancel();
    }
    this.setState({ successpopup: {} });
  };

  /**show sweet alert popup */
  getAlert = () => {
    if (!isEmpty(this.state.successpopup) && !this.state.successpopup.isError) {
      return (
        <SweetAlert
          success
          title="Success"
          onConfirm={() => this.hideAlert()}
          btnSize="md"
        >
          {this.state.successpopup.message}
        </SweetAlert>
      );
    } else if (
      !isEmpty(this.state.successpopup) &&
      this.state.successpopup.isError
    ) {
      return (
        <SweetAlert
          error
          title="Error"
          onConfirm={() => this.hideAlert()}
          btnSize="md"
        >
          {this.state.successpopup.message}
        </SweetAlert>
      );
    }
  };

  validateForm = ({ key = null, submitted = false }) => {
    const errors = {};

    if (isEmpty(this.state.firstName) && (key === "firstName" || submitted)) {
      errors.firstName = "First name is required.";
    } else if (
      this.state.firstName &&
      !Validator.isLength(this.state.firstName, { min: 3, max: 30 })
    ) {
      errors.firstName = "First name should have minimum 3 characters.";
    }

    if (this.state.firstName && !Validator.isAlpha(this.state.firstName)) {
      errors.firstName = "First name Invalid.";
    }

    if (isEmpty(this.state.lastName) && (key === "lastName" || submitted)) {
      errors.lastName = "Last name is required.";
    } else if (
      this.state.lastName &&
      !Validator.isLength(this.state.lastName, { min: 3, max: 30 })
    ) {
      errors.lastName = "Last name should have minimum 3 characters.";
    }

    if (this.state.lastName && !Validator.isAlpha(this.state.lastName)) {
      errors.lastName = "Last name Invalid.";
    }

    if (isEmpty(this.state.email) && (key === "email" || submitted)) {
      errors.email = "Email id required";
    }
    if (this.state.email && !Validator.isEmail(this.state.email)) {
      errors.email = "Email is invalid";
    }

    if (isEmpty(this.state.assignTo) && (key === "assignTo" || submitted)) {
      errors.assignTo = "Assign to is required.";
    }

    if (isEmpty(this.state.roleId) && (key === "roleId" || submitted)) {
      errors.roleId = "Role is required.";
    }

    if (
      isEmpty(this.state.categoryName) &&
      (key === "categoryName" || submitted)
    ) {
      errors.categoryName = "Category is required.";
    }

    if (isEmpty(this.state.phone) && (key === "phone" || submitted)) {
      errors.phone = "Phone number is required.";
    } else if (
      this.state.phone &&
      (!Validator.isDecimal(this.state.phone) ||
        !Validator.isMobilePhone(this.state.phone, "en-IN"))
    ) {
      errors.phone = "Phone number is Invalid.";
    } else if (
      this.state.phone &&
      !Validator.isLength(this.state.phone, { min: 10, max: 10 })
    ) {
      errors.phone = "Phone number should have minimum 10 numbers.";
    }

    this.setState({ errors });
    return isEmpty(errors);
  };

  render() {
    const { errors } = this.state;
    return (
      <div
        className={this.props.show ? "modal fade show" : "modal fade hide"}
        id="modal_02"
        tabindex="-1"
        role="dialog"
        aria-hidden="true"
        style={{ display: "block" }}
      >
        {/* sweet alert popup */}
        {!isEmpty(this.state.successpopup) ? this.getAlert() : ""}
        {/* End sweet alert popup */}
        <div
          className="modal-dialog modal-xl modal-dialog-centered"
          role="document"
        >
          <div className="modal-content">
            <div className="modal-header">
              <h5 className="modal-title">Edit User Details</h5>
              <button
                type="button"
                className="close btn btn-round"
                data-dismiss="modal"
                aria-label="Close"
                onClick={() => this.props.onCancel()}
              >
                <i className="material-icons">close</i>
              </button>
            </div>
            <div className="modal-body">
              <div className="mb-2">
                <div className="row">
                  <div className="col-md-12">
                    <div className="form-row">
                      <div className="form-group col-md-6">
                        <TextFieldGroup
                          label="First Name"
                          type="text"
                          name="firstName"
                          value={this.state.firstName}
                          onChange={this.onChange}
                          maxlength={"30"}
                          placeholder="First name"
                          error={errors && errors.firstName}
                        />
                      </div>
                      <div className="form-group col-md-6">
                        <TextFieldGroup
                          label="Last Name"
                          type="text"
                          name="lastName"
                          value={this.state.lastName}
                          onChange={this.onChange}
                          maxlength={"30"}
                          placeholder="Last name"
                          error={errors && errors.lastName}
                        />
                      </div>
                    </div>
                  </div>
                </div>
                <div className="row">
                  <div className="col-md-12">
                    <div className="form-row">
                      <div className="form-group col-md-3">
                        <TextFieldGroup
                          label="Email id"
                          type="email"
                          name="email"
                          value={this.state.email}
                          onChange={this.onChange}
                          disabled={true}
                          placeholder="Email id"
                          error={errors && errors.email}
                        />
                      </div>
                      <div className="form-group col-md-3">
                        <TextFieldGroup
                          label="Phone / Mobile Number"
                          type="text"
                          name="phone"
                          value={this.state.phone}
                          onChange={this.onChange}
                          maxlength="10"
                          placeholder="Phone / Mobile Number"
                          error={errors && errors.phone}
                        />
                      </div>
                      <div className="form-group col-md-6">
                        <SelectComponent
                          label="Category"
                          onChange={this.onChange}
                          options={this.categoryNames()}
                          name="categoryName"
                          value={this.state.categoryName}
                          error={errors && errors.categoryName}
                        />
                      </div>
                    </div>
                  </div>
                </div>
                <div className="row">
                  <div className="col-md-12">
                    <div className="form-row">
                      <div className="form-group col-md-6">
                        <SelectComponent
                          label="Assign To"
                          onChange={this.onChange}
                          options={this.assignToList()}
                          name="assignTo"
                          value={this.state.assignTo}
                          error={errors && errors.assignTo}
                        />
                      </div>
                      <div className="form-group col-md-6">
                        <SelectComponent
                          label="Role"
                          onChange={this.onChange}
                          options={this.roleNames()}
                          name="roleId"
                          value={this.state.roleId}
                          error={errors && errors.roleId}
                        />
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div className="modal-footer">
              <button
                type="button"
                className="btn btn-primary-ghost"
                data-dismiss="modal"
                onClick={() => this.props.onCancel()}
              >
                Cancel
              </button>
              <button
                type="submit"
                className="btn btn-primary"
                onClick={this.saveDetails}
              >
                Update
              </button>
            </div>
          </div>
        </div>
      </div>
    );
  }
}

export default Edituser;
