import React from "react";
import SweetAlert from "react-bootstrap-sweetalert";

import DataTable from "../DataTable";
import Edituser from "./Edituser";

import services from "../../../services";
import isEmpty from "../../../utils/isEmpty";

class Userlist extends React.Component {
  state = {
    show: false,
    data: {},
    editDetails: {},
    column: [
      { field: "_id", header: "S No" },
      { field: "userName", header: "User Name" },
      { field: "phone", header: "Contact Number" },
      { field: "roleId", header: "Role" },
      { field: "categoryName", header: "Category Name" },
      { field: "companyName", header: "Company Name" },
      { field: "created", header: "Created On" },
      { field: "Actions", header: "Actions" },
    ],
    details: [],
    successpopup: {},
  };

  componentDidMount() {
    this.allServiceList();
  }

  allServiceList = async () => {
    let data = JSON.parse(JSON.stringify(this.state.data));

    services.userManagementServices.getUser().then((resp) => {
      this.setState({ details: resp });
    });

    services.userManagementServices.getRoles().then((resp) => {
      data.roles = resp;
      this.setState({ data });
    });

    services.userManagementServices.getCategory().then((resp) => {
      data.category = resp;
      this.setState({ data });
    });
  };

  roleName = (value) => {
    let roleArr = [];
    let role =
      this.state.data && this.state.data.roles ? this.state.data.roles : [];
    role.forEach((item) => {
      if (item._id == value) {
        roleArr.push(item.name);
      }
    });
    return roleArr;
  };

  /**catagiry names list function */
  categoryNames = (value) => {
    let category = [];
    let categoryArr =
      this.state.data && this.state.data.category
        ? this.state.data.category
        : [];

    categoryArr.forEach((item) => {
      if (item._id == value) {
        category.push(item.category_name);
      }
    });
    return category;
  };

  modifyColums = (rowData, col) => {
    switch (col.field) {
      case "_id":
        return <span className="token-anchor">{rowData._id}</span>;
      case "userName":
        return (
          <span className="token-anchor">
            {`${rowData.firstName} ${rowData.lastName}`}
            <div className="token-anchor">{rowData.email}</div>
          </span>
        );

      case "companyName":
        return (
          <span className="token-anchor">
            {!isEmpty(rowData.organizationId)
              ? rowData.organizationId.companyName
              : ""}
            <div>{rowData.status}</div>
          </span>
        );

      // case "categoryName":
      //   return (
      //     <span className="token-anchor">
      //       {this.categoryNames(rowData.categoryName)}
      //       <div>{rowData.status}</div>
      //     </span>
      //   );

      case "roleId":
        return (
          <span className="token-anchor">
            {this.roleName(rowData.roleId)}
            <div>{rowData.status}</div>
          </span>
        );

      case "Actions":
        return (
          <span>
            <button
              className="btn action-button"
              data-toggle="modal"
              data-target="#modal_02"
              onClick={(e) => this.viewDetails(e, rowData)}
            >
              <i className="fa fa-edit"></i>
            </button>
            <button
              className="btn action-button"
              data-toggle="modal"
              data-target="#modal_01"
              onClick={(e) => this.deleteView(e, rowData)}
            >
              <i className="fa fa-trash"></i>
            </button>
          </span>
        );

      default:
        return rowData[col.field];
    }
  };

  /**edit user popup function*/
  viewDetails = (e, rowData) => {
    this.setState({
      show: true,
      editDetails: rowData,
    });
  };

  /**delete user popup function */
  deleteView = (e, rowData) => {
    this.setState({
      editDetails: rowData,
    });
  };

  /**user delete function */
  deleteUser = () => {
    let _id = this.state.editDetails._id;
    services.userManagementServices
      .deleteUser(_id)
      .then((success) => {
        let successpopup = success;
        this.setState({ successpopup });
        // this.onCancel();
        // this.allServiceList();
      })
      .catch((error) => {
        let successpopup = error;
        this.setState({ successpopup });
      });
  };

  hideAlert = () => {
    if (!isEmpty(this.state.successpopup) && !this.state.successpopup.isError) {
      this.allServiceList();
    }
    this.setState({ successpopup: {} });
  };

  /**show sweet alert popup */
  getAlert = () => {
    if (!isEmpty(this.state.successpopup) && !this.state.successpopup.isError) {
      return (
        <SweetAlert
          success
          title="Success"
          onConfirm={() => this.hideAlert()}
          btnSize="md"
        >
          {this.state.successpopup.message}
        </SweetAlert>
      );
    } else if (
      !isEmpty(this.state.successpopup) &&
      this.state.successpopup.isError
    ) {
      return (
        <SweetAlert
          error
          title="Error"
          onConfirm={() => this.hideAlert()}
          btnSize="md"
        >
          {this.state.successpopup.message}
        </SweetAlert>
      );
    }
  };

  /**edit user cancel popup function */
  onCancel = (step) => {
    this.setState({
      show: step,
    });
    // this.allServiceList();
  };

  render() {
    return (
      <div className=" " id="pills-user">
        {/* sweet alert popup */}
        {!isEmpty(this.state.successpopup) ? this.getAlert() : ""}
        {/* End sweet alert popup */}
        <div className="row">
          <div className="col-md-12">
            <div className="mt-3">List of Users</div>
          </div>
        </div>
        <div className="custom-table mt-1">
          <DataTable
            respData={this.state.details}
            column={this.state.column}
            modifyColums={(rowData, col) => this.modifyColums(rowData, col)}
          />

          {this.state.show ? (
            <Edituser
              show={this.state.show}
              editDetails={this.state.editDetails}
              onCancel={() => this.onCancel(false)}
            />
          ) : (
            ""
          )}

          <div className="modal fade" id="modal_01" tabindex="-1" role="dialog">
            <div className="modal-dialog modal-dialog-centered" role="document">
              <div className="modal-content">
                <div className="modal-header">
                  <h5 className="modal-title">Delete User</h5>
                  <button
                    type="button"
                    className="close btn btn-round"
                    data-dismiss="modal"
                    aria-label="Close"
                  >
                    <i className="material-icons">close</i>
                  </button>
                </div>
                <div className="modal-body">
                  <p>
                    Are you sure you want to Delete this User_
                    {this.state.editDetails._id} ?
                  </p>
                </div>
                <div className="modal-footer">
                  <button
                    type="button"
                    className="btn btn-primary-ghost"
                    data-dismiss="modal"
                  >
                    Cancel
                  </button>
                  <button
                    type="button"
                    className="btn btn-danger"
                    data-dismiss="modal"
                    onClick={() => this.deleteUser()}
                  >
                    Delete
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }
}

export default Userlist;
