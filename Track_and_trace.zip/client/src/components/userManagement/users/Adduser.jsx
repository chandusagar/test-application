import React from "react";
import Validator from "validator";
import SweetAlert from "react-bootstrap-sweetalert";

import SelectComponent from "../../common/SelectComponent";
import TextFieldGroup from "../../common/TextFieldGroup";

import isEmpty from "../../../utils/isEmpty";

import services from "../../../services";

class Adduser extends React.Component {
  state = {
    firstName: "",
    lastName: "",
    email: "",
    assignTo: "",
    roleId: "",
    organizationId: "",
    categoryName: "",
    phone: "",
    data: {},
    errors: {},
    successpopup: {},
  };

  // categoryName
  // roleId

  componentDidMount() {
    this.getUserData();
    this.allServiceList();
  }

  getUserData = () => {
    let respData = services.userManagementServices.setCurrentUser();
    let user = JSON.parse(respData);
    this.setState({ user, organizationId: user.organizationId._id });
  };

  allServiceList = async () => {
    let data = JSON.parse(JSON.stringify(this.state.data));

    services.userManagementServices.getCategory().then((resp) => {
      data.category = resp;
      this.setState({ data });
    });

    services.userManagementServices.getRoles().then((resp) => {
      data.roles = resp;
      this.setState({ data });
    });
  };

  /**role names list function */
  roleNames = () => {
    let roleArr = [];
    let roles =
      this.state.data && this.state.data.roles ? this.state.data.roles : [];

    roles.forEach((item) => {
      let obj = {
        name: item.name,
        value: item._id,
        rolePermissions: item.rolePermissions,
        created: item.created,
      };
      roleArr.push(obj);
    });
    return roleArr;
  };

  /**catagiry names list function */
  categoryNames = () => {
    let categoryArr = [];
    let category =
      this.state.data && this.state.data.category
        ? this.state.data.category
        : [];
    category.forEach((item) => {
      let obj = {
        value: item.category_name,
        name: item.category_name,
      };
      categoryArr.push(obj);
    });

    return categoryArr;
  };

  /**AsignTo names list function */
  assignToList = () => {
    let companyArr = [];
    let assignNames =
      this.state.data && this.state.data.assignList
        ? this.state.data.assignList
        : [];

    assignNames.forEach((item) => {
      let obj = {
        value: item._id,
        name: `${item.basicDetails.name} (${item.basicDetails.emailId})`,
      };
      companyArr.push(obj);
    });
    return companyArr;
  };

  comapyLists = (name) => {
    let data = JSON.parse(JSON.stringify(this.state.data));
    services.userManagementServices.companyList(name).then((resp) => {
      data.assignList = resp;
      this.setState({ data });
    });
  };

  onChange = (e) => {
    const { name, value } = e.target;
    if (name === "categoryName" && value !== "") {
      if (
        this.state.user.categoryName !== "Manufacturer" &&
        this.state.user.categoryName !== value
      ) {
        this.setState({
          errors: {
            categoryName: `As a ${this.state.user.categoryName}, you do not have permission to add ${value}`,
          },
        });
        return false;
      } else {
        this.comapyLists(value);
      }
    }
    this.setState({ [name]: value, errors: {} }, async () => {
      this.validateForm({ key: name });
    });
  };

  saveDetails = async (e) => {
    e.preventDefault();
    if (this.validateForm({ submitted: true })) {
      const formData = Object.assign({}, this.state);
      delete formData.errors;
      delete formData.data;
      services.userManagementServices
        .addUser(formData)
        .then((success) => {
          let successpopup = success;
          this.setState({ successpopup });
        })
        .catch((error) => {
          let errors = error;
          let successpopup = error;
          this.setState({ errors, successpopup });
        });
    }
  };

  hideAlert = () => {
    if (!isEmpty(this.state.successpopup) && !this.state.successpopup.isError) {
      this.props.onSave();
    }
    this.setState({ successpopup: {} });
  };

  /**show sweet alert popup */
  getAlert = () => {
    if (!isEmpty(this.state.successpopup) && !this.state.successpopup.isError) {
      return (
        <SweetAlert
          success
          title="Success"
          onConfirm={() => this.hideAlert()}
          btnSize="md"
        >
          {this.state.successpopup.message}
        </SweetAlert>
      );
    } else if (
      !isEmpty(this.state.successpopup) &&
      this.state.successpopup.isError
    ) {
      return (
        <SweetAlert
          error
          title="Error"
          onConfirm={() => this.hideAlert()}
          btnSize="md"
        >
          {this.state.successpopup.message}
        </SweetAlert>
      );
    }
  };

  clearDetails = () => {
    this.setState((prevState) => {
      prevState.firstName = "";
      prevState.lastName = "";
      prevState.email = "";
      prevState.assignTo = "";
      prevState.roleId = "";
      prevState.categoryName = "";
      prevState.phone = "";
      return prevState;
    });
  };

  validateForm = ({ key = null, submitted = false }) => {
    const errors = {};

    if (isEmpty(this.state.firstName) && (key === "firstName" || submitted)) {
      errors.firstName = "First name is required.";
    } else if (
      this.state.firstName &&
      !Validator.isLength(this.state.firstName, { min: 3, max: 30 })
    ) {
      errors.firstName = "First name should have minimum 3 characters.";
    }

    if (this.state.firstName && !Validator.isAlpha(this.state.firstName)) {
      errors.firstName = "First name Invalid.";
    }

    if (isEmpty(this.state.lastName) && (key === "lastName" || submitted)) {
      errors.lastName = "Last name is required.";
    } else if (
      this.state.lastName &&
      !Validator.isLength(this.state.lastName, { min: 3, max: 30 })
    ) {
      errors.lastName = "Last name should have minimum 3 characters.";
    }

    if (this.state.lastName && !Validator.isAlpha(this.state.lastName)) {
      errors.lastName = "Last name Invalid.";
    }

    if (isEmpty(this.state.email) && (key === "email" || submitted)) {
      errors.email = "Email id required";
    }
    if (this.state.email && !Validator.isEmail(this.state.email)) {
      errors.email = "Email is invalid";
    }

    if (isEmpty(this.state.assignTo) && (key === "assignTo" || submitted)) {
      errors.assignTo = "Assign to is required.";
    }

    if (isEmpty(this.state.roleId) && (key === "roleId" || submitted)) {
      errors.roleId = "Role is required.";
    }

    if (
      isEmpty(this.state.categoryName) &&
      (key === "categoryName" || submitted)
    ) {
      errors.categoryName = "Category is required.";
    }

    if (isEmpty(this.state.phone) && (key === "phone" || submitted)) {
      errors.phone = "Phone number is required.";
    } else if (
      this.state.phone &&
      (!Validator.isDecimal(this.state.phone) ||
        !Validator.isMobilePhone(this.state.phone, "en-IN"))
    ) {
      errors.phone = "Phone number is Invalid.";
    } else if (
      this.state.phone &&
      !Validator.isLength(this.state.phone, { min: 10, max: 10 })
    ) {
      errors.phone = "Phone number should have minimum 10 numbers.";
    }

    this.setState({ errors });
    return isEmpty(errors);
  };

  render() {
    const { errors } = this.state;

    return (
      <div className="" id="pills-add">
        {/* sweet alert popup */}
        {!isEmpty(this.state.successpopup) ? this.getAlert() : ""}
        {/* End sweet alert popup */}
        <div className="row">
          <div className="col-md-12">
            <div className="mt-3">Add User's Details</div>
          </div>
        </div>
        <div className="user-content mb-4">
          <form>
            <div className="row">
              <div className="col-md-12">
                <div className="form-row">
                  <div className="form-group col-md-6">
                    <TextFieldGroup
                      label="First Name"
                      type="text"
                      name="firstName"
                      value={this.state.firstName}
                      onChange={this.onChange}
                      maxlength={"30"}
                      placeholder="First name"
                      error={errors && errors.firstName}
                    />
                  </div>
                  <div className="form-group col-md-6">
                    <TextFieldGroup
                      label="Last Name"
                      type="text"
                      name="lastName"
                      value={this.state.lastName}
                      onChange={this.onChange}
                      maxlength={"30"}
                      placeholder="Last name"
                      error={errors && errors.lastName}
                    />
                  </div>
                </div>
              </div>
            </div>

            <div className="row">
              <div className="col-md-12">
                <div className="form-row">
                  <div className="form-group col-md-4">
                    <TextFieldGroup
                      label="Email id"
                      type="email"
                      name="email"
                      value={this.state.email}
                      onChange={this.onChange}
                      placeholder="Email id"
                      error={errors && errors.email}
                    />
                  </div>
                  <div className="form-group col-md-2">
                    <TextFieldGroup
                      label="Phone / Mobile Number"
                      type="text"
                      name="phone"
                      value={this.state.phone}
                      onChange={this.onChange}
                      maxlength="10"
                      placeholder="Phone / Mobile Number"
                      error={errors && errors.phone}
                    />
                  </div>
                  <div className="form-group col-md-6">
                    <SelectComponent
                      label="Category Name"
                      onChange={this.onChange}
                      options={this.categoryNames()}
                      name="categoryName"
                      value={this.state.categoryName}
                      error={errors && errors.categoryName}
                    />
                  </div>
                </div>
              </div>
            </div>

            <div className="row">
              <div className="col-md-12">
                <div className="form-row">
                  <div className="form-group col-md-6">
                    <SelectComponent
                      label="Assign To"
                      onChange={this.onChange}
                      options={this.assignToList()}
                      name="assignTo"
                      value={this.state.assignTo}
                      error={errors && errors.assignTo}
                    />
                  </div>

                  <div className="form-group col-md-6">
                    <SelectComponent
                      label="Role"
                      onChange={this.onChange}
                      options={this.roleNames()}
                      name="roleId"
                      value={this.state.roleId}
                      error={errors && errors.roleId}
                    />
                  </div>
                </div>
              </div>
            </div>
            <div className="row">
              <div className="col-md-12">
                {errors && errors.isError && (
                  <p className="text-danger user-content-btn">
                    {errors.message}
                  </p>
                )}
                <div className="user-content-btn">
                  <button
                    type="button"
                    className="btn btn-primary-ghost mr-2 px-3"
                    onClick={this.clearDetails}
                  >
                    Clear
                  </button>
                  <button
                    type="button"
                    className="btn btn-primary px-3"
                    onClick={this.saveDetails}
                  >
                    Save
                  </button>
                </div>
              </div>
            </div>
          </form>
        </div>
      </div>
    );
  }
}

export default Adduser;
