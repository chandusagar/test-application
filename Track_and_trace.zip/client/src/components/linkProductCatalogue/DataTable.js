import React from "react";
import { DataTable } from "primereact/datatable";
import { Column } from "primereact/column";
// import "./Default.css";

class DefaultTable extends React.Component {
  componentDidUpdate() {
    // this.dt.filter(this.props.productType, "_id", "in");
  }

  render() {
    const dynamicColumns = this.props.column.map((col, index) => {
      return (
        <Column
          key={col.field}
          field={col.field}
          header={col.header}
          body={
            this.props.modifyColums
              ? (rowData, col) => this.props.modifyColums(rowData, col)
              : ""
          }
          //   sortable={col.field == "Action" ? false : true}

          // filter
        />
      );
    });

    return (
      <div className="custom-table mt-1">
        <DataTable
          // ref={(el) => (this.dt = el)}
          className="table table-bordered table-sm mb-1"
          value={this.props.respData}
          emptyMessage="No records found"
          paginator={true}
          rows={10}
          rowsPerPageOptions={[10, 25, 50, 100]}
        >
          {dynamicColumns}
        </DataTable>
      </div>
    );
  }
}

export default DefaultTable;
