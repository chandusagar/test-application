import React from "react";
import SweetAlert from "react-bootstrap-sweetalert";

import DataTable from "./DataTable";
// import "./Default.css";

/**import header component */
import DashBoardHeader from "../layout/DashBoardHeader";

import { MultiSelect } from "primereact/multiselect";
import { Dropdown } from "primereact/dropdown";

/**import utility */
import isEmpty from "../../utils/isEmpty";

import services from "../../services";

class ProductLink extends React.Component {
  state = {
    id: null,
    productData: [],
    productArr: [],
    data: [{ productType: [], categoryList: [], rawMaterialData: [] }],
    column: [{ field: "_id" }],
    details: [],
    successpopup: {},
  };

  componentDidMount() {
    this.setData();
  }

  setData = () => {
    let data = JSON.parse(JSON.stringify(this.state.data));
    services.productLinkServices.productTypeList().then((resp) => {
      data[0].productType = resp;
      this.setState({ data });
    });

    services.productLinkServices.productCategories().then((resp) => {
      data[0].categoryList = resp;
      this.setState({ data });
    });
  };

  /**product type selection function */
  typeList = (e) => {
    this.listOfProduct(e.target.value);

    this.setState({ productType: e.target.value });
  };

  listOfProduct = (item) => {
    services.productLinkServices.productType(item).then((resp) => {
      this.setState({ details: resp });
      this.setcategoryList(resp, item);
    });
  };

  /**default set Data */
  setcategoryList = (details, productType) => {
    let productData = JSON.parse(JSON.stringify(this.state.productData));

    this.state.details.forEach((obj, i) => {
      productData[i] = {
        productType: productType,
        productRange: "",
        productCategory: obj._id,
        manufacturerEmailId: "",
        minProductId: "",
        maxProductId: "",
        supplier: "",
        rawMaterials: [],
      };
    });
    this.setState({ productData: productData });
  };

  /**product list  */
  productList = () => {
    let type = [];
    let productList =
      this.state.data && this.state.data[0].productType
        ? this.state.data[0].productType
        : [];
    productList.forEach((item) => {
      let obj = {
        value: item._id,
        name: item._id,
      };
      type.push(obj);
    });

    return type;
  };

  /**product releted suplier list  */
  supplierList = (id) => {
    let supplierName = [];
    let categoryList =
      this.state.data && this.state.data[0].categoryList
        ? this.state.data[0].categoryList
        : [];
    categoryList.forEach((item) => {
      let obj = {
        value: item.basicDetails.emailId,
        name: `${item.basicDetails.name} (${item.basicDetails.emailId})`,
      };
      supplierName.push(obj);
    });

    let name = null;
    if (id) {
      categoryList.forEach((item, i) => {
        if (item.value == id) {
          name = item.basicDetails.name;
        }
      });
      return name;
    } else {
      return supplierName;
    }
  };

  onChange = (e, index, id = 0) => {
    const { name, value } = e.target;

    let productData = JSON.parse(JSON.stringify(this.state.productData));
    let data = JSON.parse(JSON.stringify(this.state.data));
    let oldArr = [];
    if (name === "supplier") {
      productData[index][name] = value;
      productData[index].supplier.forEach((obj, i) => {
        const newObj = {
          supplierId: "",
          rawMaterialIds: [],
        };
        oldArr.push({ rawData: [] });
        productData[index].rawMaterials[i] = newObj;

        this.setRwaData(obj, i);
      });
    } else if (name === "rawMaterials") {
      productData[index].rawMaterials[id].supplierId =
        productData[index].supplier[id];
      productData[index].rawMaterials[id].rawMaterialIds = value;
    } else if (name === "productRange") {
      productData[index][name] = value;
      this.getProductMinAndMaxId(value, index);
    } else {
      productData[index][name] = value;
    }

    this.setState({ productData: productData, errors: {} }, async () => {
      this.validateForm({ key: name, index: index });
    });
  };

  getProductMinAndMaxId = async (range, index) => {
    let productIdRange = await services.qrCodeServices.getProductIdsRange(
      this.state.productData[index].productType,
      this.state.productData[index].productCategory,

      range
    );
    if (!isEmpty(productIdRange)) {
      this.setState((prevState) => ({
        ...prevState,
        productData: this.state.productData.map((item, productIndex) => {
          if (productIndex === index) {
            item.minProductId = productIdRange.minProductId;
            item.maxProductId = productIdRange.maxProductId;
            item.manufacturerEmailId = productIdRange.docMailId;
          }
          return item;
        }),
      }));
    }
  };

  /**raw material get list */
  setRwaData = (obj, id) => {
    let data = JSON.parse(JSON.stringify(this.state.data));

    services.productLinkServices
      .rawMaterialList(obj)
      .then((resp) => {
        data[0].rawMaterialData[id] = resp;
        this.setState({ data });
      })
      .catch((error) => {});
  };

  /**suplier related rawmaterial list */
  rawMaterialList = (id) => {
    if (!isEmpty(this.state.data[0].rawMaterialData[id])) {
      let data = this.state.data[0].rawMaterialData[id].map((item) => {
        let obj = {
          name: item.name,
          value: item.rawMaterialId,
        };
        return obj;
      });
      return data;
    } else {
      return [];
    }
  };

  /**save product list function */
  onSave = async (e, index) => {
    e.preventDefault();

    if (this.validateForm({ index: index, submitted: true })) {
      let productData = this.state.productData[index];
      delete productData.errors;
      delete productData.supplier;

      let formData = {
        peers: ["peer0.preProcessor.usecase.com"],
        fcn: "productLinkingRawMaterial",
        args: productData,
      };
      services.productLinkServices
        .saveProductLink(formData)
        .then((success) => {
          let successpopup = success;
          this.setState({
            id: null,
            productData: [],
            productArr: [],

            column: [{ field: "_id" }],
            details: [],
            successpopup: success,
          });
        })
        .catch((error) => {
          let successpopup = error;
          this.setState({ successpopup });
        });

      let productArr = JSON.parse(JSON.stringify(this.state.productArr));
      productArr[index] = productData;
      this.setState({ productArr, id: null });
    }
  };

  hideAlert = () => {
    this.setState({ successpopup: {} });
  };

  /**show sweet alert popup */
  getAlert = () => {
    if (!isEmpty(this.state.successpopup) && this.state.successpopup.success) {
      return (
        <SweetAlert
          success
          title="Success"
          onConfirm={() => this.hideAlert()}
          btnSize="md"
        >
          {this.state.successpopup.message}
        </SweetAlert>
      );
    } else if (
      !isEmpty(this.state.successpopup) &&
      !this.state.successpopup.success
    ) {
      return (
        <SweetAlert
          error
          title="Error"
          onConfirm={() => this.hideAlert()}
          btnSize="md"
        >
          {this.state.successpopup.message}
        </SweetAlert>
      );
    }
  };

  /**input values reset function */
  onReset = (id) => {
    let productData = JSON.parse(JSON.stringify(this.state.productData));
    productData[id] = {
      _id: "",
      productRange: "",
      minProductId: "",
      maxProductId: "",
      supplier: "",
      rawMaterials: [],
    };
    this.setState({ productData });
  };

  validateForm = ({ key = null, index = -1, submitted = false }) => {
    if (index >= 0) {
      let { validationStatus } = this.validationOnLoop({
        key,
        index,
        submitted,
      });
      return validationStatus;
    } else {
      let status = false;

      let { validationStatus } = this.validationOnLoop({
        index,
        submitted,
      });
      if (!validationStatus) return validationStatus;
      else status = validationStatus;

      return status;
    }
  };

  productRangeDropDown = (count) => {
    let items = [];
    for (let i = 1; i <= count; i++) {
      items.push(<option value={i}>{i}</option>);
    }
    return items;
  };

  validationOnLoop = ({ key = null, index = null, submitted = false }) => {
    const validateData = JSON.parse(JSON.stringify(this.state.productData));

    validateData[index].errors = {};

    if (
      isEmpty(validateData[index].minProductId) &&
      (key === "minProductId" || submitted)
    ) {
      validateData[index].errors.minProductId = "Min product Id is required";
    }
    if (
      isEmpty(validateData[index].maxProductId) &&
      (key === "maxProductId" || submitted)
    ) {
      validateData[index].errors.maxProductId = "Max product Id  is required";
    }

    if (
      isEmpty(validateData[index].supplier) &&
      (key === "supplier" || submitted)
    ) {
      validateData[index].errors.supplier = "supplier is required";
    }

    if (!isEmpty(validateData[index].rawMaterials)) {
      const errorRaw = [];

      validateData[index].rawMaterials.forEach((rawMaterial, i) => {
        if (
          isEmpty(rawMaterial.rawMaterialIds) &&
          (key === "rawMaterials" || submitted)
        ) {
          let obj = {
            rawMaterialIds: `Raw material ${i + 1} required`,
          };
          errorRaw[i] = obj;
        }
      });
      if (!isEmpty(errorRaw)) {
        validateData[index].errors.rawMaterials = errorRaw;
      }
    }

    this.setState({ productData: validateData });

    return { validationStatus: isEmpty(validateData[index].errors) };
  };

  /**Detata Table modify calams */
  modifyColums = (rowData, col) => {
    switch (col.field) {
      case "_id":
        return (
          <>
            <div
              className="custom-control custom-checkbox col"
              key={rowData._id}
            >
              <input
                type="checkbox"
                style={{ position: "absolute", top: "32%", left: "1%" }}
                // className="custom-control-input"
                // id="checklist-item-1"
                name="check"
                value={rowData._id}
                checked={this.state.id == rowData._id}
                onChange={(e) => this.showList(e, rowData)}
              />
              <label
              //  className="custom-control-label"
              ></label>
              <div className="media align-items-center">
                <ul className="pro-image">
                  <li>
                    <img
                      alt="product-image"
                      src="assets/img/product-image.png"
                      className="pro-image"
                    />
                  </li>
                </ul>
                <div className="media-body">
                  <div>
                    <span className="h6 font-weight-bolder">
                      {/* Traditional Unstrained */}
                      {rowData._id}
                    </span>
                  </div>
                  {this.state.productArr[rowData._id - 1] ? (
                    // productData
                    <div>
                      <span className="text-small">Product range :</span>
                      <span className="text-small pro-range-txt pr-3">
                        From{" "}
                        {this.state.productArr[rowData._id - 1].minProductId} To{" "}
                        {this.state.productArr[rowData._id - 1].maxProductId}
                      </span>
                      <span className="text-small pl-3">
                        Suppliers Details :
                      </span>
                      <span className="text-small pro-sup-txt pr-3">
                        {this.state.productArr[rowData._id - 1].supplier.map(
                          (list, id) => (
                            <span key={id}>{this.supplierList(list)},</span>
                          )
                        )}
                      </span>

                      {this.state.productArr[rowData._id - 1].rawMaterials.map(
                        (list, index) => (
                          <>
                            <span className="text-small pl-3" key={index}>
                              Raw Materials {index + 1}:
                            </span>
                            <span className="text-small pro-raw-txt">
                              {list.rawMaterialIds.map((item, id) => (
                                <span key={id}>
                                  {this.rawMaterialList(item)},
                                </span>
                              ))}
                            </span>
                          </>
                        )
                      )}
                    </div>
                  ) : (
                    ""
                  )}
                </div>
              </div>
            </div>

            {this.state.details.map((item, i) => (
              <div key={i}>
                {this.state.id === item._id && item._id === rowData._id ? (
                  <div
                    className="accordian-body  p-3"
                    style={{ backgroundColor: "#f1f4f9" }}
                  >
                    <form>
                      <div className="row">
                        <div className="col-3 col-md-3">
                          <div className="row">
                            <div className="col-md-12 form-m-group">
                              <div>
                                <label className="col-form-label">
                                  Product range
                                </label>
                                <select
                                  id="inputState"
                                  className="form-control"
                                  name="productRange"
                                  onChange={(e) => this.onChange(e, i)}
                                  value={this.state.productData[i].productRange}
                                >
                                  <option value="">Select</option>
                                  {this.productRangeDropDown(item.count)}
                                </select>
                              </div>
                              <div>
                                {" "}
                                <label className="col-form-label">
                                  Product ID range
                                </label>
                                <div className="form-row">
                                  <div className="form-group col-md-6">
                                    <input
                                      type="text"
                                      className="form-control"
                                      optionLabel="name"
                                      placeholder="min"
                                      name="minProductId"
                                      value={
                                        this.state.productData[i].minProductId
                                      }
                                      disabled
                                    />

                                    {this.state.productData[i].errors ? (
                                      <p className="text-danger">
                                        {
                                          this.state.productData[i].errors
                                            .minProductId
                                        }
                                      </p>
                                    ) : (
                                      ""
                                    )}
                                  </div>
                                  <div className="form-group col-md-6">
                                    <input
                                      type="text"
                                      className="form-control"
                                      optionLabel="name"
                                      optionValue="value"
                                      placeholder="max"
                                      name="maxProductId"
                                      value={
                                        this.state.productData[i].maxProductId
                                      }
                                      disabled
                                    />
                                    {this.state.productData[i].errors ? (
                                      <p className="text-danger">
                                        {
                                          this.state.productData[i].errors
                                            .maxProductId
                                        }
                                      </p>
                                    ) : (
                                      ""
                                    )}
                                  </div>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                        <div className="col-4 col-md-4">
                          <div className="row">
                            <div className="col-md-12">
                              <div className="form-row">
                                <div className="form-group col-md-12">
                                  <label className="col-form-label">
                                    Supplier Deatils
                                  </label>
                                  <MultiSelect
                                    className="form-control"
                                    optionLabel="name"
                                    optionValue="value"
                                    name="supplier"
                                    placeholder="Select a Supplier"
                                    value={this.state.productData[i].supplier}
                                    options={this.supplierList()}
                                    onChange={(e) => this.onChange(e, i)}
                                  />
                                  {this.state.productData[i].errors ? (
                                    <p className="text-danger">
                                      {
                                        this.state.productData[i].errors
                                          .supplier
                                      }
                                    </p>
                                  ) : (
                                    ""
                                  )}
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                        <div className="col-4 col-md-5">
                          <div className="row">
                            <div className="col-md-12">
                              <div
                                className={
                                  this.state.productData[i].supplier.length > 2
                                    ? "form-row scrolling-wrapper flex-row flex-nowrap mb-1 pb-3"
                                    : "form-row flex-row flex-nowrap mb-1 pb-3"
                                }
                              >
                                {this.state.productData[i].supplier &&
                                  this.state.productData[i].supplier.map(
                                    (list, index) => (
                                      <div
                                        className="form-group col-md-6"
                                        key={index}
                                      >
                                        <label className="col-form-label">
                                          Raw Materials from Supplier {list}
                                        </label>
                                        {this.state.data[0].rawMaterialData &&
                                        this.state.data[0].rawMaterialData[
                                          index
                                        ] ? (
                                          <MultiSelect
                                            className="form-control"
                                            optionLabel="name"
                                            optionValue="value"
                                            placeholder="Select a Raw Material"
                                            name="rawMaterials"
                                            value={
                                              this.state.productData[i]
                                                .rawMaterials[index]
                                                .rawMaterialIds
                                            }
                                            options={this.rawMaterialList(
                                              index
                                            )}
                                            onChange={(e) =>
                                              this.onChange(e, i, index)
                                            }
                                          />
                                        ) : (
                                          ""
                                        )}

                                        {this.state.productData[i].errors &&
                                        !isEmpty(
                                          this.state.productData[i].errors
                                            .rawMaterials
                                        ) ? (
                                          <p className="text-danger">
                                            {this.state.productData[i].errors
                                              .rawMaterials[index]
                                              ? this.state.productData[i].errors
                                                  .rawMaterials[index]
                                                  .rawMaterialIds
                                              : ""}
                                          </p>
                                        ) : (
                                          ""
                                        )}
                                      </div>
                                    )
                                  )}
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                      <hr className="my-1" />
                      <div className="row pt-2">
                        <div className="col-md-12">
                          <div className="qr-bottom-btn">
                            <button
                              type="button"
                              className="btn btn-primary-ghost px-3 mr-2"
                              onClick={() => this.onReset(i)}
                            >
                              Clear
                            </button>
                            <button
                              type="submit"
                              className="btn btn-primary px-2"
                              onClick={(e) => this.onSave(e, i)}
                            >
                              Save
                            </button>
                          </div>
                        </div>
                      </div>
                    </form>
                  </div>
                ) : (
                  ""
                )}
              </div>
            ))}
          </>
        );

      default:
        return rowData[col.field];
    }
  };

  /**product list show function */
  showList = async (e, rowData) => {
    if (!this.state.id) {
      this.setState({ id: rowData._id });
    } else {
      this.setState({ id: null });
    }
  };

  render() {
    return (
      <div className="wrapper">
        <div className="content-page">
          <div className="content">
            <div className="topnav-navbar topnav-navbar-light">
              <DashBoardHeader />
            </div>
            {/* sweet alert popup */}
            {!isEmpty(this.state.successpopup) ? this.getAlert() : ""}
            {/* End sweet alert popup */}

            <div className="container-fluid">
              <div className="link_pro_catlog p-6 mb-4">
                <div className="row">
                  <div className="col-12 ">
                    <div className="font-weight-bolder text-dark display-6">
                      Link Product Catalogue
                    </div>
                    <div className="qr-content">
                      <div className="row">
                        <div className="col-md-6">
                          <div className="form-row">
                            <div className="form-group col-md-6">
                              <label>Type of product</label>

                              <select
                                id="inputState"
                                className="form-control"
                                placeholder="Select the type"
                                onChange={(e) => this.typeList(e)}
                                value={this.state.productType}
                              >
                                <option value="">Select</option>
                                {this.state.data &&
                                this.state.data[0].productType
                                  ? this.state.data[0].productType.map(
                                      (item) => {
                                        return (
                                          <option value={item._id}>
                                            {item._id}
                                          </option>
                                        );
                                      }
                                    )
                                  : ""}
                              </select>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>

                {isEmpty(this.state.productType) ? (
                  <div className="empty-qr-screen">
                    <svg className="manage-nav-icon">
                      <use xlinkHref="../assets/img/up-sprite.svg#empty_status_qr"></use>
                    </svg>
                    <p>
                      To link product to the supplier
                      <br /> Select the type of product
                    </p>
                  </div>
                ) : (
                  ""
                )}

                {!isEmpty(this.state.productType) ? (
                  <div className="link-product-list">
                    <div className="font-weight-bolder text-dark h6 my-2">
                      Product Catalogue List of{" "}
                      {this.state.productType ? (
                        <span>{this.state.productType},</span>
                      ) : (
                        ""
                      )}
                    </div>

                    <div className="row">
                      <div className="col-lg-12">
                        <DataTable
                          respData={this.state.details}
                          column={this.state.column}
                          modifyColums={(rowData, col) =>
                            this.modifyColums(rowData, col)
                          }
                          productType={this.state.productType}
                        />
                      </div>
                    </div>
                  </div>
                ) : (
                  ""
                )}
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }
}

export default ProductLink;
