import React from "react";
import Validator from "validator";

import TextFieldGroup from "../common/TextFieldGroup";

import isEmpty from "../../utils/isEmpty";

import services from "../../services";

import SweetAlert from "react-bootstrap-sweetalert";

class Signin extends React.Component {
  state = {
    email: "",
    password: "",
    errors: {},
    successpopup: {},
  };

  onSubmit = async (e) => {
    e.preventDefault();
    if (this.validateForm({ submitted: true })) {
      const formData = Object.assign({}, this.state);
      delete formData.errors;
      services.userManagementServices
        .signinUser(formData)
        .then((success) => {
          let successpopup = {};
          successpopup.message = "You have successfully login!.";
          this.setState({ successpopup });
        })
        .catch((err) => {
          let errors = err;
          this.setState({ errors });
        });
    }
  };

  hideAlert = () => {
    let redirectPath = "/dashboard";
    this.props.history.push(redirectPath);
    this.setState({ successpopup: {} });
  };

  /**show sweet alert popup */
  getAlert = () => {
    return (
      <SweetAlert
        success
        title="Success"
        onConfirm={() => this.hideAlert()}
        btnSize="md"
      >
        {this.state.successpopup.message}
      </SweetAlert>
    );
  };

  onChange = (e) => {
    const { name, value } = e.target;
    this.setState({ [name]: value, errors: {} }, async () => {
      this.validateForm({ key: name });
    });
  };

  validateForm = ({ key = null, submitted = false }) => {
    const errors = {};

    if (isEmpty(this.state.email) && (key === "email" || submitted)) {
      errors.email = "Email field is required";
    } else if (this.state.email && !Validator.isEmail(this.state.email)) {
      errors.email = "Email is invalid";
    }

    if (isEmpty(this.state.password) && (key === "password" || submitted)) {
      errors.password = "Password field is required";
    }
    this.setState({ errors });
    return isEmpty(errors);
  };

  render() {
    const { errors } = this.state;
    return (
      <div className="d-flex flex-column flex-root">
        <div className="login login-1 login-signin-on d-flex flex-column flex-lg-row flex-column-fluid">
          <div className="login-aside d-flex flex-column flex-row-auto">
            <div className="d-flex flex-column-auto flex-column pt-lg-30 pt-10 mx-11">
              <a className="text-center mb-10 px-3">
                <img src="assets/img/logo.svg" alt="logo" className="h-60px" />
                <span className="ml-2 font-weight-bolder text-center h5 text-white">
                  Unified Track & Trace
                </span>
              </a>
              <div className="uc-supplyflow">
                <div className="font-weight-bolder h5 text-white">
                  What you can do?
                </div>
                <ul>
                  <li>Integrate and Create Inventory</li>
                  <li>Create QR code</li>
                  <li>Real-time asset tracking</li>
                  <li>Help identify asset location </li>
                </ul>
              </div>
            </div>
          </div>

          <div className="login-content flex-row-fluid d-flex flex-column justify-content-center position-relative overflow-hidden p-7 mx-auto">
            <div className="d-flex flex-column-fluid flex-center">
              <div className="login-form login-signin">
                <form className="form">
                  <div className="pt-28 pb-6">
                    <h3 className="font-weight-bolder text-dark h5">
                      Welcome back. We only need your Username and password, and
                      you'll be on your way.
                    </h3>
                  </div>

                  <div className="form-row">
                    <div className="form-group col-md-12">
                      <TextFieldGroup
                        label="Email Address"
                        type="email"
                        name="email"
                        value={this.state.email}
                        onChange={(e) => this.onChange(e)}
                        placeholder="Enter Email Address"
                        error={errors && errors.email}
                      />
                    </div>
                  </div>

                  <div className="form-row">
                    <div className="form-group col-md-12">
                      <TextFieldGroup
                        label="Password"
                        type="password"
                        name="password"
                        value={this.state.password}
                        onChange={(e) => this.onChange(e)}
                        placeholder="Password"
                        error={errors && errors.password}
                      />
                    </div>
                  </div>

                  <div className="row check-cont">
                    <div className="col-6">
                      <label className="check-cont">
                        <span className="pl-8 text-small">Remember me</span>
                        <input type="checkbox" defaultChecked="checked" />
                        <span className="checkmark"></span>
                      </label>
                    </div>
                    <div className="col-6">
                      <a href="#" className="link pull-right text-small">
                        Forgot password?
                      </a>
                    </div>
                  </div>

                  <div className="bottom-btn">
                    <button
                      type="submit"
                      className="btn btn-primary w-100 py-1"
                      onClick={this.onSubmit}
                    >
                      Login
                    </button>
                  </div>
                </form>
                {/* sweet alert popup */}
                {!isEmpty(this.state.successpopup) &&
                this.state.successpopup.message
                  ? this.getAlert()
                  : ""}
                {/* End sweet alert */}
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }
}
export default Signin;
