import React from "react";
import { withRouter, Link } from "react-router-dom";

class SignupConfirmation extends React.Component {
  render() {
    return (
      <div className="layout">
        <div className="container-fluid p-0">
          <div className="account-ver-content">
            <div className="full-screen-loader">
              <img src="../assets/img/ballon.png" alt="ballon" />
              <div className="card">
                <div className="half-arc"></div>
                <div className="cong-content">
                  <div className="h4">Congratulations</div>
                  <p>Your new account has been verified</p>
                  <div className="row">
                    <div className="col-12 blue-btn">
                      <Link to="/" className="btn px-5 py-2 border-0">
                        Continue to Login
                      </Link>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }
}

export default SignupConfirmation;
