import React from "react";
import Validator from "validator";

import TextFieldGroup from "../common/TextFieldGroup";

import isEmpty from "../../utils/isEmpty";

const owasp = require("owasp-password-strength-test");
owasp.config({
  allowPassphrases: false,
  maxLength: 128,
  minLength: 6,
  minPhraseLength: 10,
  minOptionalTestsToPass: 3
});

class PersonalDetails extends React.Component {
  state = {
    firstName: "",
    lastName: "",
    phone: "",
    email: "",
    password: "",
    confirmPassword: "",
    errors: {}
  };

  componentDidMount() {
    this.setDetails();
  }

  setDetails = () => {
    this.setState(prevState => {
      prevState =
        this.props.confirmDetails && this.props.confirmDetails.personal
          ? this.props.confirmDetails.personal
          : {};

      return prevState;
    });
  };

  onSave = async e => {
    e.preventDefault();
    if (this.validationForm({ submitted: true })) {
      let formData = Object.assign({}, this.state);
      delete formData.errors;
      if (this.props.confirmDetails && this.props.confirmDetails.personal) {
        this.props.activeTab(3, formData, "edit");
      } else {
        this.props.activeTab(3, formData);
      }
    }
  };

  onChange = e => {
    const { name, value } = e.target;
    this.setState({ [name]: value, errors: {} }, async () => {
      this.validationForm({ key: name });
    });
  };

  validationForm = ({ key = null, submitted = false }) => {
    const errors = {};

    if (isEmpty(this.state.firstName) && (key === "firstName" || submitted)) {
      errors.firstName = "First Name is required";
    } else if (
      this.state.firstName &&
      !Validator.isLength(this.state.firstName, { min: 3 })
    ) {
      errors.firstName = "First Name minimum 3 characters";
    }
    if (this.state.firstName && !Validator.isAlpha(this.state.firstName)) {
      errors.firstName = "First Name is invalid";
    }

    if (isEmpty(this.state.lastName) && (key === "lastName" || submitted)) {
      errors.lastName = "Last Name is required";
    }

    if (isEmpty(this.state.phone) && (key === "phone" || submitted)) {
      errors.phone = "Phone number is required";
    } else if (
      this.state.phone &&
      !Validator.isLength(this.state.phone, { min: 10, max: 10 })
    ) {
      errors.phone = "Phone Number minimum 10 numbers";
    }
    if (this.state.phone && !Validator.isDecimal(this.state.phone)) {
      errors.phone = "Phone number Invalid";
    }

    if (isEmpty(this.state.email) && (key === "email" || submitted)) {
      errors.email = "Email is required";
    }

    if (isEmpty(this.state.password) && (key === "password" || submitted)) {
      errors.password = "password is required";
    } else if (
      !isEmpty(this.state.password) &&
      !Validator.isLength(this.state.password, { min: 6, max: 30 })
    ) {
      errors.password = "Password must be atleast 6 characters";
    }

    if (!isEmpty(this.state.password)) {
      let passwdTestResult = owasp.test(this.state.password);
      if (passwdTestResult.errors.length > 0) {
        errors.password = passwdTestResult.errors[0];
      }
    }

    if (
      isEmpty(this.state.confirmPassword) &&
      (key === "confirmPassword" || submitted)
    ) {
      errors.confirmPassword = `Confirm password field is required`;
    } else if (
      !isEmpty(this.state.confirmPassword) &&
      !Validator.equals(this.state.password, this.state.confirmPassword)
    ) {
      errors.confirmPassword = "Passwords must be equal";
    }

    this.setState({ errors });
    return isEmpty(errors);
  };

  onClear = () => {
    this.setState();
  };

  render() {
    const { errors } = this.state;
    return (
      <div className="login-content flex-row-fluid d-flex flex-column justify-content-center position-relative overflow-hidden p-7 mx-auto">
        <div className="d-flex flex-column-fluid flex-center">
          <div className="login-form login-signin">
            <form className="form">
              <div className="pt-22 pb-6">
                <h3 className="font-weight-bolder text-dark h5">
                  Hello! Please tell us a little bit about your Personal
                </h3>
              </div>

              <div className="form-row">
                <div className="form-group col-md-6">
                  <TextFieldGroup
                    label="First name"
                    type="text"
                    name="firstName"
                    value={this.state.firstName}
                    onChange={e => this.onChange(e)}
                    placeholder="Enter First name"
                    error={errors && errors.firstName}
                  />
                </div>
                <div className="form-group col-md-6">
                  <TextFieldGroup
                    label="Last name"
                    type="text"
                    name="lastName"
                    value={this.state.lastName}
                    onChange={e => this.onChange(e)}
                    placeholder="Enter Last name"
                    error={errors && errors.lastName}
                  />
                </div>
              </div>

              <div className="form-row">
                {/* <div className="form-group col-md-6">
                  <TextFieldGroup
                    label="Role"
                    type="text"
                    name="role"
                    value={this.state.role}
                    onChange={(e) => this.onChange(e)}
                    placeholder="Enter Role"
                    error={errors && errors.role}
                  />
                </div> */}
                <div className="form-group col-md-6">
                  <TextFieldGroup
                    label="Phone / Mobile Number"
                    type="text"
                    name="phone"
                    value={this.state.phone}
                    onChange={e => this.onChange(e)}
                    maxlength="10"
                    placeholder="Enter phone / mobile number"
                    error={errors && errors.phone}
                  />
                </div>
              </div>

              <div className="form-row">
                <div className="form-group col-md-12">
                  <TextFieldGroup
                    label="Email id"
                    type="email"
                    name="email"
                    value={this.state.email}
                    onChange={e => this.onChange(e)}
                    placeholder="Enter email id"
                    error={errors && errors.email}
                  />
                </div>
              </div>

              <div className="form-row">
                <div className="form-group col-md-6">
                  <TextFieldGroup
                    label="Password"
                    type="password"
                    name="password"
                    value={this.state.password}
                    onChange={e => this.onChange(e)}
                    placeholder="Enter password"
                    error={errors && errors.password}
                  />
                </div>
                <div className="form-group col-md-6">
                  <TextFieldGroup
                    label="Confirm Password"
                    type="password"
                    name="confirmPassword"
                    value={this.state.confirmPassword}
                    onChange={e => this.onChange(e)}
                    placeholder="Enter confirm password"
                    error={errors && errors.confirmPassword}
                  />
                </div>
              </div>

              <div className="bottom-btn">
                <button
                  type="button"
                  className="btn btn-primary-ghost mr-2"
                  onClick={this.onClear}
                >
                  Clear
                </button>
                {this.props.confirmDetails &&
                this.props.confirmDetails.personal ? (
                  <button
                    type="submit"
                    class="btn btn-primary"
                    onClick={this.onSave}
                  >
                    Update
                  </button>
                ) : (
                  <button
                    type="submit"
                    class="btn btn-primary"
                    onClick={this.onSave}
                  >
                    Next
                  </button>
                )}
              </div>
            </form>
          </div>
        </div>
      </div>
    );
  }
}

export default PersonalDetails;
