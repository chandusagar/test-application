import React from "react";
import { withRouter } from "react-router-dom";

import services from "../../services";

class Confirm extends React.Component {
  state = {};

  onSave = async () => {
    let business = this.props.confirmDetails.business;
    services.userManagementServices
      .createOrganizationUser(business)
      .then((orgData) => {
        console.log(orgData);
        this.personalService(orgData.data._id);
      })
      .catch((err) => {
        console.log(err);
        alert("There is a Pbm in Sending Request");
      });
  };

  personalService = (data) => {
    let personal = this.props.confirmDetails.personal;
    personal.organizationId = data;

    services.userManagementServices
      .addAdminUser(personal)
      .then((success) => {
        let redirectPath = `/verifyAccount/${personal.email}`;
        this.props.history.push(redirectPath);
      })
      .catch((err) => {
        console.log(err);
        // alert("There is a Pbm in Sending Request");
      });
  };

  render() {
    const details = this.props.confirmDetails;
    return (
      <div class="login-content flex-row-fluid d-flex flex-column justify-content-center position-relative overflow-hidden p-7 mx-auto">
        <div class="d-flex flex-column-fluid flex-center">
          <div class="login-form login-signin">
            <div class="pt-22 pb-6">
              <h3 class="font-weight-bolder text-dark h5">
                Thanks! for Sharing your details, Please Confirm to get your
                verification code
              </h3>
            </div>
            <div class="row ">
              {details.business ? (
                <div class="col-12 col-lg-6 col-xl-6 d-flex">
                  <div class="card flex-fill w-100">
                    <div class="card-header d-flex">
                      <h6 class="card-title mb-0 font-weight-bolder text-dark">
                        Business Details
                      </h6>
                      <div class="card-actions expand-icon-txt">
                        <button
                          class="btn p-0"
                          onClick={() => this.props.editDetails(1)}
                        >
                          <i class="fas fa-edit"></i>
                        </button>
                      </div>
                    </div>
                    <div class="card-body">
                      <div class="text-small">Business Type</div>
                      <div class="sub-text">
                        {details.business && details.business.businessType
                          ? details.business.businessType
                          : ""}
                      </div>
                      <hr class="my-1" />
                      <div class="text-small">Business Name</div>
                      <div class="sub-text">
                        {details.business && details.business.companyName
                          ? details.business.companyName
                          : ""}
                      </div>
                      <hr class="my-1" />
                      <div class="text-small">Entity Name</div>
                      <div class="sub-text">
                        {details.business && details.business.entityName
                          ? details.business.entityName
                          : ""}
                      </div>
                      <hr class="my-1" />
                      <div class="text-small">Phone / Mobile Number</div>
                      <div class="sub-text">
                        +91
                        {details.business && details.business.phone
                          ? details.business.phone
                          : ""}
                      </div>
                      <hr class="my-1" />
                      <div class="text-small">Compnay Address</div>
                      <div class="sub-text">
                        <p>
                          {details.business && details.business.companyAddress
                            ? details.business.companyAddress
                            : ""}
                          ,
                          {details.business && details.business.city
                            ? details.business.city
                            : ""}
                          -
                          {details.business && details.business.zipCode
                            ? details.business.zipCode
                            : ""}
                          .
                          {details.business && details.business.state
                            ? details.business.state
                            : ""}
                          ,India.
                        </p>
                      </div>
                    </div>
                  </div>
                </div>
              ) : (
                ""
              )}
              {details.personal ? (
                <div class="col-12 col-lg-6 col-xl-6 d-flex">
                  <div class="card flex-fill w-100">
                    <div class="card-header d-flex">
                      <h6 class="card-title mb-0 font-weight-bolder text-dark">
                        Personal Details
                      </h6>
                      <div class="card-actions expand-icon-txt">
                        <button
                          class="btn p-0"
                          onClick={() => this.props.editDetails(2)}
                        >
                          <i class="fas fa-edit"></i>
                        </button>
                      </div>
                    </div>
                    <div class="card-body">
                      <div class="text-small">First Name</div>
                      <div class="sub-text">
                        {details.personal && details.personal.firstName
                          ? details.personal.firstName
                          : ""}
                      </div>
                      <hr class="my-1" />
                      <div class="text-small">Last Name</div>
                      <div class="sub-text">
                        {details.personal && details.personal.lastName
                          ? details.personal.lastName
                          : ""}
                      </div>
                      <hr class="my-1" />
                      <div class="text-small">Role</div>
                      <div class="sub-text">
                        {details.personal && details.personal.role
                          ? details.personal.role
                          : ""}
                      </div>
                      <hr class="my-1" />
                      <div class="text-small">Mobile name</div>
                      <div class="sub-text">
                        +91{" "}
                        {details.personal && details.personal.phone
                          ? details.personal.phone
                          : ""}
                      </div>
                      <hr class="my-1" />
                      <div class="text-small">E mail address</div>
                      <div class="sub-text">
                        {details.personal && details.personal.email
                          ? details.personal.email
                          : ""}
                      </div>
                      <hr class="my-1" />
                      <div class="text-small">Password</div>
                      {/* <div class="sub-text">
                        {details.personal && details.personal.password
                          ? details.personal.password
                          : ""}
                      </div> */}
                      <div class="sub-text">*************</div>
                    </div>
                  </div>
                </div>
              ) : (
                ""
              )}

              <div className="bottom-btn">
                {/* <button type="button" className="btn btn-primary-ghost mr-2">
                  Back
                </button> */}
                <button
                  type="submit"
                  class="btn btn-primary"
                  onClick={this.onSave}
                >
                  Next
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }
}

export default withRouter(Confirm);
