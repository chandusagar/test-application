import React from "react";
import { withRouter } from "react-router-dom";
import Validator from "validator";

import TextFieldGroup from "../common/TextFieldGroup";

import isEmpty from "../../utils/isEmpty";

import services from "../../services";

const owasp = require("owasp-password-strength-test");
owasp.config({
  allowPassphrases: false,
  maxLength: 128,
  minLength: 6,
  minPhraseLength: 10,
  minOptionalTestsToPass: 3,
});

class CreatePassword extends React.Component {
  state = {
    email: "",
    password: "",
    confirmPassword: "",
    errors: {},
  };

  onChange = (e) => {
    const { name, value } = e.target;
    this.setState({ [name]: value, errors: {} }, async () => {
      this.validateLoginForm({ key: name });
    });
  };

  onSubmit = (e) => {
    e.preventDefault();

    /** Check form validations */
    if (
      this.validateLoginForm({ submitted: true }) &&
      !isEmpty(this.props.match.params.companyId)
    ) {
      const formData = Object.assign({}, this.state);
      delete formData.errors;

      services.userManagementServices
        .signupUser(formData)
        .then((success) => {
          alert(success);
          let redirectPath = `/verifyAccount/${formData.email}`;
          this.props.history.push(redirectPath);
        })
        .catch((err) => {
          console.log(err);
          alert("There is a Pbm in Sending Request");
        });
      //   formData.companyId = this.props.match.params.companyId;

      //   this.props.sigupUser(formData, this.props.history);
    }
  };

  /** Return validations */
  validateLoginForm = ({ key = null, submitted = false }) => {
    const errors = {};

    if (isEmpty(this.state.email) && (key === "email" || submitted)) {
      errors.email = `Email field is required`;
    } else if (this.state.email && !Validator.isEmail(this.state.email)) {
      errors.email = "Email is invalid";
    }

    if (isEmpty(this.state.password) && (key === "password" || submitted)) {
      errors.password = `Password field is required`;
    } else if (
      !isEmpty(this.state.password) &&
      !Validator.isLength(this.state.password, { min: 6, max: 30 })
    ) {
      errors.password = "Password must be atleast 6 characters";
    }

    if (!isEmpty(this.state.password)) {
      let passwdTestResult = owasp.test(this.state.password);
      if (passwdTestResult.errors.length > 0) {
        errors.password = passwdTestResult.errors[0];
      }
    }

    if (
      isEmpty(this.state.confirmPassword) &&
      (key === "confirmPassword" || submitted)
    ) {
      errors.confirmPassword = `Confirm password field is required`;
    } else if (
      !isEmpty(this.state.confirmPassword) &&
      !Validator.equals(this.state.password, this.state.confirmPassword)
    ) {
      errors.confirmPassword = "Passwords must be equal";
    }

    this.setState({ errors });

    return isEmpty(errors);
  };

  render() {
    const { errors } = this.state;
    return (
      <div className="d-flex flex-column flex-root">
        <div className="login login-1 login-signin-on d-flex flex-column flex-lg-row flex-column-fluid">
          <div className="login-aside d-flex flex-column flex-row-auto">
            <div className="d-flex flex-column-auto flex-column pt-lg-30 pt-10 mx-11">
              <a className="text-center mb-10 px-3">
                <img
                  src="../assets/img/logo.svg"
                  alt="logo"
                  className="h-60px"
                />
                <span className="ml-2 font-weight-bolder text-center h5 text-white">
                  Unified Track & Trace
                </span>
              </a>
              <div className="uc-supplyflow">
                <div className="font-weight-bolder h5 text-white">
                  What you can do?
                </div>
                <ul>
                  <li>Integrate and Create Inventory</li>
                  <li>Create QR code</li>
                  <li>Real-time asset tracking</li>
                  <li>Help identify asset location </li>
                </ul>
              </div>
            </div>
          </div>

          <div className="login-content flex-row-fluid d-flex flex-column justify-content-center position-relative overflow-hidden p-7 mx-auto">
            <div className="d-flex flex-column-fluid flex-center">
              <div className="login-form login-signin">
                <form className="form">
                  <div className="pt-28 pb-6">
                    <h3 className="font-weight-bolder text-dark h5">
                      Welcome We only need your password And Confirm password,
                      and you'll be on your way.
                    </h3>
                  </div>

                  <div className="form-row">
                    <div className="form-group col-md-12">
                      <TextFieldGroup
                        label="Email Address"
                        type="email"
                        name="email"
                        value={this.state.email}
                        onChange={(e) => this.onChange(e)}
                        placeholder="Enter Email Address"
                        error={errors && errors.email}
                      />
                    </div>
                  </div>

                  <div className="form-row">
                    <div className="form-group col-md-12">
                      <TextFieldGroup
                        label="Password"
                        type="password"
                        name="password"
                        value={this.state.password}
                        onChange={(e) => this.onChange(e)}
                        placeholder="Password"
                        error={errors && errors.password}
                      />
                    </div>
                  </div>

                  <div className="form-row">
                    <div className="form-group col-md-12">
                      <TextFieldGroup
                        label="Confirm Password"
                        type="password"
                        name="confirmPassword"
                        value={this.state.confirmPassword}
                        onChange={(e) => this.onChange(e)}
                        placeholder="Enter confirm password"
                        error={errors && errors.confirmPassword}
                      />
                    </div>
                  </div>

                  <div className="bottom-btn">
                    <button
                      type="submit"
                      className="btn btn-primary w-100 py-1"
                      onClick={this.onSubmit}
                    >
                      {/* Login */}
                      Save
                    </button>
                  </div>
                </form>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }
}

export default withRouter(CreatePassword);
