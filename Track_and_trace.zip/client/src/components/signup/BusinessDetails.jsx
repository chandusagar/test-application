import React from "react";
import Validator from "validator";

import TextFieldGroup from "../common/TextFieldGroup";
import SelectComponent from "../common/SelectComponent";

import stateMapping from "../onBoardInventory/commonComponents/JsonData/states";

import isEmpty from "../../utils/isEmpty";

class BusinessDetails extends React.Component {
  state = {
    businessType: "",
    companyName: "",
    entityName: "",
    phone: "",
    companyAddress: "",
    city: "",
    state: "",
    zipCode: "",
    errors: {},
  };

  // companyName

  componentDidMount() {
    this.setDetails();
  }

  setDetails = () => {
    this.setState((prevState) => {
      prevState =
        this.props.confirmDetails && this.props.confirmDetails.business
          ? this.props.confirmDetails.business
          : {};
      return prevState;
    });
  };

  onSave = async (e) => {
    e.preventDefault();
    if (this.validationForm({ submitted: true })) {
      const formData = Object.assign({}, this.state);
      delete formData.errors;

      if (this.props.confirmDetails.business) {
        this.props.activeTab(2, formData, "edit");
      } else {
        this.props.activeTab(2, formData);
      }
    }
  };

  onChange = (e) => {
    const { name, value } = e.target;
    this.setState({ [name]: value, errors: {} }, async () => {
      this.validationForm({ key: name });
    });
  };

  validationForm = ({ key = null, submitted = false }) => {
    const errors = {};

    if (
      isEmpty(this.state.businessType) &&
      (key === "businessType" || submitted)
    ) {
      errors.businessType = "business type is required";
    }

    if (
      isEmpty(this.state.companyName) &&
      (key === "companyName" || submitted)
    ) {
      errors.companyName = "Business name is required";
    } else if (
      this.state.companyName &&
      !Validator.isLength(this.state.companyName, { min: 3 })
    ) {
      errors.companyName = "Business name minimum 3 characters";
    }

    if (isEmpty(this.state.entityName) && (key === "entityName" || submitted)) {
      errors.entityName = "EntityName name is required";
    } else if (
      this.state.entityName &&
      !Validator.isLength(this.state.entityName, { min: 3 })
    ) {
      errors.entityName = "Entity name minimum 3 characters";
    }

    if (isEmpty(this.state.phone) && (key === "phone" || submitted)) {
      errors.phone = "Phone number is required";
    } else if (
      this.state.phone &&
      !Validator.isLength(this.state.phone, { min: 10, max: 10 })
    ) {
      errors.phone = "Phone Number minimum 10 numbers";
    }

    if (this.state.phone && !Validator.isDecimal(this.state.phone)) {
      errors.phone = "Phone number Invalid";
    }

    if (
      isEmpty(this.state.companyAddress) &&
      (key === "companyAddress" || submitted)
    ) {
      errors.companyAddress = "Company address is required";
    } else if (
      this.state.companyAddress &&
      !Validator.isLength(this.state.companyAddress, { min: 5 })
    ) {
      errors.companyAddress = "Company address minimum 5 characters";
    }

    if (isEmpty(this.state.city) && (key === "city" || submitted)) {
      errors.city = "City is required";
    } else if (
      this.state.city &&
      !Validator.isLength(this.state.city, { min: 5 })
    ) {
    }
    if (this.state.city && !Validator.isAlpha(this.state.city)) {
      errors.city = "City is invalid";
    }

    if (isEmpty(this.state.state) && (key === "state" || submitted)) {
      errors.state = "State is required";
    }

    if (isEmpty(this.state.zipCode) && (key === "zipCode" || submitted)) {
      errors.zipCode = "Zip Code is required";
    } else if (
      this.state.zipCode &&
      !Validator.isLength(this.state.zipCode, { min: 6 })
    ) {
      errors.zipCode = "Zip code should have minimum 6 numbers";
    }

    if (this.state.zipCode && !Validator.isDecimal(this.state.zipCode)) {
      errors.zipCode = "Invalid Zip Code";
    }

    this.setState({ errors });
    return isEmpty(errors);
  };

  onClear = () => {
    this.setState((prevState) => {
      prevState.businessType = "";
      prevState.companyName = "";
      prevState.entityName = "";
      prevState.phone = "";
      prevState.companyAddress = "";
      prevState.city = "";
      prevState.state = "";
      prevState.zipCode = "";
      return prevState;
    });
  };

  /**list of state name function */
  stateNames = () => {
    return stateMapping.stateNames.fields;
  };

  businessList = () => {
    return [
      { name: "Service ", value: "Service" },
      { name: "Merchandising ", value: "Merchandising" },
      { name: "Manufacturing ", value: "Manufacturing" },
      { name: "Hybrid ", value: "Hybrid" },
      { name: "Sole Proprietorship", value: "SoleProprietorship" },
      { name: "Partnership", value: "Partnership" },
      { name: "Corporation", value: "Corporation" },
      { name: "Limited Liability (LLC)", value: "LimitedLiabilityCompany" },
    ];
  };

  render() {
    const { errors } = this.state;
    return (
      <div className="login-content flex-row-fluid d-flex flex-column justify-content-center position-relative overflow-hidden p-7 mx-auto">
        <div className="d-flex flex-column-fluid flex-center">
          <div className="login-form login-signin">
            <form className="form">
              <div className="pt-22 pb-6">
                <h3 className="font-weight-bolder text-dark h5">
                  Hello! Please tell us a little bit about your business
                </h3>
              </div>
              <div className="form-row">
                <div className="form-group col-md-6">
                  <SelectComponent
                    label="Business Type"
                    onChange={(e) => this.onChange(e)}
                    options={this.businessList()}
                    name="businessType"
                    value={this.state.businessType}
                    error={errors && errors.businessType}
                  />
                </div>
                <div className="form-group col-md-6">
                  <TextFieldGroup
                    label="Business Name"
                    type="text"
                    name="companyName"
                    value={this.state.companyName}
                    onChange={(e) => this.onChange(e)}
                    placeholder="Enter Your business name"
                    error={errors && errors.companyName}
                  />
                </div>
              </div>
              <div className="form-row">
                <div className="form-group col-md-6">
                  <TextFieldGroup
                    label="Entity Name"
                    type="text"
                    name="entityName"
                    value={this.state.entityName}
                    onChange={(e) => this.onChange(e)}
                    placeholder="Enter Your entity name"
                    error={errors && errors.entityName}
                  />
                </div>
                <div className="form-group col-md-6">
                  <TextFieldGroup
                    label="Phone / Mobile Number"
                    type="text"
                    name="phone"
                    value={this.state.phone}
                    onChange={(e) => this.onChange(e)}
                    maxlength="10"
                    placeholder="Enter phone / mobile number"
                    error={errors && errors.phone}
                  />
                </div>
              </div>

              <div className="form-row">
                <div className="form-group col-md-12">
                  <TextFieldGroup
                    label="Company Address"
                    type="text"
                    name="companyAddress"
                    value={this.state.companyAddress}
                    onChange={(e) => this.onChange(e)}
                    placeholder="Enter Company companyAddress"
                    error={errors && errors.companyAddress}
                  />
                </div>
              </div>

              <div className="form-row">
                <div className="form-group col-md-4">
                  <TextFieldGroup
                    label="City"
                    type="text"
                    name="city"
                    value={this.state.city}
                    onChange={(e) => this.onChange(e)}
                    placeholder="Enter City Name"
                    error={errors && errors.city}
                  />
                </div>
                <div className="form-group col-md-4">
                  <SelectComponent
                    label="State"
                    onChange={(e) => this.onChange(e)}
                    options={this.stateNames()}
                    name="state"
                    value={this.state.state}
                    error={errors && errors.state}
                  />
                </div>
                <div className="form-group col-md-4">
                  <TextFieldGroup
                    label="ZipCode"
                    type="text"
                    name="zipCode"
                    value={this.state.zipCode}
                    onChange={(e) => this.onChange(e)}
                    maxlength="7"
                    placeholder="Enter ZipCode"
                    error={errors && errors.zipCode}
                  />
                </div>
              </div>

              <div className="bottom-btn">
                <button
                  type="button"
                  className="btn btn-primary-ghost mr-2"
                  onClick={this.onClear}
                >
                  Clear
                </button>
                {this.props.confirmDetails &&
                this.props.confirmDetails.business ? (
                  <button
                    type="submit"
                    className="btn btn-primary"
                    onClick={this.onSave}
                  >
                    Update
                  </button>
                ) : (
                  <button
                    type="submit"
                    className="btn btn-primary"
                    onClick={this.onSave}
                  >
                    Next
                  </button>
                )}
              </div>
            </form>
          </div>
        </div>
      </div>
    );
  }
}

export default BusinessDetails;
