import React from "react";
import { withRouter } from "react-router-dom";

import Validator from "validator";
import isEmpty from "../../utils/isEmpty";

import services from "../../services";

class AccountVerification extends React.Component {
  state = {
    vCode1: "",
    vCode2: "",
    vCode3: "",
    vCode4: "",
    errors: {},
  };

  onChange = (e) => {
    const { name, value } = e.target;

    this.setState({ [name]: value, errors: {} }, async () => {
      this.validationForm({ key: name });
    });
  };

  onSubmit = async (e) => {
    e.preventDefault();

    /** Check form validations */
    if (
      this.validationForm({ submitted: true }) &&
      !isEmpty(this.props.match.params.email)
    ) {
      const formData = {
        verificationkey:
          this.state.vCode1 +
          this.state.vCode2 +
          this.state.vCode3 +
          this.state.vCode4,
        email: this.props.match.params.email,
      };

      services.userManagementServices
        .verifyAccount(formData)
        .then((success) => {
          let redirectPath = "/signupConfirmation";
          this.props.history.push(redirectPath);
        })
        .catch((err) => {
          let errors = err;
          this.setState({ errors });
        });
    }
  };

  validationForm = ({ key = null, submitted = false }) => {
    const errors = {};

    if (
      this.state.vCode1 &&
      this.state.vCode2 &&
      this.state.vCode3 &&
      this.state.vCode4 &&
      (!Validator.isDecimal(this.state.vCode1) ||
        !Validator.isDecimal(this.state.vCode2) ||
        !Validator.isDecimal(this.state.vCode3) ||
        !Validator.isDecimal(this.state.vCode4)) &&
      (key === "vCode1" ||
        key === "vCode2" ||
        key === "vCode3" ||
        key === "vCode4" ||
        submitted)
    ) {
      errors.verificationCodeErrorMessage = "Please enter numbers only";
    }
    this.setState({ errors });
    return isEmpty(errors);
  };

  /** Resend verification code to email */
  resendVerificationCode = async () => {
    services.userManagementServices
      .resendVerificationCode({ email: this.props.match.params.email })
      .then((success) => {
        if (success) {
          this.setState({
            errors: {
              otpSuccessMessage: "OTP is reset, please check the mail",
            },
          });
        }
      })
      .catch((err) => {
        // alert("There is a Pbm in Sending Request");
        let errors = JSON.parse(err.message);
        this.setState({ errors });
      });
  };

  render() {
    const errors = !isEmpty(this.state.errors) ? this.state.errors : "";
    console.log(errors);
    return (
      <div className="layout">
        <div className="container-fluid p-0">
          <div className="account-ver-content">
            <div className="half-arc"></div>
            <div className="row no-gutters justify-content-center align-items-center">
              <div className="env-icon">
                <svg>
                  <use xlinkHref="assets/img/up-sprite.svg#envelope"></use>
                </svg>
              </div>

              <div className="acc-ver-content">
                <form>
                  <p className="acc-header-txt">Please Verify Account</p>
                  <p className="acc-body-txt">
                    Enter the 4 digit code we sent to your
                    <br />
                    email id{" "}
                    <span className="link-a">
                      {this.props.match.params.email}
                    </span>
                    {/* ashok.palakirthi@msr-it.com */}
                  </p>

                  <div className="acc-code-box">
                    <div className="flex-item">
                      <input
                        type="text"
                        name="vCode1"
                        placeholder="0"
                        className="form-control"
                        maxlength="1"
                        autofocus
                        oninput="this.value=this.value.replace(/[^0-9]/g,'');"
                        value={this.state.vCode1}
                        onChange={this.onChange}
                      />
                    </div>
                    <div className="flex-item">
                      <input
                        type="text"
                        name="vCode2"
                        placeholder="0"
                        className="form-control"
                        maxlength="1"
                        oninput="this.value=this.value.replace(/[^0-9]/g,'');"
                        value={this.state.vCode2}
                        onChange={this.onChange}
                      />
                    </div>
                    <div className="flex-item">
                      <input
                        type="text"
                        name="vCode3"
                        placeholder="0"
                        className="form-control"
                        maxlength="1"
                        oninput="this.value=this.value.replace(/[^0-9]/g,'');"
                        value={this.state.vCode3}
                        onChange={this.onChange}
                      />
                    </div>
                    <div className="flex-item">
                      <input
                        type="text"
                        name="vCode4"
                        placeholder="0"
                        className="form-control"
                        maxlength="1"
                        oninput="this.value=this.value.replace(/[^0-9]/g,'');"
                        value={this.state.vCode4}
                        onChange={this.onChange}
                      />
                    </div>
                  </div>

                  {errors && (
                    <p className="text-danger">
                      {errors.verificationCodeErrorMessage}
                    </p>
                  )}

                  <div className="row">
                    <div className="col-12 blue-btn">
                      <button
                        type="submit"
                        className="btn px-5 py-2 border-0"
                        onClick={(e) => this.onSubmit(e)}
                      >
                        Verify & Continue
                      </button>
                    </div>
                  </div>

                  {/* <p className="error">
                    Your have enter invalid code,
                    <br />
                    try again or click Resend link below
                  </p> */}
                  {errors && <p className="text-danger">{errors.message}</p>}

                  {errors && !isEmpty(errors.otpSuccessMessage) && (
                    <p className="text-success">{errors.otpSuccessMessage}</p>
                  )}

                  <p className="acc-footer-txt mt-3">
                    Didn't got the code?&nbsp;
                    <a
                      onClick={this.resendVerificationCode}
                      className="link-a"
                      style={{ color: "var(--info)" }}
                    >
                      RESEND CODE
                    </a>
                  </p>
                </form>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }
}

export default withRouter(AccountVerification);
