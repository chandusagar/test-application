import React from "react";
import BusinessDetails from "./BusinessDetails";
import PersonalDetails from "./PersonalDetails";
import Confirm from "./Confirm";

class Signup extends React.Component {
  state = {
    activeStep: 1,
    confirmDetails: {},
  };

  activeTab = (step, obj, flag) => {
    let confirmDetails = JSON.parse(JSON.stringify(this.state.confirmDetails));
    if (step === 2) {
      confirmDetails.business = obj;
    } else if (step === 3) {
      confirmDetails.personal = obj;
    }
    this.setState({ activeStep: flag ? 3 : step, confirmDetails });
  };

  editDetails = (id) => {
    this.setState({ activeStep: id });
  };

  render() {
    return (
      <div className="d-flex flex-column flex-root">
        <div className="login login-1 login-signin-on d-flex flex-column flex-lg-row flex-column-fluid">
          <div className="login-aside d-flex flex-column flex-row-auto">
            <div className="d-flex flex-column-auto flex-column pt-lg-30 pt-10 mx-11">
              <a className="text-center mb-10 px-3">
                <img src="assets/img/logo.svg" alt="logo" className="h-60px" />
                <span className="ml-2 font-weight-bolder text-center h5 text-white">
                  Unified Track & Trace
                </span>
              </a>
              <div className="uc-supplyflow">
                <div
                  className={
                    this.state.activeStep === 1
                      ? "uc-supplyflow__item uc-supplyflow__item--active"
                      : "uc-supplyflow__item uc-supplyflow__item--deactive"
                  }
                  // onClick={() => this.editDetails(1)}
                >
                  <span className="uc-supplyflow__item-section">
                    <div className="uc-supplyflow__item-section-border">
                      <div className="uc-supplyflow__item-section-icon">
                        <i className="fa fa-circle uc-font-icon"></i>
                      </div>
                    </div>
                    <div className="uc-supplyflow__item-text">
                      Business Details
                    </div>
                  </span>
                </div>
                <div
                  className={
                    this.state.activeStep === 2
                      ? "uc-supplyflow__item uc-supplyflow__item--active"
                      : "uc-supplyflow__item uc-supplyflow__item--deactive"
                  }
                  // onClick={() => this.editDetails(2)}
                >
                  <span className="uc-supplyflow__item-section">
                    <div className="uc-supplyflow__item-section-border">
                      <div className="uc-supplyflow__item-section-icon">
                        <i className="fa fa-circle uc-font-icon"></i>
                      </div>
                    </div>
                    <div className="uc-supplyflow__item-text">
                      Personal Details
                    </div>
                  </span>
                </div>
                <div
                  className={
                    this.state.activeStep === 3
                      ? "uc-supplyflow__item uc-supplyflow__item--active"
                      : "uc-supplyflow__item uc-supplyflow__item--deactive"
                  }
                  // onClick={() => this.editDetails(3)}
                >
                  <span className="uc-supplyflow__item-section">
                    <div className="uc-supplyflow__item-section-border">
                      <div className="uc-supplyflow__item-section-icon">
                        <i className="fa fa-truck-loading uc-font-icon"></i>
                      </div>
                    </div>
                    <div className="uc-supplyflow__item-text">Confirm</div>
                  </span>
                </div>
              </div>
            </div>
          </div>

          {this.state.activeStep === 1 ? (
            <BusinessDetails
              activeTab={(id, obj, flag) => this.activeTab(id, obj, flag)}
              confirmDetails={this.state.confirmDetails}
            />
          ) : this.state.activeStep === 2 ? (
            <PersonalDetails
              activeTab={(id, obj, flag) => this.activeTab(id, obj, flag)}
              confirmDetails={this.state.confirmDetails}
            />
          ) : this.state.activeStep === 3 ? (
            <Confirm
              confirmDetails={this.state.confirmDetails}
              editDetails={(id) => this.editDetails(id)}
            />
          ) : (
            ""
          )}
        </div>
      </div>
    );
  }
}

export default Signup;
