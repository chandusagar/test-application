import React from "react";
import { connect } from "react-redux";
import { withRouter } from "react-router-dom";

import TextFieldGroup from "../../../common/TextFieldGroup";
import SelectListGroup from "../../../common/SelectListGroup";
import SelectComponent from "../../../common/SelectComponent";

import {
  showSupplierModel,
  supplierRawMeterial,
  supplierRawMeterialDelete,
} from "../../../../actions/supplierAction";

import isEmpty from "../../../../utils/isEmpty";

class IntegrateManually extends React.Component {
  state = {
    listId: null,
    id: null,
    deleteIndex: null,
    addProduct: false,
    systemDetails: [],
    systemList: [],
  };

  componentDidMount() {
    this.setStoreData();
    const pathname = this.props.location.pathname;
    if (pathname.indexOf("editsupplier") === 1) {
      this.props.showSupplierModel(false);
    }
  }

  /** Set state Raw material data from props */
  setStoreData = () => {
    let systemDetails = this.props.supplier.systemDetails;
    let systemList =
      systemDetails.length > 0
        ? systemDetails
        : [
            {
              name: "",
              image: "",
              location: "",
              quantity: "",
              units: "",
              date: "",
              time: "",
            },
          ];

    let Id = systemDetails.length > 0 ? systemDetails.length : 1;
    // this.showMaterialDetails(Id - 1);
    this.props.showSupplierModel(true);
    const perview = this.props.editperview;

    if (perview.id) {
      this.showMaterialDetails(perview.id - 1);
    } else {
      this.showMaterialDetails(Id - 1);
    }

    this.setState({
      systemList: systemList,
      systemDetails: systemList,
      id: Id,
    });
  };

  addMaterialDetails = (id, from) => {
    let clear = from;
    let obj = {
      name: "",
      image: "",
      location: "",
      quantity: "",
      units: "",
      date: "",
      time: "",
    };
    let systemList = Array.from(this.state.systemList);
    if (!isEmpty(clear)) {
      systemList[id] = obj;
    } else {
      systemList.push(obj);
    }

    this.setState({ systemList, id: id + 1, listId: id, addProduct: false });

    this.props.showSupplierModel(true);
  };

  clearList = (index) => {
    this.addMaterialDetails(index, "clear");
  };

  showMaterialDetails = (id) => {
    let listid = null;
    if (id !== this.state.listId) {
      listid = id;
    } else {
      listid = null;
    }

    this.setState({
      listId: listid,
    });
  };

  deleteMaterialDetails = (id) => {
    this.setState({
      deleteIndex: id,
    });
  };

  /**index based on raw material details delete from props */
  deleteList = (id) => {
    let systemList = Array.from(this.state.systemList);
    systemList.splice(id, 1);

    this.setState({
      systemList,
      id: id,
      listId: id - 1,
    });

    if (this.props.supplier.systemDetails[id]) {
      this.props.supplierRawMeterialDelete(id);
    }
  };

  onChange = (e, index) => {
    const { name, value, files } = e.target;
    let systemlist = JSON.parse(JSON.stringify(this.state.systemList));

    if (name === "image") {
      let reader = new FileReader();
      reader.onload = () => {
        if (reader.readyState === 2) {
          let obj = {
            name: files[0].name,
            type: files[0].type,
            doc: reader.result,
          };
          systemlist[index].ShowImage = obj;
          this.setState({ systemList: systemlist });
        }
      };
      reader.readAsDataURL(files[0]);
    }
    console.log(name, value);
    systemlist[index][name] = value;

    this.setState({ systemList: systemlist, errors: {} }, async () => {
      this.validateForm({ key: name, i: index });
    });
  };

  saveDetails = async (e, list, index) => {
    e.preventDefault();
    if (this.validateForm({ submitted: true })) {
      let listobj = Object.assign({}, list);
      delete listobj.errors;
      let systemDetails = Array.from(this.state.systemDetails);
      systemDetails[index] = listobj;

      this.setState({
        systemDetails,
        addProduct: true,
        listId: null,
      });
      this.props.saveDetails(3, systemDetails, "system", index);

      this.props.showSupplierModel(false);
    } else {
      this.props.showSupplierModel(true);

      this.setState({
        addProduct: false,
      });
    }
  };

  /** validations for add data Raw material form */
  validateForm = ({ key = null, index = -1, submitted = false }) => {
    if (index >= 0) {
      let { validationStatus } = this.validationOnLoop({
        key,
        index,
        submitted,
      });

      return validationStatus;
    } else {
      let status = false;

      const formData = JSON.parse(JSON.stringify(this.state.systemList));

      for (let i = 0; i < formData.length; i++) {
        let { validationStatus } = this.validationOnLoop({
          index: i,
          submitted,
        });

        if (!validationStatus) return validationStatus;
        else status = validationStatus;
      }

      return status;
    }
  };

  /** Validate form data based on index */
  validationOnLoop = ({ key = null, index = null, submitted = false }) => {
    let validateData = JSON.parse(JSON.stringify(this.state.systemList));

    validateData[index].errors = {};

    if (isEmpty(validateData[index].name) && (key === "name" || submitted)) {
      validateData[index].errors.name = "Raw Material Name is required";
    }

    if (isEmpty(validateData[index].image) && (key === "image" || submitted)) {
      validateData[index].errors.image =
        "Upload Raw Material image is required";
    }

    if (
      isEmpty(validateData[index].location) &&
      (key === "location" || submitted)
    ) {
      validateData[index].errors.location = "Storage Unit Location is required";
    }

    if (
      isEmpty(validateData[index].quantity) &&
      (key === "quantity" || submitted)
    ) {
      validateData[index].errors.quantity = "Quantity is required";
    }

    if (isEmpty(validateData[index].units) && (key === "units" || submitted)) {
      validateData[index].errors.units = "Units is required";
    }

    this.setState({ systemList: validateData });

    return { validationStatus: isEmpty(validateData[index].errors) };
  };

  /** storage location function */
  storeLocation = () => {
    let storeDetails = this.props.supplier.storeDetails;
    let arr = [];
    storeDetails.forEach((item, i) => {
      let obj = {
        name: `${item.name} (${item.supplierName})`,
        value: item.supplierName,
      };

      arr.push(obj);
    });
    return arr;
  };

  /**quantity list function */
  quantityNames = () => {
    return ["10", "20", "30", "40", "50"];
  };

  /**units list function */
  unitNames = () => {
    return ["PC", "Box"];
  };

  render() {
    return (
      <div>
        {this.state.systemList.map((list, index) => (
          <div className="accordion mt-1" id="accordion-1" key={index}>
            <div className="card m-0">
              <div className="card-header" id="headingOne">
                <h2 className="mb-0">
                  <button
                    className="btn accordionBtn ml-2"
                    type="button"
                    onClick={() => this.showMaterialDetails(index)}
                  >
                    Raw Material_{index + 1}
                  </button>
                  {this.state.systemDetails[index] &&
                  this.state.systemDetails[index].name ? (
                    <label>
                      Name of the Raw Material :
                      <span class="sub-txt-header">
                        {this.state.systemDetails[index].name}
                      </span>
                    </label>
                  ) : (
                    ""
                  )}
                </h2>
              </div>
              <div
                className={index === this.state.listId ? "show" : "collapse"}
              >
                <form>
                  <div className="p-w-content">
                    {this.state.systemList.length > 1 ? (
                      <span
                        class="del-icon"
                        data-toggle="modal"
                        data-target="#modal_01"
                        onClick={() => this.deleteMaterialDetails(index)}
                      >
                        <i class="fa fa-trash"></i>
                      </span>
                    ) : (
                      ""
                    )}

                    <div className="row">
                      <div className="col-lg-6 col-xl-6 order-lg-1 order-xl-1">
                        <div className="form-group">
                          <TextFieldGroup
                            label="Raw Material Name"
                            type="text"
                            name="name"
                            value={this.state.systemList[index].name}
                            onChange={(e) => this.onChange(e, index)}
                            placeholder="Enter Raw Material Name"
                            error={list.errors && list.errors.name}
                          />
                        </div>
                      </div>
                    </div>
                  </div>
                  <div className="p-w-content mt-2">
                    <div className="row">
                      <div className="col-lg-6 col-xl-6 order-lg-1 order-xl-1">
                        <div className="form-group">
                          <label>
                            Upload Raw Material image
                            <span className="astric">*</span>
                          </label>
                          <div className="custom-file">
                            <input
                              type="file"
                              className="custom-file-input"
                              id="customFile"
                              name="image"
                              onChange={(e) => this.onChange(e, index)}
                            />
                            <label className="custom-file-label">
                              {this.state.systemList[index].ShowImage
                                ? this.state.systemList[index].ShowImage.name
                                : " Broswse the image file"}
                            </label>
                            {list.errors ? (
                              <p className="text-danger text-small">
                                {list.errors && list.errors.image}
                              </p>
                            ) : (
                              ""
                            )}
                          </div>
                        </div>
                        {this.state.systemList[index].image ? (
                          <img
                            src={
                              this.state.systemList[index].ShowImage &&
                              this.state.systemList[index].ShowImage.doc
                                ? this.state.systemList[index].ShowImage.doc
                                : ""
                            }
                            alt=""
                            style={{ width: "120px", height: "120px" }}
                          />
                        ) : (
                          ""
                        )}
                      </div>
                    </div>

                    <div className="row">
                      <div className="col-lg-6 col-xl-6 order-lg-1 order-xl-1">
                        <div className="form-group">
                          <SelectComponent
                            label="Storage unit Location"
                            onChange={(e) => this.onChange(e, index)}
                            options={this.storeLocation()}
                            name="location"
                            value={list.location}
                            error={list.errors && list.errors.location}
                          />
                        </div>
                      </div>
                    </div>
                    <div className="row">
                      <div className="col-lg-6 col-xl-6 order-lg-1 order-xl-1">
                        <div className="form-row">
                          <div className="form-group col-md-4">
                            <SelectListGroup
                              label="Quantity"
                              onChange={(e) => this.onChange(e, index)}
                              options={this.quantityNames()}
                              name="quantity"
                              value={list.quantity}
                              error={list.errors && list.errors.quantity}
                            />
                          </div>

                          <div className="form-group col-md-4">
                            <SelectListGroup
                              label="Units"
                              onChange={(e) => this.onChange(e, index)}
                              options={this.unitNames()}
                              name="units"
                              value={list.units}
                              error={list.errors && list.errors.units}
                            />
                          </div>
                          {/* <div className="form-group col-md-3">
                          <label for="inputZip">Date</label>
                          <input
                            type="text"
                            className="form-control"
                            id="date"
                          />
                        </div>
                        <div className="form-group col-md-3">
                          <label for="inputZip">Time</label>
                          <input
                            type="text"
                            className="form-control"
                            id="time"
                          />
                        </div> */}
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="p-w-content mt-2">
                    <div className="row">
                      <div className="col-lg-6 col-xl-6 order-lg-1 order-xl-1">
                        <div className="bottom-btn">
                          <button
                            type="button"
                            className="btn btn-primary-ghost mr-2"
                            onClick={() => this.clearList(index)}
                          >
                            Clear
                          </button>
                          <button
                            type="submit"
                            className="btn btn-primary"
                            onClick={(e) => this.saveDetails(e, list, index)}
                          >
                            Save
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                </form>
              </div>
            </div>
          </div>
        ))}
        <div className="add-btn-content">
          <div className="p-w-content">
            <button
              className="btn btn-add-ghost"
              disabled={!this.state.addProduct}
              onClick={() => this.addMaterialDetails(this.state.id)}
            >
              <i className="la la-plus-square mr-1"></i> Add another Item /
              Product
            </button>
          </div>
        </div>

        <div className="modal fade" id="modal_01" tabindex="-1" role="dialog">
          <div className="modal-dialog" role="document">
            <div className="modal-content">
              <div className="modal-header">
                <h5 className="modal-title">
                  Delete Raw Material Details of Supplier_
                  {this.state.deleteIndex + 1}
                </h5>
                <button
                  type="button"
                  className="close btn btn-round"
                  data-dismiss="modal"
                  aria-label="Close"
                >
                  <i className="material-icons">close</i>
                </button>
              </div>
              <div className="modal-body">
                <p className="modal-txt m-0">This can't be undone.</p>
                <p>
                  - Supplier_{this.state.deleteIndex + 1} Raw Material Details.
                </p>
              </div>
              <div className="modal-footer">
                <button
                  type="button"
                  className="btn btn-primary-ghost"
                  data-dismiss="modal"
                >
                  Cancel
                </button>
                <button
                  type="button"
                  className="btn btn-danger"
                  data-dismiss="modal"
                  onClick={() => this.deleteList(this.state.deleteIndex)}
                >
                  Delete
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }
}
const mapStateToProps = (state) => ({
  supplier: state.supplier,
});
export default connect(mapStateToProps, {
  showSupplierModel,
  supplierRawMeterial,
  supplierRawMeterialDelete,
})(withRouter(IntegrateManually));

//   export default connect(mapStateToProps, {})(SystemIntigrate);
