import React from "react";
import IntegrateExisting from "./IntegrateExisting";
import IntegrateManually from "./IntegrateManually";
import ExcelSheet from "./ExcelSheet";
import DataTable from "./DataTable";

class SystemIntigrate extends React.Component {
  state = {
    activeStep: 1,
    excelSheet: false,
    excelData: null,

    column: [
      { field: "rawMaterialId", header: "Raw Material Id" },
      { field: "name", header: "Name" },
      { field: "quantity", header: "Quantity" },
      { field: "units", header: "Units" },
      { field: "image", header: "Image" },
      { field: "date", header: "Date" },
      { field: "location", header: "Location" },
    ],
    details: [],
  };

  componentDidMount() {
    this.setActiveTab();
  }

  setActiveTab = () => {
    const perview = this.props.editperview;

    let id;
    let excelSheet = false;
    let data = {};
    if (perview.flag === "existing") {
      id = 1;
    } else if (perview.flag === "rawMaterial") {
      id = 2;
    } else if (perview.flag === "import") {
      excelSheet = true;
      data = perview.id;
      console.log(data);
    }
    let activeId = id ? id : 1;

    if (excelSheet) {
      this.setState({
        excelSheet: true,
        excelData: data,
        details: data && data.fileData ? data.fileData : [],
      });
      this.moveStep(0);
    } else {
      this.moveStep(activeId);
    }
    // let activeId = id ? id : 1;
    // this.moveStep(activeId);

    // }
  };

  moveStep = (step) => {
    this.setState({
      activeStep: step,
    });
  };

  /**import excel sheet priview details */
  priview = (id, file, flag) => {
    console.log(id, file, flag);
    this.setState({
      excelSheet: flag,
      activeStep: id,
      excelData: file,
      details: file && file.fileData ? file.fileData : [],
    });
  };

  modifyColums = (rowData, col) => {
    switch (col.field) {
      case "quantity":
        return (
          <span>
            {rowData.quantity}
            <div>{rowData.productCategory}</div>
          </span>
        );
      case "productImage":
        return (
          <div className="pack-image">
            <img src={rowData.productImage} alt="package-image" />
          </div>
        );
      default:
        return rowData[col.field];
    }
  };

  render() {
    return (
      <div className="row">
        <div className="col-md-12">
          <div className="stepper-content">
            {!this.state.excelSheet ? (
              <div className="p-w-content mt-2">
                <div className="row">
                  <div className="col-lg-6 col-xl-6 order-lg-1 order-xl-1">
                    <div
                      className="btn-toolbar d-none d-md-block mb-1 btn-toggle"
                      role="toolbar"
                      aria-label="Toolbar with buttons"
                    >
                      <div
                        className="btn-group btn-group-toggle"
                        data-toggle="buttons"
                      >
                        <label
                          className={
                            this.state.activeStep === 1
                              ? "btn btn-outline-secondary active"
                              : "btn btn-outline-secondary"
                          }
                          onClick={() => this.moveStep(1)}
                        >
                          Integrate Existing System
                        </label>
                        <label
                          className={
                            this.state.activeStep === 2
                              ? "btn btn-outline-secondary active"
                              : "btn btn-outline-secondary"
                          }
                          onClick={() => this.moveStep(2)}
                        >
                          Integrate Manually
                        </label>
                        <label
                          className={
                            this.state.activeStep === 3
                              ? "btn btn-outline-secondary active"
                              : "btn btn-outline-secondary"
                          }
                          onClick={() => this.moveStep(3)}
                        >
                          Import excel sheet
                        </label>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            ) : (
              ""
            )}
            {this.state.activeStep === 1 ? (
              <IntegrateExisting
                saveDetails={(id, obj, flag) =>
                  this.props.saveDetails(id, obj, flag)
                }
              />
            ) : this.state.activeStep === 3 ? (
              <ExcelSheet
                priview={(id, file, flag) => this.priview(id, file, flag)}
              />
            ) : (
              ""
            )}

            {this.state.excelSheet ? (
              <>
                <div className="p-w-content">
                  <div className="text-small"> Import excel sheet </div>
                </div>
                <hr className="m-0" />
                <DataTable
                  respData={this.state.details}
                  column={this.state.column}
                  modifyColums={(rowData, col) =>
                    this.modifyColums(rowData, col)
                  }
                  excelData={this.state.excelData}
                  priview={(id, file, flag) => this.priview(id, file, flag)}
                  saveDetails={(id, obj, flag) =>
                    this.props.saveDetails(id, obj, flag)
                  }
                />
              </>
            ) : (
              ""
            )}
          </div>

          {this.state.activeStep === 2 ? (
            <IntegrateManually
              editperview={this.props.editperview}
              saveDetails={(id, obj, flag, index) =>
                this.props.saveDetails(id, obj, flag, index)
              }
            />
          ) : (
            ""
          )}
        </div>
      </div>
    );
  }
}

export default SystemIntigrate;
