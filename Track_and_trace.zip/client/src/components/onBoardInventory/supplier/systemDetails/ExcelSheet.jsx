import React from "react";
import XLSX from "xlsx";
import { connect } from "react-redux";
import { withRouter } from "react-router-dom";
import Moment from "moment";

import isEmpty from "../../../../utils/isEmpty";

import { showSupplierModel } from "../../../../actions/supplierAction";

class ExcelSheet extends React.Component {
  state = {
    fileName: "",
    fileData: [],
    errors: {},
  };

  componentDidMount() {
    const pathname = this.props.location.pathname;
    if (pathname.indexOf("editsupplier") === 1) {
      this.props.showSupplierModel(false);
    }
  }

  onSave = async (e) => {
    e.preventDefault();
    if (this.validateForm({ submitted: true })) {
      const formData = Object.assign({}, this.state);
      delete formData.errors;
      this.props.priview(null, formData, true);
    } else {
      this.setState((prevState) => {
        prevState.fileName = "";
        return prevState;
      });
    }
  };

  /*reset file function* */
  reset = () => {
    this.setState((prevState) => {
      prevState.fileName = "";
      prevState.fileData = [];
      return prevState;
    });
  };

  onChange = (e) => {
    const { name, files } = e.target;

    let selectFile = null;
    if (files && files[0]) {
      selectFile = files[0].name.split(".").pop();
    }

    if (
      name === "fileName" &&
      (selectFile === "csv" || selectFile === "xlsx" || selectFile === "xls")
    ) {
      const reader = new FileReader();
      const rABS = !!reader.readAsBinaryString;

      reader.onload = (e) => {
        const bstr = e.target.result;
        const wb = XLSX.read(bstr, {
          type: rABS ? "binary" : "array",
          bookVBA: true,
          cellDates: true,
        });

        const wsname = wb.SheetNames[0];
        const ws = wb.Sheets[wsname];
        console.log("chandu", wsname, "sagar", ws);

        const data = XLSX.utils.sheet_to_json(ws);

        data.forEach((value) => {
          let date = Moment(value.date).format("DD/MM/YYYY");
          if (value.date) value.date = date;

          if (value.quantity) value.quantity = value.quantity.toString();
        });

        this.setState(
          {
            fileName: files[0].name,
            fileData: data,
            errors: {},
          },
          () => {
            this.validateForm({ key: data });
          }
        );
      };

      if (rABS) {
        reader.readAsBinaryString(files[0]);
      } else {
        reader.readAsArrayBuffer(files[0]);
      }
    }
  };

  validateForm = ({ key = null, submitted = false }) => {
    const formData = JSON.parse(JSON.stringify(this.state.fileData));
    const errors = {};
    let fileName = this.state.fileName;

    if (!isEmpty(formData)) {
      for (let i = 0; i < formData.length; i++) {
        if (isEmpty(formData[i].rawMaterialId && submitted)) {
          errors.rawMaterialId = `Raw Material id ${i + 1} is required.`;
        }

        if (isEmpty(formData[i].name && submitted)) {
          errors.name = `Raw Material Name ${i + 1} is required.`;
        }
        if (isEmpty(formData[i].quantity && submitted)) {
          errors.quantity = `Raw Material quantity ${i + 1} is required.`;
        }
        if (isEmpty(formData[i].units && submitted)) {
          errors.units = `Raw Material units ${i + 1} is required.`;
        }
        if (isEmpty(formData[i].location && submitted)) {
          errors.location = `Raw Material location ${i + 1} is required.`;
        }
        if (isEmpty(formData[i].date && submitted)) {
          errors.date = `Raw Material date ${i + 1} is required.`;
        }
        if (isEmpty(formData[i].image && submitted)) {
          errors.image = `Raw Material image ${i + 1} is required.`;
        }

        if (
          (formData[0] && !formData[0].rawMaterialId) ||
          !formData[0].name ||
          !formData[0].quantity ||
          !formData[0].units ||
          !formData[0].image
        ) {
          errors.rawMaterialId = `Invalid excel sheet.`;
        }
      }
    } else {
      errors.rawMaterialId = `You have uploaded with Empty data, Please add some data`;
      fileName = "";
    }

    this.setState({ errors, fileName });
    return isEmpty(errors);
  };

  render() {
    const { errors } = this.state;

    return (
      <>
        <div className="p-w-content mt-2">
          <div className="row">
            <div className="col-lg-6 col-xl-6 order-lg-1 order-xl-1">
              {this.state.fileName ? (
                <div className="upload-file-wrapper active">
                  <input
                    type="file"
                    name="fileName"
                    onChange={(e) => this.onChange(e)}
                  />
                  <div className="file-cont">
                    <div className="file-cont-text">
                      <p className="file-text-u-header">
                        <span className="upload-file"></span>
                        {this.state.fileName ? this.state.fileName : ""}
                        {/* Raw Material details.xlsx */}
                      </p>
                    </div>
                    <div className="file-cont-btn ">
                      <i className="fas fa-upload f-upload"></i>
                      <label className="f-upload">Upload file</label>
                    </div>
                  </div>
                </div>
              ) : (
                <div className="upload-file-wrapper">
                  <input
                    type="file"
                    name="fileName"
                    onChange={(e) => this.onChange(e)}
                    onClick={(e) => (e.target.value = null)}
                  />
                  <div className="file-cont">
                    <div className="file-cont-text">
                      <p className="file-text-header m-0">
                        Browse to upload file
                      </p>
                      <p className="file-text-sub-header">
                        Note: Column names of the excel sheet should match the
                        following Order to upload.
                      </p>

                      {errors && errors.rawMaterialId ? (
                        <p className="file-text-sub-header">
                          {errors.rawMaterialId}
                        </p>
                      ) : errors && errors.name ? (
                        <p className="file-text-sub-header">{errors.name}</p>
                      ) : errors && errors.quantity ? (
                        <p className="file-text-sub-header">
                          {errors.quantity}
                        </p>
                      ) : errors && errors.units ? (
                        <p className="file-text-sub-header">{errors.units}</p>
                      ) : errors && errors.image ? (
                        <p className="file-text-sub-header">{errors.image}</p>
                      ) : (
                        ""
                      )}
                      <p className="file-upload-format">
                        {/* S. No,Package Id, Supplier Details,Raw material name */}
                        rawMaterialId,name,image,quantity,units,date,location
                      </p>
                    </div>
                    <div className="file-cont-btn">
                      <i className="fas fa-upload"></i>
                      <label>Upload file</label>
                    </div>
                  </div>
                </div>
              )}

              {this.state.fileName ? (
                <div class="bottom-btn mt-3">
                  <button
                    type="button"
                    className="btn btn-primary-ghost mr-2 px-3"
                    onClick={() => this.reset()}
                  >
                    {/* this.props.priview(3, this.state, false) */}
                    Clear
                  </button>
                  <button
                    type="button"
                    className="btn btn-primary px-3"
                    onClick={(e) => this.onSave(e)}
                  >
                    Perview
                  </button>
                </div>
              ) : (
                ""
              )}
            </div>
          </div>
        </div>
      </>
    );
  }
}

const mapStateToProps = (state) => ({});

export default connect(mapStateToProps, {
  showSupplierModel,
})(withRouter(ExcelSheet));
