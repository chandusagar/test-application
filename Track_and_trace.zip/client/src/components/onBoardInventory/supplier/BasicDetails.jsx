import React from "react";
import { connect } from "react-redux";
import { withRouter } from "react-router-dom";
import Validator from "validator";

/**import google Map component */
import Map from "../supplier/GoogleMap/Map";
import SearchLocation from "./GoogleMap/SearchLocation";

/**import common files */
import SelectListGroup from "../../common/SelectListGroup";
import TextFieldGroup from "../../common/TextFieldGroup";

/** loading Basic Details actions */
import {
  showSupplierModel,
  showActiveTabsClear,
  supplierBasicDetails,
  supplierBasicDetailsDelete,
  supplierStoreDetailsDelete,
  supplierRawMeterialDelete,
} from "../../../actions/supplierAction";

/**import config validations */
import isEmpty from "../../../utils/isEmpty";

class BasicDetails extends React.Component {
  state = {
    listId: null,
    id: null,
    deleteIndex: null,
    addSupplier: false,
    basicDetails: [],
    basicList: [],
    setLocation: "",
    valueCount: false,
  };

  componentDidMount() {
    this.setBasicData();
  }

  componentDidUpdate(prevProps) {
    if (prevProps.supplier.basicDetails !== this.props.supplier.basicDetails) {
      this.setBasicData();
    }
  }

  /** Set state basic Details data from props */
  setBasicData = () => {
    let basicDetails = this.props.supplier.basicDetails;
    basicDetails.forEach((item, i) => {
      item.latitude = Number(item.latitude);
      item.longitude = Number(item.longitude);
    });

    let basicList =
      basicDetails.length > 0
        ? basicDetails
        : [
            {
              type: "",
              name: "",
              emailId: "",
              phoneNo: "",
              address: "",
              city: "",
              state: "",
              country: "",
              zipCode: "",
              latitude: "",
              longitude: "",
            },
          ];

    let Id = basicDetails.length > 0 ? basicDetails.length : 1;

    this.props.showSupplierModel(true);
    const perview = this.props.editperview;
    if (perview.id) {
      this.showBasicDetails(perview.id - 1);
    } else {
      if (!this.state.valueCount) {
        this.setState({ valueCount: true }, async () => {
          this.props.showActiveTabsClear();
          this.showBasicDetails(Id - 1);
        });
      }
    }

    this.setState({
      basicList: basicList,
      basicDetails: basicList,
      id: Id,
    });
  };

  /** Basic details adding function */
  addBasicDetails = (id, from) => {
    let clear = from;
    let obj = {
      type: "",
      name: "",
      emailId: "",
      phoneNo: "",
      address: "",
      city: "",
      state: "",
      country: "",
      zipCode: "",
      latitude: "",
      longitude: "",
    };

    let basicList = Array.from(this.state.basicList);
    if (!isEmpty(clear)) {
      basicList[id] = obj;
    } else {
      basicList.push(obj);
    }

    this.setState({ basicList, id: id + 1, listId: id, addSupplier: false });

    this.props.showSupplierModel(true);
  };

  /**form input values reset function */
  clearList = (index) => {
    this.addBasicDetails(index, "clear");
  };

  /** Basic details show function */
  showBasicDetails = (id) => {
    let listid = null;
    if (id !== this.state.listId) {
      listid = id;
    } else {
      listid = null;
    }
    this.setState({
      listId: listid,
    });
  };

  /** Basic Details delete function */
  deleteBasicDetails = (id) => {
    this.setState({
      deleteIndex: id,
    });
  };

  /**index based on basic details delete from props */
  deleteList = (id) => {
    let basicList = Array.from(this.state.basicList);
    basicList.splice(id, 1);

    this.setState({
      basicList,
      basicDetails: basicList,
      id: id,
      listId: id - 1,
    });

    /** store to basic Details delete function */
    if (this.props.supplier.basicDetails[id]) {
      let basicDetails = this.props.supplier.basicDetails;
      let storeDetails = this.props.supplier.storeDetails;
      let systemDetails = this.props.supplier.systemDetails;

      basicDetails.forEach((item, i) => {
        if (i == id) {
          this.props.supplierBasicDetailsDelete(id);
          storeDetails.forEach((store, ii) => {
            if (store.supplierName === item.emailId) {
              this.props.supplierStoreDetailsDelete(ii);
              systemDetails.forEach((system, iii) => {
                if (system.location === store.supplierName) {
                  this.props.supplierRawMeterialDelete(iii);
                }
              });
            }
          });
        }
      });

      this.props.saveDetails(1, basicList, "basic", id);
    }
  };

  onChange = (e, index) => {
    const { name, value } = e.target;

    let basicList = JSON.parse(JSON.stringify(this.state.basicList));
    basicList[index][name] = value;

    this.setState({ basicList: basicList, errors: {} }, async () => {
      this.validateForm({ key: name, i: index });
    });
  };

  saveDetails = async (e, list, index) => {
    e.preventDefault();

    if (
      this.validateForm({ submitted: true }) &&
      list.latitude &&
      list.longitude
    ) {
      let latitude = list.latitude.toString();
      let longitude = list.longitude.toString();
      let listobj = Object.assign({}, list);
      delete listobj.errors;
      listobj.latitude = latitude;
      listobj.longitude = longitude;
      let basicDetails = Array.from(this.state.basicDetails);

      basicDetails[index] = listobj;
      console.log(basicDetails);
      this.setState({
        basicDetails,
        addSupplier: true,
        listId: null,
      });
      this.props.saveDetails(1, basicDetails, "basic", index);
      this.props.showSupplierModel(false);
    } else {
      this.props.showSupplierModel(true);

      this.setState({
        addSupplier: false,
      });
    }
  };

  /** validations for add data basic Details form */
  validateForm = ({ key = null, index = -1, submitted = false }) => {
    if (index >= 0) {
      let { validationStatus } = this.validationOnLoop({
        key,
        index,
        submitted,
      });

      return validationStatus;
    } else {
      let status = false;

      const formData = JSON.parse(JSON.stringify(this.state.basicList));

      for (let i = 0; i < formData.length; i++) {
        let { validationStatus } = this.validationOnLoop({
          index: i,
          submitted,
        });

        if (!validationStatus) return validationStatus;
        else status = validationStatus;
      }

      return status;
    }
  };

  /** Validate form data based on index */
  validationOnLoop = ({ key = null, index = null, submitted = false }) => {
    let validateData = JSON.parse(JSON.stringify(this.state.basicList));

    validateData[index].errors = {};

    if (isEmpty(validateData[index].type) && (key === "type" || submitted)) {
      validateData[index].errors.type = "Type is required";
    }

    if (isEmpty(validateData[index].name) && (key === "name" || submitted)) {
      validateData[index].errors.name = "Name is required";
    } else if (
      validateData[index].name &&
      !Validator.isLength(validateData[index].name, { min: 3 })
    ) {
      validateData[index].errors.name = "Name should have minimum 3 characters";
    }

    if (
      isEmpty(validateData[index].emailId) &&
      (key === "emailId" || submitted)
    ) {
      validateData[index].errors.emailId = "Email id is required";
    } else if (
      validateData[index].emailId &&
      !Validator.isEmail(validateData[index].emailId)
    ) {
      validateData[index].errors.emailId = "Email is invalid";
    }

    if (
      isEmpty(validateData[index].phoneNo) &&
      (key === "phoneNo" || submitted)
    ) {
      validateData[index].errors.phoneNo = "Phone number is required";
    } else if (
      (validateData[index].phoneNo &&
        !Validator.isDecimal(validateData[index].phoneNo)) ||
      (validateData[index].phoneNo &&
        !Validator.isMobilePhone(validateData[index].phoneNo, "en-IN"))
    ) {
      validateData[index].errors.phoneNo = "Invalid phone number";
    } else if (
      validateData[index].phoneNo &&
      !Validator.isLength(validateData[index].phoneNo, { min: 10, max: 10 })
    ) {
      validateData[index].errors.phoneNo = "Phone Number min 10 numbers";
    }

    if (
      isEmpty(validateData[index].address) &&
      (key === "address" || submitted)
    ) {
      validateData[index].errors.address = "Address is required";
    } else if (
      validateData[index].address &&
      !Validator.isLength(validateData[index].address, { min: 5 })
    ) {
      validateData[index].errors.address =
        "Address should have minimum 5 characters";
    }

    if (isEmpty(validateData[index].city) && (key === "city" || submitted)) {
      validateData[index].errors.city = "City is required";
    } else if (
      validateData[index].city &&
      !Validator.isLength(validateData[index].city, { min: 3 })
    ) {
      validateData[index].errors.city =
        "City name should have minimum 3 characters";
    }

    if (isEmpty(validateData[index].state) && (key === "state" || submitted)) {
      validateData[index].errors.state = "State is required";
    }

    if (
      isEmpty(validateData[index].country) &&
      (key === "country" || submitted)
    ) {
      validateData[index].errors.country = "Country is required";
    }

    if (
      isEmpty(validateData[index].zipCode) &&
      (key === "zipCode" || submitted)
    ) {
      validateData[index].errors.zipCode = "Zip code is required";
    } else if (
      validateData[index].zipCode &&
      !Validator.isLength(validateData[index].zipCode, { min: 6 })
    ) {
      validateData[index].errors.zipCode =
        "Zip code should have minimum 6 numbers";
    }
    if (
      validateData[index].zipCode &&
      !Validator.isDecimal(validateData[index].zipCode)
    ) {
      validateData[index].errors.zipCode = " Invalid Zip Code";
    }

    this.setState({ basicList: validateData });

    return { validationStatus: isEmpty(validateData[index].errors) };
  };

  productType = () => {
    return ["Dairy Product"];
  };

  /** map to get Details */
  mapDetails = (mapData, i) => {
    if (mapData.query) {
      this.setState({ setLocation: mapData.query });
    } else {
      let addressArr = mapData.address.split(",");
      delete addressArr[addressArr.length - 2];
      delete addressArr[addressArr.length - 1];
      let address = "";
      addressArr.forEach((item) => {
        address += `${item},`;
      });

      this.setState((prevProps) => {
        prevProps.setLocation = "";
        prevProps.basicList[i].address = address;
        prevProps.basicList[i].city = mapData.city;
        prevProps.basicList[i].state = mapData.state;
        prevProps.basicList[i].country = mapData.country;
        prevProps.basicList[i].zipCode = mapData.zipCode;
        prevProps.basicList[i].latitude = mapData.markerPosition.lat;
        prevProps.basicList[i].longitude = mapData.markerPosition.lng;
        return prevProps.basicList;
      });
    }
  };

  render() {
    return (
      <div>
        {this.state.basicList.map((list, index) => (
          <div className="accordion mt-1" id="accordion-1" key={index}>
            <div className="card m-0">
              <div className="card-header" id="headingOne">
                <h2 className="mb-0">
                  <button
                    className="btn accordionBtn ml-2"
                    type="button"
                    onClick={() => this.showBasicDetails(index)}
                  >
                    Supplier Basic Details_{index + 1}
                  </button>

                  {this.state.basicDetails[index] &&
                  this.state.basicDetails[index].name ? (
                    <label>
                      Name of the Supplier :
                      <span class="sub-txt-header">
                        {this.state.basicDetails[index].name}
                      </span>
                    </label>
                  ) : (
                    ""
                  )}
                </h2>
              </div>
              <div
                className={index === this.state.listId ? "show" : "collapse"}
              >
                <div className="row">
                  <div className="col-md-12">
                    <div className="stepper-content">
                      <div className="p-w-content ">
                        {this.state.basicList.length > 1 &&
                        this.props.location.pathname === "/supplier" ? (
                          <span
                            class="del-icon"
                            data-toggle="modal"
                            data-target="#modal_01"
                            onClick={() => this.deleteBasicDetails(index)}
                          >
                            <i class="fa fa-trash"></i>
                          </span>
                        ) : (
                          ""
                        )}
                        <form>
                          <div className="row">
                            <div className="col-lg-6 col-xl-6 order-lg-1 order-xl-1">
                              <div className="form-row">
                                <div className="form-group col-md-6">
                                  <SelectListGroup
                                    label="Type"
                                    onChange={(e) => this.onChange(e, index)}
                                    options={this.productType()}
                                    name="type"
                                    value={list.type}
                                    error={list.errors && list.errors.type}
                                  />
                                </div>
                                <div className="form-group col-md-6">
                                  <TextFieldGroup
                                    label="Supplier Name"
                                    type="text"
                                    name="name"
                                    value={this.state.basicList[index].name}
                                    onChange={(e) => this.onChange(e, index)}
                                    placeholder="Supplier's name"
                                    maxlength={30}
                                    error={list.errors && list.errors.name}
                                  />
                                </div>
                              </div>
                              <div className="form-row">
                                <div className="form-group col-md-6">
                                  <TextFieldGroup
                                    label="Email id"
                                    type="email"
                                    name="emailId"
                                    value={this.state.basicList[index].emailId}
                                    onChange={(e) => this.onChange(e, index)}
                                    placeholder="Enter supplier's Email id"
                                    error={list.errors && list.errors.emailId}
                                    maxlength={32}
                                    disabled={
                                      this.state.basicList[index].emailId &&
                                      this.props.location.pathname.indexOf(
                                        "editsupplier"
                                      ) === 1
                                    }
                                  />
                                </div>
                                <div className="form-group col-md-6">
                                  <TextFieldGroup
                                    label="Phone / Mobile Number"
                                    type="text"
                                    name="phoneNo"
                                    value={this.state.basicList[index].phoneNo}
                                    onChange={(e) => this.onChange(e, index)}
                                    placeholder="000-000-0000"
                                    maxlength={10}
                                    error={list.errors && list.errors.phoneNo}
                                  />
                                </div>
                              </div>

                              {!this.state.basicList[index].longitude &&
                              !this.state.basicList[index].longitude ? (
                                <div className="form-row">
                                  <SearchLocation
                                    mapDetails={(data) =>
                                      this.mapDetails(data, index)
                                    }
                                  />
                                </div>
                              ) : (
                                ""
                              )}

                              <div className="form-group">
                                <label>
                                  Address
                                  <span className="astric">*</span>
                                </label>
                                <textarea
                                  className="form-control"
                                  placeholder="Supplier's company address"
                                  name="address"
                                  value={this.state.basicList[index].address}
                                  onChange={(e) => this.onChange(e, index)}
                                  disabled={true}
                                  rows="3"
                                ></textarea>
                                {list.errors ? (
                                  <p className="text-danger text-small">
                                    {list.errors.address}
                                  </p>
                                ) : (
                                  ""
                                )}
                              </div>
                              <div className="form-row">
                                <div className="form-group col-md-6">
                                  <TextFieldGroup
                                    label="Distric"
                                    type="text"
                                    name="city"
                                    value={this.state.basicList[index].city}
                                    onChange={(e) => this.onChange(e, index)}
                                    placeholder="Distric name"
                                    disabled={true}
                                    error={list.errors && list.errors.city}
                                  />
                                </div>
                                <div className="form-group col-md-6">
                                  <TextFieldGroup
                                    label="State"
                                    type="text"
                                    name="state"
                                    value={this.state.basicList[index].state}
                                    onChange={(e) => this.onChange(e, index)}
                                    placeholder="State name"
                                    disabled={true}
                                    error={list.errors && list.errors.state}
                                  />
                                </div>
                              </div>
                              <div className="form-row">
                                <div className="form-group col-md-6">
                                  <TextFieldGroup
                                    label="Country"
                                    type="text"
                                    name="country"
                                    value={this.state.basicList[index].country}
                                    onChange={(e) => this.onChange(e, index)}
                                    placeholder="Country name"
                                    disabled={true}
                                    error={list.errors && list.errors.country}
                                  />
                                </div>
                                <div className="form-group col-md-6">
                                  <TextFieldGroup
                                    label="Zip Code"
                                    type="text"
                                    name="zipCode"
                                    maxlength={7}
                                    value={this.state.basicList[index].zipCode}
                                    onChange={(e) => this.onChange(e, index)}
                                    disabled={true}
                                    error={list.errors && list.errors.zipCode}
                                  />
                                </div>
                              </div>
                            </div>
                            <div className="col-lg-6 col-xl-6 order-lg-1 order-xl-1">
                              <div class="map-container">
                                <Map
                                  mapStyle={{ height: "337px" }}
                                  defaultDraggable={true}
                                  setLocation={this.state.setLocation}
                                  mapDetails={(data) =>
                                    this.mapDetails(data, index)
                                  }
                                  address={this.state.basicList[index]}
                                  location={{
                                    lat: this.state.basicList[index].latitude
                                      ? this.state.basicList[index].latitude
                                      : 0,
                                    lng: this.state.basicList[index].longitude
                                      ? this.state.basicList[index].longitude
                                      : 0,
                                  }}
                                />
                              </div>
                            </div>
                          </div>
                          <div className="bottom-btn">
                            <button
                              type="button"
                              className="btn btn-primary-ghost mr-2 px-3"
                              onClick={() => this.clearList(index)}
                            >
                              Clear
                            </button>
                            <button
                              type="submit"
                              className="btn btn-primary px-3"
                              onClick={(e) => this.saveDetails(e, list, index)}
                            >
                              Save
                            </button>
                          </div>
                        </form>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        ))}

        {/* {this.props.location.pathname === "/supplier" ? (
          <div className="add-btn-content">
            <div className="p-w-content">
              <button
                className="btn btn-add-ghost"
                disabled={!this.state.addSupplier}
                onClick={() => this.addBasicDetails(this.state.id)}
              >
                <i className="la la-plus-square mr-1"></i> Add another Supplier
              </button>
            </div>
          </div>
        ) : (
          ""
        )} */}

        <div className="modal fade" id="modal_01" tabindex="-1" role="dialog">
          <div className="modal-dialog" role="document">
            <div className="modal-content">
              <div className="modal-header">
                <h5 className="modal-title">
                  Delete Basic Details of Supplier_{this.state.deleteIndex + 1}
                </h5>
                <button
                  type="button"
                  className="close btn btn-round"
                  data-dismiss="modal"
                  aria-label="Close"
                >
                  <i className="material-icons">close</i>
                </button>
              </div>
              <div className="modal-body">
                <p className="modal-txt m-0">This can't be undone.</p>
                <p className="m-0">
                  - Supplier_{this.state.deleteIndex + 1} Basic Details.
                </p>
                <p className="m-0">- Storage Units.</p>
                <p className="m-0">- System Integrate.</p>
              </div>
              <div className="modal-footer">
                <button
                  type="button"
                  className="btn btn-primary-ghost"
                  data-dismiss="modal"
                >
                  Cancel
                </button>
                <button
                  type="button"
                  className="btn btn-danger"
                  data-dismiss="modal"
                  onClick={() => this.deleteList(this.state.deleteIndex)}
                >
                  Delete
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }
}

const mapStateToProps = (state) => ({
  supplier: state.supplier,
});

export default connect(mapStateToProps, {
  showSupplierModel,
  showActiveTabsClear,
  supplierBasicDetails,
  supplierBasicDetailsDelete,
  supplierStoreDetailsDelete,
  supplierRawMeterialDelete,
})(withRouter(BasicDetails));
