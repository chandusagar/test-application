import React from "react";
import {
  withScriptjs,
  withGoogleMap,
  Marker,
  InfoWindow,
} from "react-google-maps";
import Map from "./Map";

// const MyMap = withScriptjs(
//   withGoogleMap(
//     `https://maps.googleapis.com/maps/api/js?key=AIzaSyDUsoLY33TlpJ4feuhEPJFF3Q9HGP1iC5g&v=3.exp&libraries=geometry,drawing,places`,
//     () => handelScriptLoad(query, autocomplete)
//   )
// );

export default function Gmap(props) {
  return (
    <div>
      {/* <MyMap
        isMarkerShown
        googleMapURL={`https://maps.googleapis.com/maps/api/js?key=AIzaSyDUsoLY33TlpJ4feuhEPJFF3Q9HGP1iC5g&v=3.exp&libraries=geometry,drawing,places`}
        loadingElement={<div style={{ height: `100%` }} />}
        containerElement={<div style={props.mapStyle} />}
        mapElement={<div style={{ height: `100%` }} />}
      /> */}
    </div>
  );
}

// 312px
// 00px
