import React from "react";
import {
  withScriptjs,
  withGoogleMap,
  GoogleMap,
  Marker,
  InfoWindow,
  Circle,
} from "react-google-maps";
import Geocode from "react-geocode";
import AutoComplete from "react-google-autocomplete";

Geocode.setApiKey("AIzaSyDUsoLY33TlpJ4feuhEPJFF3Q9HGP1iC5g");
Geocode.enableDebug();

class Map extends React.Component {
  state = {
    address: "",
    city: "",
    area: "",
    state: "",
    country: "",
    zipCode: "",
    mapPosition: {
      lat: 0,
      lng: 0,
    },
    markerPosition: {
      lat: 0,
      lng: 0,
    },
    isOpen: false,
  };

  async componentDidUpdate() {
    if (this.props.setLocation) {
      console.log(this.props.setLocation);
      this.setLatLng(this.props.setLocation);
    }
    console.log(this.state);
  }

  /**control re-render component validation */
  shouldComponentUpdate(nextProps, nextState) {
    return (
      this.props.setLocation !== nextProps.setLocation ||
      (this.props.location.lat !== nextProps.location.lat &&
        this.props.location.lng !== nextProps.location.lng) ||
      this.state.isOpen !== nextState.isOpen ||
      (nextProps.address.address && !nextProps.defaultDraggable)
    );
  }

  setLatLng = (setLocation) => {
    Geocode.fromAddress(setLocation).then((response) => {
      console.log(response);
      const address = response.results[0].formatted_address,
        addressArray = response.results[0].address_components,
        city = this.getCity(addressArray),
        area = this.getArea(addressArray),
        state = this.getState(addressArray),
        country = this.getCountry(addressArray),
        zipcode = this.getZipCode(addressArray),
        newLat = response.results[0].geometry.location.lat,
        newLng = response.results[0].geometry.location.lng;
      this.setState({
        address: address ? address : "",
        city: city ? city : "",
        area: area ? area : "",
        state: state ? state : "",
        country: country ? country : "",
        zipCode: zipcode ? zipcode : "",
        markerPosition: {
          lat: newLat,
          lng: newLng,
        },
        mapPosition: {
          lat: newLat,
          lng: newLng,
        },
      });

      this.props.mapDetails(this.state);
    });
  };

  getCity = (addressArray) => {
    let city = "";

    for (let index = 0; index < addressArray.length; index++) {
      if (
        addressArray[index].types[0] &&
        "administrative_area_level_2" === addressArray[index].types[0]
      ) {
        city = addressArray[index].long_name;
        return city;
      }
    }
  };

  getArea = (addressArray) => {
    let area = "";
    for (let index = 0; index < addressArray.length; index++) {
      if (addressArray[index].types[0]) {
        for (let j = 0; j < addressArray.length; j++) {
          if (
            "sublocality_level_2" === addressArray[index].types[j] ||
            "locality" === addressArray[index].types[j]
          ) {
            area = addressArray[index].long_name;
          }
          return area;
        }
      }
    }
  };

  getState = (addressArray) => {
    let state = "";
    for (let index = 0; index < addressArray.length; index++) {
      if (
        addressArray[index].types[0] &&
        "administrative_area_level_1" === addressArray[index].types[0]
      ) {
        state = addressArray[index].long_name;
        return state;
      }
    }
  };

  getCountry = (addressArray) => {
    let country = "";
    for (let index = 0; index < addressArray.length; index++) {
      if (
        addressArray[index].types[0] &&
        "country" === addressArray[index].types[0]
      ) {
        country = addressArray[index].long_name;
        return country;
      }
    }
  };

  getZipCode = (addressArray) => {
    let zipcode = "";
    for (let index = 0; index < addressArray.length; index++) {
      if (
        addressArray[index].types[0] &&
        "postal_code" === addressArray[index].types[0]
      ) {
        zipcode = addressArray[index].long_name;
        return zipcode;
      }
    }
  };

  /**Markar Dragbule function */
  onMarkarDragEnd = (event) => {
    let newLat = event.latLng.lat();
    let newLng = event.latLng.lng();
    Geocode.fromLatLng(newLat, newLng).then((response) => {
      const address = response.results[0].formatted_address,
        addressArray = response.results[0].address_components,
        city = this.getCity(addressArray),
        area = this.getArea(addressArray),
        state = this.getState(addressArray),
        country = this.getCountry(addressArray),
        zipcode = this.getZipCode(addressArray);
      this.setState({
        address: address ? address : "",
        city: city ? city : "",
        area: area ? area : "",
        state: state ? state : "",
        country: country ? country : "",
        zipCode: zipcode ? zipcode : "",
        markerPosition: {
          lat: newLat,
          lng: newLng,
        },
        mapPosition: {
          lat: newLat,
          lng: newLng,
        },
      });
      this.props.mapDetails(this.state);
    });
  };

  onToggleOpen = (isOpen) => {
    this.setState({ isOpen: !isOpen });
  };

  render() {
    const MyMap = withScriptjs(
      withGoogleMap((props) => (
        <GoogleMap
          google={props.google}
          mapTypeId={"roadmap"}
          defaultZoom={15}
          defaultCenter={{
            lat: this.props.location
              ? this.props.location.lat
              : this.state.mapPosition.lat,
            lng: this.props.location
              ? this.props.location.lng
              : this.state.mapPosition.lng,
          }}
        >
          <Marker
            defaultDraggable={this.props.defaultDraggable}
            onDragEnd={this.onMarkarDragEnd}
            position={{
              lat: this.props.location
                ? this.props.location.lat === 0
                  ? null
                  : this.props.location.lat
                : this.state.markerPosition.lat,
              lng: this.props.location
                ? this.props.location.lng === 0
                  ? null
                  : this.props.location.lng
                : this.state.markerPosition.lng,
            }}
            onClick={() => this.onToggleOpen(this.state.isOpen)}
          >
            {this.state.isOpen ? (
              <InfoWindow>
                <div>
                  {this.props.address
                    ? `${this.props.address.address}${this.props.address.city},${this.props.address.state} ${this.props.address.zipCode},${this.props.address.country}`
                    : this.state.address}
                </div>
              </InfoWindow>
            ) : (
              ""
            )}
          </Marker>
        </GoogleMap>
      ))
    );

    return (
      <div>
        <MyMap
          isMarkerShown
          googleMapURL={`https://maps.googleapis.com/maps/api/js?key=${process.env.REACT_APP_GOOGLE_MAP_KEY}&v=3.exp&libraries=geometry,drawing,places`}
          loadingElement={<div style={{ height: `100%` }} />}
          containerElement={<div style={this.props.mapStyle} />}
          mapElement={<div style={{ height: `100%` }} />}
        />
      </div>
    );
  }
}

export default React.memo(Map);
