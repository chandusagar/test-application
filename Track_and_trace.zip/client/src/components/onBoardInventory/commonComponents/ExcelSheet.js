import React from "react";
import XLSX from "xlsx";

import isEmpty from "../../../utils/isEmpty";

class ExcelSheet extends React.Component {
  state = {
    fileName: "",
    fileData: [],
    errors: {},
  };

  onSave = async (e) => {
    e.preventDefault();
    if (this.validateForm({ submitted: true })) {
      const formData = Object.assign({}, this.state);
      delete formData.errors;
      this.props.priview(null, formData, true);
    } else {
      this.setState((prevState) => {
        prevState.fileName = "";
        return prevState;
      });
    }
  };

  onChange = (e) => {
    const { name, files } = e.target;

    let selectFile = null;
    if (files && files[0]) {
      selectFile = files[0].name.split(".").pop();
    }

    if (
      name === "fileName" &&
      (selectFile === "csv" || selectFile === "xlsx" || selectFile === "xls")
    ) {
      const reader = new FileReader();
      const rABS = !!reader.readAsBinaryString;

      reader.onload = (e) => {
        const bstr = e.target.result;
        const wb = XLSX.read(bstr, {
          type: rABS ? "binary" : "array",
          bookVBA: true,
        });

        const wsname = wb.SheetNames[0];
        const ws = wb.Sheets[wsname];

        const data = XLSX.utils.sheet_to_json(ws);

        this.setState(
          {
            fileName: files[0].name,
            fileData: data,
            errors: {},
          },
          () => {
            this.validateForm({ key: data });
          }
        );
      };

      if (rABS) {
        reader.readAsBinaryString(files[0]);
      } else {
        reader.readAsArrayBuffer(files[0]);
      }
    }
  };

  validateForm = ({ key = null, submitted = false }) => {
    const formData = JSON.parse(JSON.stringify(this.state.fileData));
    const errors = {};
    let fileName = this.state.fileName;

    if (!isEmpty(formData)) {
      for (let i = 0; i < formData.length; i++) {
        if (isEmpty(formData[i].productId && submitted)) {
          errors.productId = `Product id ${i + 1} is required.`;
        }

        if (isEmpty(formData[i].productName && submitted)) {
          errors.productName = `Product Name ${i + 1} is required.`;
        }
        if (isEmpty(formData[i].productType && submitted)) {
          errors.productType = `Product type ${i + 1} is required.`;
        }
        if (isEmpty(formData[i].productCategory && submitted)) {
          errors.productCategory = `Product category ${i + 1} is required.`;
        }
        if (isEmpty(formData[i].productDescription && submitted)) {
          errors.productDescription = `Product description ${
            i + 1
          } is required.`;
        }
        if (isEmpty(formData[i].productImage && submitted)) {
          errors.productImage = `Product image ${i + 1} is required.`;
        }

        if (
          (formData[0] && !formData[0].productId) ||
          !formData[0].productName ||
          !formData[0].productType ||
          !formData[0].productCategory ||
          !formData[0].productImage
        ) {
          errors.productId = `Invalid excel sheet.`;
        }
      }
    } else {
      errors.productId = `You have uploaded with Empty data, Please add some data`;
      fileName = "";
    }

    this.setState({ errors, fileName });
    return isEmpty(errors);
  };

  /*reset file function* */
  reset = () => {
    this.setState((prevState) => {
      prevState.fileName = "";
      prevState.fileData = [];
      return prevState;
    });
  };

  render() {
    const { errors } = this.state;
    return (
      <>
        <div className="p-w-content mt-2">
          <div className="row">
            <div className="col-lg-6 col-xl-6 order-lg-1 order-xl-1">
              {this.state.fileName ? (
                <div className="upload-file-wrapper active">
                  <input
                    type="file"
                    name="fileName"
                    onChange={(e) => this.onChange(e)}
                  />
                  <div className="file-cont">
                    <div className="file-cont-text">
                      <p className="file-text-u-header">
                        <span className="upload-file"></span>
                        {this.state.fileName && this.state.fileName
                          ? this.state.fileName
                          : ""}
                        {/* Raw Material details.xlsx */}
                      </p>
                    </div>
                    <div className="file-cont-btn ">
                      <i className="fas fa-upload f-upload"></i>
                      <label className="f-upload">Upload file</label>
                    </div>
                  </div>
                </div>
              ) : (
                <div className="upload-file-wrapper">
                  <input
                    type="file"
                    name="fileName"
                    onChange={(e) => this.onChange(e)}
                    onClick={(e) => (e.target.value = null)}
                  />
                  <div className="file-cont">
                    <div className="file-cont-text">
                      <p className="file-text-header m-0">
                        Browse to upload file
                      </p>
                      <p className="file-text-sub-header">
                        Note: Column names of the excel sheet should match the
                        following Order to upload.
                      </p>

                      {errors && errors.productId ? (
                        <p className="file-text-sub-header">
                          {errors.productId}
                        </p>
                      ) : errors && errors.productName ? (
                        <p className="file-text-sub-header">
                          {errors.productName}
                        </p>
                      ) : errors && errors.productType ? (
                        <p className="file-text-sub-header">
                          {errors.productType}
                        </p>
                      ) : errors && errors.productCategory ? (
                        <p className="file-text-sub-header">
                          {errors.productCategory}
                        </p>
                      ) : errors && errors.productImage ? (
                        <p className="file-text-sub-header">
                          {errors.productImage}
                        </p>
                      ) : (
                        ""
                      )}
                      <p className="file-upload-format">
                        {/* S. No,Package Id, Supplier Details,Raw material name */}
                        product Id,product Name, product Type,product Category
                        ,product Description ,product Image
                      </p>
                    </div>
                    <div className="file-cont-btn">
                      <i className="fas fa-upload"></i>
                      <label>Upload file</label>
                    </div>
                  </div>
                </div>
              )}

              {this.state.fileName ? (
                <div class="bottom-btn mt-3">
                  <button
                    type="button"
                    className="btn btn-primary-ghost mr-2 px-3"
                    onClick={() => this.reset()}
                  >
                    {/* this.props.priview(3, this.state, false) */}
                    Clear
                  </button>
                  <button
                    type="button"
                    className="btn btn-primary px-3"
                    onClick={(e) => this.onSave(e)}
                  >
                    Perview
                  </button>
                </div>
              ) : (
                ""
              )}
            </div>
          </div>
        </div>
      </>
    );
  }
}
export default ExcelSheet;
