import React from "react";
import { connect } from "react-redux";
import { DataTable } from "primereact/datatable";
import { Column } from "primereact/column";

import { showSupplierModel } from "../../../actions/supplierAction";

class DefaultTable extends React.Component {
  confirm = () => {
    this.props.showSupplierModel(true);
    this.props.saveDetails(3, this.props.excelData, "system");
  };

  render() {
    const dynamicColumns = this.props.column.map((col, index) => {
      return (
        <Column
          key={col.field}
          field={col.field}
          header={col.header}
          body={
            this.props.modifyColums
              ? (rowData, col) => this.props.modifyColums(rowData, col)
              : ""
          }
          sortable={col.field == "Action" ? false : true}
        />
      );
    });

    return (
      <div className="p-w-content">
        <div className="row">
          <div className="col-12">
            <div className="up-cont-detail">
              <div className="up-text-details">
                <span className="up-label-text">Upload execl file : </span>
                <span className="up-load-text mr-2">
                  {this.props.excelData && this.props.excelData.fileName
                    ? this.props.excelData.fileName
                    : ""}
                </span>
                <span className="up-label-text">
                  Total records:
                  <span class="ml-1">
                    {this.props.excelData &&
                    this.props.excelData.fileData.length
                      ? this.props.excelData.fileData.length
                      : ""}
                  </span>
                </span>
              </div>
            </div>
          </div>
        </div>
        <div className="custom-table mt-1">
          <DataTable
            className="table table-bordered table-sm mb-1"
            value={this.props.respData}
            emptyMessage="No records found"
            paginator={true}
            rows={10}
            rowsPerPageOptions={[10, 25, 50, 100]}
          >
            {dynamicColumns}
          </DataTable>
        </div>
        <div className="d-flex">
          <div className="bottom-btn s-flex-end">
            <button
              type="button"
              className="btn btn-primary-ghost mr-2"
              onClick={() => this.props.priview(2, null, false)}
            >
              Cancel
            </button>
            <button
              type="submit"
              className="btn btn-primary"
              onClick={() => this.confirm()}
            >
              Confirm
            </button>
          </div>
        </div>
      </div>
    );
  }
}

// const mapStateToProps = (state) => ({
//   supplier: state.supplier,
// });

export default connect(null, { showSupplierModel })(DefaultTable);
