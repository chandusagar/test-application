import React from "react";
import Validator from "validator";
import TextFieldGroup from "../../common/TextFieldGroup";

import isEmpty from "../../../utils/isEmpty";

class IntegrateAPI extends React.Component {
  state = {
    apiObj: {
      type: "",
      url: "",
      header: [
        { key: false, name: "", value: "" },
        { key: false, name: "", value: "" },
        { key: false, name: "", value: "" },
      ],
      body: "",
    },
    contentType: "Headers",
  };

  clear = () => {
    this.setState((prevPorps) => {
      prevPorps.apiObj = {
        type: "",
        url: "",
        header: [
          { key: false, name: "", value: "" },
          { key: false, name: "", value: "" },
          { key: false, name: "", value: "" },
        ],
        body: "",
      };
      return prevPorps.apiObj;
    });
  };

  onSave = (e) => {
    e.preventDefault();

    if (this.validationForm({ submitted: true })) {
      let apiObj = JSON.parse(JSON.stringify(this.state.apiObj));
      let obj = {};
      apiObj.header.forEach((item) => {
        if (item.key) {
          delete item.key;
          obj[item.name] = item.value;
        }
      });
      apiObj.header = obj;
      apiObj.body = apiObj.body ? JSON.parse(apiObj.body) : "";
      console.log(apiObj);
    }
  };

  onChange = (e, index) => {
    const { name, value, checked } = e.target;
    let apiObj = JSON.parse(JSON.stringify(this.state.apiObj));
    console.log(name, value, checked);
    if (apiObj.header[index]) {
      if (name === "key") {
        apiObj.header[index][name] = checked;
      } else {
        apiObj.header[index][name] = value;
      }
    } else {
      apiObj[name] = value;
    }
    this.setState({ apiObj, errors: {} }, async () => {
      this.validationForm({ key: name });
    });
  };

  validationForm = ({ key = null, submitted = false }) => {
    const errors = {};
    if (isEmpty(this.state.apiObj.url) && (key === "url" || submitted)) {
      errors.url = "please enter url";
    } else if (
      this.state.apiObj.url &&
      !Validator.isURL(this.state.apiObj.url)
    ) {
      errors.url = "Invalid URL";
    }
    this.setState({ errors });
    return isEmpty(errors);
  };

  requestBody = () => {
    return (
      <>
        {this.state.apiObj.header.map((item, index) => (
          <tr key={index}>
            <td className="text-center">
              <TextFieldGroup
                type="checkbox"
                name="key"
                value={item.key}
                onChange={(e) => this.onChange(e, index)}
              />
            </td>
            <td>
              <TextFieldGroup
                type="text"
                name="name"
                value={item.name}
                onChange={(e) => this.onChange(e, index)}
              />
            </td>
            <td>
              <TextFieldGroup
                type="text"
                name="value"
                value={item.value}
                onChange={(e) => this.onChange(e, index)}
              />
            </td>
          </tr>
        ))}
      </>
    );
  };

  /**header tab function */
  headerTab = (tab) => {
    this.setState({ contentType: tab });
  };

  render() {
    console.log(this.state);
    return (
      <div className="p-w-content">
        <div className="j-content">
          <div className="row">
            <div className="col-lg-9 col-xl-9">
              <div className="input-group p-1">
                <div className="input-group-prepend pr-1">
                  <select
                    name="type"
                    className="form-control"
                    onChange={(e) => this.onChange(e)}
                    value={this.state.apiObj.type}
                  >
                    <option selected="">Get</option>
                    <option>Post</option>
                  </select>
                </div>

                <input
                  class="form-control"
                  type="text"
                  name="url"
                  onChange={(e) => this.onChange(e)}
                  value={this.state.apiObj.url}
                  placeholder="Enter request URL"
                />
              </div>
            </div>
            <div className="col-lg-3 col-xl-3 align-self-center p-0">
              <button
                type="submit"
                className="btn btn-primary mr-1"
                onClick={this.onSave}
              >
                Save
              </button>
              <button
                type="button"
                className="btn btn-primary-ghost"
                onClick={this.clear}
              >
                Clear
              </button>
            </div>
          </div>
          <hr className="m-0" />
          <div className="row">
            <div className="col-12">
              <div className="qr-custom-tabs px-2">
                <ul className="nav nav-pills" id="pills-tab2" role="tablist">
                  <li className="nav-item">
                    <label
                      className={
                        this.state.contentType === "Headers"
                          ? "nav-link active"
                          : "nav-link"
                      }
                      onClick={() => this.headerTab("Headers")}
                    >
                      Headers
                    </label>
                  </li>
                  <li className="nav-item">
                    <label
                      className={
                        this.state.contentType === "Body"
                          ? "nav-link active"
                          : "nav-link"
                      }
                      onClick={() => this.headerTab("Body")}
                    >
                      Body
                    </label>
                  </li>
                </ul>
              </div>
            </div>
          </div>
          <div className="tab-content">
            {this.state.contentType === "Headers" ? (
              <div
                className="tab-pane fade show active"
                id="pills-qr2"
                role="tabpanel"
                aria-labelledby="pills-qr-tab"
              >
                <div className="j-table">
                  <table className="table table-bordered table-sm mb-0">
                    <thead>
                      <tr>
                        <th></th>
                        <th>Key</th>
                        <th>Value</th>
                      </tr>
                    </thead>
                    <tbody>{this.requestBody()}</tbody>
                  </table>
                </div>
              </div>
            ) : (
              <div
                className="tab-pane fade show active"
                id="pills-active2"
                role="tabpanel"
                aria-labelledby="pills-active-tab"
              >
                <div className="row">
                  <div className="col-12">
                    <div className="b-text-content p-2 ">
                      <textarea
                        className="form-control"
                        id="Textarea1"
                        rows="3"
                        name="body"
                        onChange={(e) => this.onChange(e)}
                        value={this.state.apiObj.body}
                      ></textarea>
                    </div>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    );
  }
}

export default IntegrateAPI;
