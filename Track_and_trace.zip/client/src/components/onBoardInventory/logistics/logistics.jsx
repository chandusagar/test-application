import React from "react";
import { connect } from "react-redux";
import { withRouter } from "react-router-dom";
import SweetAlert from "react-bootstrap-sweetalert";

import BasicDetails from "./BasicDetails";
import SystemIntigrate from "./systemDetails/SystemIntigrate";
import PerviewConfirm from "./PerviewConfirm";

import {
  showSupplierModel,
  showSupplierModelActive,
  supplierPerviewConfirm,
} from "../../../actions/supplierAction";

import {
  logisticBasicDetails,
  logisticStoreDetails,
  logisticExistingSystem,
  logisticImportExcelSheet,
  logisticPerviewConfirm,
  setEditLogisticDetails,
} from "../../../actions/logisticsAction";

import Header from "../../layout/Header";

import services from "../../../services";

import isEmpty from "../../../utils/isEmpty";

class Logistics extends React.Component {
  state = {
    activeDetails: 1,
    ProcedPopUp: false,
    activeTab: [],
    successAlert: null,
    editVal: false,
    editperview: {},
    saveDetails: {},
    successpopup: {},
  };

  moveStep = (step) => {
    let index = this.state.saveDetails.id;
    let flag = this.state.saveDetails.flag;
    let list = this.state.saveDetails.data;

    if (flag === "basic") {
      this.props.logisticBasicDetails(list);
    } else if (flag === "system") {
      if (list.authenticationType) {
        this.props.logisticExistingSystem(list);
      } else if (list.fileName) {
        this.props.logisticImportExcelSheet(list);
      }
    }

    if (step === 4) {
      this.state.activeTab.push(4);
    }

    this.state.activeTab.push(index);

    this.setState({
      activeDetails: step + 1,
    });
  };

  /**set state to remove Active tab from props */
  closeStep = (step) => {
    if (step > 1) {
      this.setState({
        activeDetails: step - 1,
      });
    }
    this.props.showSupplierModelActive(this.state.activeTab);
  };

  async componentDidMount() {
    const pathname = this.props.location.pathname;
    if (pathname.indexOf("editlogistics") === 1) {
      await this.props.setEditLogisticDetails(
        this.props.match.params.logisticId
      );
    } else {
      await this.props.logisticPerviewConfirm();
    }
  }

  componentDidUpdate() {
    if (this.state.activeTab !== this.props.supplier.activeList) {
      this.setState({
        activeTab: this.props.supplier.activeList,
      });
    }
  }

  // sub component details functions
  saveDetails = (id, data, flag, index) => {
    const mainList = { id: id, data: data, flag: flag, index: index };

    setTimeout(() => {
      this.setState({ successAlert: null });
    }, 3000);

    this.setState({
      saveDetails: mainList,
      activeDetails: id,
      successAlert: id,
    });

    this.props.showSupplierModel(false);
  };

  editDetails = (id, index, flag) => {
    const editObj = { id: index, flag: flag };
    this.setState({
      activeDetails: id,
      editVal: true,
      editperview: editObj,
    });
  };

  /**priview and confirm edit to save function */
  editConfirm = () => {
    let flag = this.state.saveDetails.flag;
    let list = this.state.saveDetails.data;
    if (flag === "basic") {
      this.props.logisticBasicDetails(list);
    } else if (flag === "system") {
      if (list.authenticationType) {
        this.props.logisticExistingSystem(list);
      } else if (list.fileName) {
        this.props.logisticImportExcelSheet(list);
      }
    }
    this.setState({
      activeDetails: 3,
      editVal: false,
    });
  };

  deletePerview = () => {
    this.setState({
      activeDetails: 1,
    });
    this.props.logisticPerviewConfirm();
    this.showProcedPopUp(false);
  };

  /**proceed popup function */
  proceed = () => {
    let basicDetails = this.props.logistic.basicDetails;
    let existingSystem = this.props.logistic.existingSystem;
    let excelDetails = this.props.logistic.excelDetails;

    let formData = [];
    let excelData = [];

    basicDetails.forEach((x, i) => {
      formData.push({ docType: "Logistics" });
      formData[i].basicDetails = x;

      if (excelDetails.fileName) {
        excelData = excelDetails.fileData;
      }

      let rowMaterialObj = {
        automationIntegration: existingSystem,
        excelData:
          excelDetails && excelDetails.fileName
            ? {
                fileName: excelDetails.fileName,
                fileData: excelData,
              }
            : {},
      };

      formData[i].products = rowMaterialObj;
    });
    let reqObj = {
      peers: ["peer0.preProcessor.usecase.com"],
      fcn: "enrollEntity",
      args: formData,
    };

    if (this.props.location.pathname.indexOf("editlogistics") === 1) {
      let editFormData = formData[0].basicDetails;
      editFormData.storageUnits = formData[0].storageUnits;
      editFormData.docType = formData[0].docType;

      reqObj.fcn = "updateBasicDetailsEntity";
      reqObj.args = editFormData;
    }

    services.onBoardInventoryServices
      .storeLogisticDetails(reqObj)
      .then((success) => {
        if (this.props.location.pathname.indexOf("editlogistics") === 1) {
          this.setState({ successAlert: 4 }, async () => {
            setTimeout(() => {
              this.props.history.push("/myinventories");
            }, 3000);
          });
        } else {
          let successpopup = success;
          this.setState({ successpopup });
        }
      })
      .catch((error) => {
        let successpopup = error;
        this.setState({ successpopup });
      });
  };

  showProcedPopUp = (value) => {
    this.setState({ ProcedPopUp: value, successpopup: {} });
  };

  changeProced = () => {
    this.showProcedPopUp(false);

    let redirectPath = "/distributor";
    this.props.history.push(redirectPath);
    this.props.logisticPerviewConfirm();
  };

  render() {
    const succes = {
      paddingLeft: "35%",
      paddingRight: "36%",
    };
    return (
      <div>
        <div className="row">
          <div className="col-md-12">
            <Header
              name={
                this.props.location.pathname.indexOf("editlogistics") === 1
                  ? "Edit Logistics"
                  : "Logistics"
              }
            />

            {!isEmpty(this.state.successpopup) &&
            this.state.successpopup.success ? (
              <SweetAlert
                success
                title="Success"
                onConfirm={() => this.showProcedPopUp(true)}
                btnSize="md"
              >
                {this.state.successpopup.message}
              </SweetAlert>
            ) : !isEmpty(this.state.successpopup) &&
              !this.state.successpopup.success ? (
              <SweetAlert
                error
                title="Error"
                onConfirm={() => this.showProcedPopUp(false)}
                btnSize="md"
              >
                {this.state.successpopup.message}
              </SweetAlert>
            ) : (
              ""
            )}

            {this.state.successAlert === 1 ? (
              <div className="alert alert-success bg-success text-white alert-dismissible success_popup">
                <button type="button" className="close">
                  &times;
                </button>
                <div className="text-center" style={succes}>
                  Your Logistics Details {this.state.saveDetails.index + 1}
                  Are Successfully Saved.
                </div>
              </div>
            ) : this.state.successAlert === 2 ? (
              <div className="alert alert-success bg-success text-white alert-dismissible success_popup">
                <button type="button" className="close">
                  &times;
                </button>
                {this.state.saveDetails.data &&
                this.state.saveDetails.data.authenticationType ? (
                  <div className="text-center" style={succes}>
                    Your System Integrate Details Are Successfully Saved.
                  </div>
                ) : this.state.saveDetails.data &&
                  this.state.saveDetails.data.fileName ? (
                  <div className="text-center" style={succes}>
                    Your Import excel sheet Details Are Successfully Saved.
                  </div>
                ) : (
                  ""
                )}
              </div>
            ) : this.state.successAlert === 4 ? (
              <div className="alert alert-success bg-success text-white alert-dismissible success_popup">
                <button type="button" className="close">
                  &times;
                </button>
                <div className="text-center" style={succes}>
                  Your Logistic Inventory details are successfully updated.
                </div>
              </div>
            ) : (
              ""
            )}
          </div>
        </div>

        <div className="content-container">
          <div className="uc-step-module">
            <div className="uc-step-module-top">
              <div className="row">
                <div className="col-md-12">
                  <ul className="stepper">
                    <li
                      style={{ width: "33.5%" }}
                      className={
                        (this.state.activeDetails === 1 ? "active" : "") ||
                        (this.state.activeTab[0] == 1 ? "done active" : "")
                      }
                    >
                      Basic Details
                    </li>

                    <li
                      style={{ width: "33.5%" }}
                      className={
                        (this.state.activeDetails === 2 ? "active" : "") ||
                        (this.state.activeTab[1] == 2 ? "done active" : "")
                      }
                    >
                      System Integrate Details
                    </li>
                    <li
                      style={{ width: "33.5%" }}
                      className={
                        (this.state.activeDetails === 3 ? "active" : "") ||
                        (this.state.activeTab[2] == 3 ? "done active" : "")
                      }
                    >
                      Perview & Confirm
                    </li>
                  </ul>
                </div>
              </div>
              {this.state.activeDetails === 1 ? (
                <BasicDetails
                  editperview={this.state.editperview}
                  saveDetails={(id, data, flag, index) =>
                    this.saveDetails(id, data, flag, index)
                  }
                />
              ) : this.state.activeDetails === 2 ? (
                <SystemIntigrate
                  editperview={this.state.editperview}
                  saveDetails={(id, data, flag, index) =>
                    this.saveDetails(id, data, flag, index)
                  }
                />
              ) : this.state.activeDetails === 3 ? (
                <PerviewConfirm
                  logistic={this.props.logistic}
                  editDetails={(id, data, flag) =>
                    this.editDetails(id, data, flag)
                  }
                />
              ) : (
                ""
              )}
            </div>
            <div className="uc-step-module-bottom">
              <div className="row">
                <div className="col-md-12">
                  <div className="uc-bottom-btn">
                    {this.state.activeDetails === 3 ? (
                      <button
                        type="submit"
                        className="btn btn-primary-ghost px-3 mr-2"
                        data-toggle="modal"
                        data-target="#modal_01"
                      >
                        Delete
                      </button>
                    ) : (
                      <button
                        type="submit"
                        className="btn btn-primary-ghost px-3 mr-2"
                        onClick={() => this.closeStep(this.state.activeDetails)}
                      >
                        Back
                      </button>
                    )}

                    {this.state.editVal ? (
                      <button
                        type="submit"
                        className="btn btn-primary px-2"
                        onClick={() => this.editConfirm()}
                      >
                        Save & Confirm
                      </button>
                    ) : this.state.activeDetails === 3 ? (
                      <button
                        type="submit"
                        className="btn btn-primary px-2"
                        onClick={() => this.proceed()}
                      >
                        Proceed
                      </button>
                    ) : (
                      <button
                        type="submit"
                        className="btn btn-primary px-2"
                        disabled={this.props.supplier.showSupplierModel}
                        onClick={() => this.moveStep(this.state.activeDetails)}
                      >
                        Save & Proceed
                      </button>
                    )}
                  </div>

                  <div
                    className="modal fade"
                    id="modal_01"
                    tabindex="-1"
                    role="dialog"
                  >
                    <div className="modal-dialog" role="document">
                      <div className="modal-content">
                        <div className="modal-header">
                          <h5 className="modal-title">
                            Delete Logistics Details
                          </h5>
                          <button
                            type="button"
                            className="close btn btn-round"
                            data-dismiss="modal"
                            aria-label="Close"
                          >
                            <i className="material-icons">close</i>
                          </button>
                        </div>
                        <div className="modal-body">
                          <p className="modal-txt m-0">This can't be undone.</p>
                          <p className="m-0">- Logistics Basic Details.</p>
                          {/* <p className="m-0">- Logistics Storage Units.</p> */}
                          <p className="m-0">- Logistics System Integrate.</p>
                        </div>
                        <div className="modal-footer">
                          <button
                            type="button"
                            className="btn btn-primary-ghost"
                            data-dismiss="modal"
                          >
                            Cancel
                          </button>
                          <button
                            type="button"
                            className="btn btn-danger"
                            data-dismiss="modal"
                            onClick={() => this.deletePerview()}
                          >
                            Delete
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* proced popup */}
                  {this.state.ProcedPopUp ? (
                    <div
                      className="modal fade show"
                      id="modal_02"
                      tabindex="-1"
                      style={{ display: "block" }}
                      role="dialog"
                    >
                      <div
                        className="modal-dialog modal-dialog-centered"
                        role="document"
                      >
                        <div className="modal-content pro-modal">
                          <div className="modal-body">
                            <div className="check-icon"></div>
                            <h4>Thank you</h4>
                            <p className="px-5">
                              Logistics Basic Details , System Integrate Details
                              are successfully saved
                            </p>
                          </div>
                          <div className="modal-footer px-0">
                            <button
                              type="button"
                              className="btn p-btn"
                              data-dismiss="modal"
                              onClick={() => {
                                this.deletePerview();
                              }}
                            >
                              Do you like add another Logistics
                            </button>
                            <span class="or-txt">(or)</span>
                            <button
                              type="button"
                              className="btn n-btn"
                              data-dismiss="modal"
                              onClick={() => {
                                this.changeProced();
                              }}
                            >
                              Proceed to add Distributor
                            </button>
                          </div>
                        </div>
                      </div>
                    </div>
                  ) : (
                    ""
                  )}
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }
}
const mapStateToProps = (state) => ({
  supplier: state.supplier,
  logistic: state.logistic,
});

export default connect(mapStateToProps, {
  showSupplierModel,
  showSupplierModelActive,
  supplierPerviewConfirm,
  logisticBasicDetails,
  logisticStoreDetails,
  logisticExistingSystem,
  logisticImportExcelSheet,
  logisticPerviewConfirm,
  setEditLogisticDetails,
})(withRouter(Logistics));
