import React from "react";
import stateMapping from "../commonComponents/JsonData/states";

class PerviewConfirm extends React.Component {
  state = {
    existingSystem: {},
    fullScreen: null,
  };

  fullScreen = (flag) => {
    if (this.state.fullScreen !== flag) {
      this.setState({
        fullScreen: flag,
      });
    } else {
      this.setState({
        fullScreen: null,
      });
    }
  };

  render() {
    const existingSystem = this.props.logistic.existingSystem;
    const excelDetails = this.props.logistic.excelDetails;

    const stateName = (value) => {
      let name;
      stateMapping.stateNames.fields.forEach((item) => {
        if (item.value == value) {
          name = item.name;
        }
      });
      return name;
    };

    return (
      <div className="row">
        <div className="col-md-12">
          <div className="stepper-content">
            <div className="p-w-content">
              <div className="text-small"> Perview & Confirm </div>
            </div>
            <hr className="m-0" />
            <div className="p-w-content">
              <div className="row mt-2 perview">
                <div className="col-12 col-lg-6 col-xl-4 d-flex">
                  <div
                    className={
                      this.state.fullScreen === "basic"
                        ? "card flex-fill w-100 panel-fullscreen"
                        : "card flex-fill w-100"
                    }
                  >
                    <div className="card-header d-flex">
                      <h6 className="card-title mb-0">
                        Basic Details <span className="nub-txt">-</span>
                        <span className="nub-txt">
                          {this.props.logistic.basicDetails.length > 0
                            ? this.props.logistic.basicDetails.length
                            : ""}
                        </span>
                      </h6>
                      <div className="card-actions expand-icon-txt">
                        <button
                          className="btn p-0"
                          onClick={() => this.fullScreen("basic")}
                          id="panel-fullscreen"
                        >
                          <i className="la la-expand"></i>
                        </button>
                      </div>
                    </div>

                    <div
                      className={
                        this.state.fullScreen === "basic"
                          ? ""
                          : this.props.logistic.basicDetails.length > 1
                          ? "m-content"
                          : ""
                      }
                    >
                      {this.props.logistic.basicDetails.map((list, index) => (
                        <div className="card-body" key={index}>
                          <div className="title-header">
                            <h6 className="title-bg">
                              Logistics_{index + 1} Details
                            </h6>
                            <div className="card-actions edit-icon-txt">
                              <button className="btn p-0">
                                <i
                                  className="fas fa-edit"
                                  onClick={() =>
                                    this.props.editDetails(
                                      1,
                                      index + 1,
                                      "basic"
                                    )
                                  }
                                ></i>
                              </button>
                            </div>
                          </div>
                          <div className="text-small">Logistics Type</div>
                          <div className="sub-text">{list.type}</div>
                          <hr className="my-1" />
                          <div className="text-small">Logistics Name</div>
                          <div className="sub-text">{list.name}</div>
                          <hr className="my-1" />
                          <div className="text-small">Email id</div>
                          <div className="sub-text">{list.emailId}</div>
                          <hr className="my-1" />
                          <div className="text-small">
                            Phone / Mobile Number
                          </div>
                          <div className="sub-text">+91 {list.phoneNo}</div>
                          <hr className="my-1" />
                          <div className="text-small">Logistics Address</div>
                          <div className="sub-text">
                            <p>
                              {list.address},{list.city},{list.state}{" "}
                              {list.zipCode}, {list.country}.
                            </p>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
                {existingSystem.authenticationType ? (
                  <div className="col-12 col-lg-6 col-xl-4 d-flex">
                    <div
                      className={
                        this.state.fullScreen === "existing"
                          ? "card flex-fill w-100 panel-fullscreen"
                          : "card flex-fill w-100"
                      }
                    >
                      <div className="card-header d-flex">
                        <h6 className="card-title mb-0">
                          System Integrate <span className="nub-txt"></span>
                          <span className="nub-txt"></span>
                        </h6>
                        <div className="card-actions expand-icon-txt">
                          <button
                            className="btn p-0"
                            onClick={() => this.fullScreen("existing")}
                          >
                            <i className="la la-expand"></i>
                          </button>
                        </div>
                      </div>

                      <div>
                        <div className="card-body">
                          <div className="title-header">
                            <h6 className="title-bg">
                              System Integrate Details
                            </h6>
                            <div className="card-actions edit-icon-txt">
                              <button
                                className="btn p-0"
                                onClick={() =>
                                  this.props.editDetails(2, null, "existing")
                                }
                              >
                                <i className="fas fa-edit"></i>
                              </button>
                            </div>
                          </div>

                          <div className="text-small">System tools</div>
                          <div className="sub-text">
                            {existingSystem.systemTool}
                          </div>
                          <hr className="my-1" />
                          <div className="text-small">Authentication Type</div>
                          <div className="sub-text">
                            {existingSystem.authenticationType}
                          </div>
                          {existingSystem.authenticationType ===
                          "SecureFile" ? (
                            <div>
                              <hr className="my-1" />
                              <div className="text-small">Host Address</div>
                              <div className="sub-text">
                                {existingSystem.hostAddress}
                              </div>
                              <hr className="my-1" />
                              <div className="text-small">
                                Upload Secure File
                              </div>
                              <div className="sub-text">
                                {existingSystem.UploadSecureFile.name}
                              </div>
                              <hr className="my-1" />
                              <div className="text-small">Port</div>
                              <div className="sub-text">
                                {existingSystem.port}
                              </div>
                            </div>
                          ) : (
                            <div>
                              <hr className="my-1" />
                              <div className="text-small">Host Address</div>
                              <div className="sub-text">
                                {existingSystem.hostAddress}
                              </div>
                              <hr className="my-1" />
                              <div className="text-small">User Name</div>
                              <div className="sub-text">
                                {existingSystem.userName}
                              </div>
                              <hr className="my-1" />
                              <div className="text-small">Port</div>
                              <div className="sub-text">
                                {existingSystem.port}
                              </div>
                            </div>
                          )}
                        </div>
                      </div>
                    </div>
                  </div>
                ) : (
                  ""
                )}

                {excelDetails.fileName ? (
                  <div className="col-12 col-lg-6 col-xl-4 d-flex">
                    <div
                      className={
                        this.state.fullScreen === "excelSheet"
                          ? "card flex-fill w-100 panel-fullscreen"
                          : "card flex-fill w-100"
                      }
                    >
                      <div className="card-header d-flex">
                        <h6 className="card-title mb-0">
                          Import excel sheet
                          <span className="nub-txt">-</span>
                          <span className="nub-txt">
                            {excelDetails && excelDetails.fileData.length > 0
                              ? excelDetails.fileData.length
                              : ""}
                          </span>
                        </h6>

                        <div className="card-actions expand-icon-txt">
                          <button
                            className="btn p-0"
                            onClick={() => this.fullScreen("excelSheet")}
                          >
                            <i className="la la-expand"></i>
                          </button>
                        </div>
                      </div>

                      <div
                        className={
                          this.state.fullScreen === "excelSheet"
                            ? ""
                            : excelDetails.fileData.length > 1
                            ? "m-content"
                            : ""
                        }
                      >
                        {excelDetails.fileData.map((list, index) => (
                          <div className="card-body" key={index}>
                            <div className="title-header">
                              <h6 className="title-bg">
                                Import excel sheet {index + 1}
                              </h6>
                              <div className="card-actions edit-icon-txt">
                                <button
                                  className="btn p-0"
                                  onClick={() =>
                                    this.props.editDetails(
                                      2,
                                      excelDetails,
                                      "import"
                                    )
                                  }
                                >
                                  <i className="fas fa-edit"></i>
                                </button>
                              </div>
                            </div>

                            <div className="text-small">Product Id</div>
                            <div className="sub-text">{list.productId}</div>
                            <hr className="my-1" />
                            <div className="text-small">Product Name</div>
                            <div className="sub-text">{list.productName}</div>
                            <hr className="my-1" />
                            <div className="text-small">Product Type</div>
                            <div className="sub-text">{list.productType}</div>
                            <hr className="my-1" />
                            <div className="text-small">Product Category</div>
                            <div className="sub-text">
                              {list.productCategory}
                            </div>
                            <hr className="my-1" />
                            <div className="text-small">Product Image</div>
                            <div className="sub-text">{list.productImage}</div>
                            <hr className="my-1" />
                            <div className="text-small">
                              product Description
                            </div>
                            <div className="sub-text">
                              {list.productDescription}
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>
                ) : (
                  ""
                )}
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }
}

export default PerviewConfirm;
