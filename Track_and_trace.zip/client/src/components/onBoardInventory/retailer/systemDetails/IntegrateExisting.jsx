import React from "react";
import { connect } from "react-redux";

import { showSupplierModel } from "../../../../actions/supplierAction";

import TextFieldGroup from "../../../common/TextFieldGroup";
import SelectComponent from "../../../common/SelectComponent";

import isEmpty from "../../../../utils/isEmpty";

class IntegrateExisting extends React.Component {
  state = {
    authenticationType: "SecureFile",
  };

  componentDidMount() {
    this.setStoreData();
  }

  /** Set state Raw material data from props */
  setStoreData = () => {
    this.setState((prevState) => {
      prevState = this.props.retailer.existingSystem;
      return prevState;
    });

    this.props.showSupplierModel(true);
  };

  activeTab = (step) => {
    this.setState({
      authenticationType: step,
    });
  };

  onChange = (e) => {
    const { name, value, files } = e.target;
    let values = null;
    if (files) {
      let reader = new FileReader();
      reader.readAsDataURL(files[0]);
      reader.onload = () => {
        if (reader.readyState === 2) {
          var obj = {
            name: files[0].name,
            type: files[0].type,
            doc: reader.result,
          };
          this.setState({ [name]: obj });
        }
      };
    } else {
      values = value;
    }

    this.setState({ [name]: values, errors: {} }, async () => {
      this.validateForm({ key: name });
    });
  };

  /** integrate existing system save function  */
  SaveDetails = async (e, flag) => {
    e.preventDefault();
    if (this.validateForm({ submitted: true })) {
      const formData = Object.assign({}, this.state);
      delete formData.errors;
      if (formData.authenticationType === "SecureFile") {
        delete formData.userName;
        delete formData.Password;
      } else {
        delete formData.UploadSecureFile;
      }

      this.props.saveDetails(3, formData, flag);

      this.props.showSupplierModel(false);
    } else {
      this.props.showSupplierModel(true);
    }
  };

  /**clear details function */
  clearDetails = () => {
    this.setState((prevState) => {
      prevState.systemTool = "";
      prevState.hostAddress = "";
      prevState.port = "";
      prevState.userName = "";
      prevState.password = "";
      prevState.UploadSecureFile = "";
      return prevState;
    });
  };

  validateForm = ({ key = null, submitted = false }) => {
    const errors = {};

    if (isEmpty(this.state.systemTool) && (key === "systemTool" || submitted)) {
      errors.systemTool = "System tool is required";
    }

    if (this.state.authenticationType === "SecureFile") {
      if (
        isEmpty(this.state.hostAddress) &&
        (key === "hostAddress" || submitted)
      ) {
        errors.hostAddress = "HostAddress is required";
      }
      if (isEmpty(this.state.port) && (key === "port" || submitted)) {
        errors.port = "Port is required";
      }

      // if (
      //   isEmpty(this.state.UploadSecureFile) &&
      //   (key === "UploadSecureFile" || submitted)
      // ) {
      //   errors.UploadSecureFile = "Upload Secure File is required";
      // }
    } else {
      if (
        isEmpty(this.state.hostAddress) &&
        (key === "hostAddress" || submitted)
      ) {
        errors.hostAddress = "HostAddress is required";
      }
      if (isEmpty(this.state.userName) && (key === "userName" || submitted)) {
        errors.userName = "UserName is required";
      }
      if (isEmpty(this.state.password) && (key === "password" || submitted)) {
        errors.password = "Password is required";
      }
      if (isEmpty(this.state.port) && (key === "port" || submitted)) {
        errors.port = "port is required";
      }
    }

    this.setState({ errors });
    return isEmpty(errors);
  };

  /**system tool list function */
  systemToolfunction = () => {
    return [
      { name: "Oracle Netsuite", value: "oracleNetsuite" },
      { name: "Logility", value: "logility" },
      { name: "Odoo", value: "odoo" },
      { name: "Fishbowl inventory", value: "fishbowlInventory" },
      { name: "plex Systems", value: "PlexSystems" },
      { name: "GEP SMART", value: "GEPSMART" },
      { name: "Access Erp", value: "accessErp" },
    ];
  };

  /**secure file function */
  secureFilefunction = () => {
    const { errors } = this.state;
    return (
      <div>
        <div className="row">
          <div className="col-lg-6 col-xl-6 order-lg-1 order-xl-1">
            <div className="form-group">
              <TextFieldGroup
                label="Host Address"
                type="text"
                name="hostAddress"
                value={this.state.hostAddress}
                onChange={(e) => this.onChange(e)}
                placeholder="Enter Raw Material Name"
                error={errors && errors.hostAddress}
              />
            </div>
          </div>
        </div>
        <div className="row">
          <div className="col-lg-6 col-xl-6 order-lg-1 order-xl-1">
            <div className="form-group">
              <TextFieldGroup
                label="port"
                type="text"
                name="port"
                value={this.state.port}
                onChange={(e) => this.onChange(e)}
                placeholder="Enter port address"
                error={errors && errors.port}
              />
            </div>
          </div>
        </div>
        <div className="row">
          <div className="col-lg-6 col-xl-6 order-lg-1 order-xl-1">
            <div className="custom-file mt-2">
              <input
                type="file"
                className="custom-file-input"
                name="UploadSecureFile"
                onChange={(e) => this.onChange(e)}
              />
              <label className="custom-file-label" for="customFile">
                {this.state.UploadSecureFile && this.state.UploadSecureFile.name
                  ? this.state.UploadSecureFile.name
                  : "Browse Secure File"}
              </label>
            </div>
          </div>
        </div>
      </div>
    );
  };

  loginBasedfunction = () => {
    const { errors } = this.state;
    return (
      <div>
        <div className="row">
          <div className="col-lg-6 col-xl-6 order-lg-1 order-xl-1">
            <div className="form-group">
              <TextFieldGroup
                label="Host Address"
                type="text"
                name="hostAddress"
                value={this.state.hostAddress}
                onChange={(e) => this.onChange(e)}
                placeholder="Enter host address"
                error={errors && errors.hostAddress}
              />
            </div>
          </div>
        </div>
        <div className="row">
          <div className="col-lg-6 col-xl-6 order-lg-1 order-xl-1">
            <div className="form-row">
              <div className="form-group col-md-6">
                <TextFieldGroup
                  label="User Name"
                  type="text"
                  name="userName"
                  value={this.state.userName}
                  onChange={(e) => this.onChange(e)}
                  placeholder="Enter the userName"
                  error={errors && errors.userName}
                />
              </div>
              <div className="form-group col-md-6">
                <TextFieldGroup
                  label="Password"
                  type="password"
                  name="password"
                  value={this.state.password}
                  onChange={this.onChange}
                  placeholder="Enter the password"
                  error={errors && errors.password}
                />
              </div>
            </div>
          </div>
        </div>
        <div className="row">
          <div className="col-lg-6 col-xl-6 order-lg-1 order-xl-1">
            <div className="form-group">
              <TextFieldGroup
                label="port"
                type="text"
                name="port"
                value={this.state.port}
                onChange={(e) => this.onChange(e)}
                placeholder="Enter port address"
                error={errors && errors.port}
              />
            </div>
          </div>
        </div>
      </div>
    );
  };

  render() {
    const { errors } = this.state;
    return (
      <div>
        <div className="p-w-content">
          <div className="row">
            <div className="col-lg-6 col-xl-6 order-lg-1 order-xl-1">
              <div className="form-group">
                <SelectComponent
                  label="System tools"
                  onChange={(e) => this.onChange(e)}
                  options={this.systemToolfunction()}
                  name="systemTool"
                  value={this.state.systemTool}
                  error={errors && errors.systemTool}
                />
              </div>
            </div>
          </div>
        </div>
        <hr className="m-0" />
        <div className="p-w-content mt-2">
          <div className="row">
            <div className="col-lg-6 col-xl-6 order-lg-1 order-xl-1">
              <div
                className="btn-toolbar d-none d-md-block mb-1 btn-toggle"
                role="toolbar"
                aria-label="Toolbar with buttons"
              >
                <div
                  className="btn-group btn-group-toggle"
                  data-toggle="buttons"
                >
                  <label
                    className={
                      this.state.authenticationType === "SecureFile"
                        ? "btn btn-outline-secondary active"
                        : "btn btn-outline-secondary"
                    }
                    onClick={() => this.activeTab("SecureFile")}
                  >
                    Secure File
                  </label>
                  <label
                    className={
                      this.state.authenticationType === "LoginBased"
                        ? "btn btn-outline-secondary active"
                        : "btn btn-outline-secondary"
                    }
                    onClick={() => this.activeTab("LoginBased")}
                  >
                    Login Based
                  </label>
                </div>
              </div>
            </div>
          </div>

          {this.state.authenticationType === "SecureFile"
            ? this.secureFilefunction()
            : this.state.authenticationType === "LoginBased"
            ? this.loginBasedfunction()
            : ""}
        </div>
        <div className="p-w-content mt-2">
          <div className="row">
            <div className="col-lg-6 col-xl-6 order-lg-1 order-xl-1">
              <div className="bottom-btn">
                <button
                  type="button"
                  className="btn btn-primary-ghost mr-2"
                  onClick={this.clearDetails}
                >
                  Clear
                </button>
                <button
                  type="submit"
                  className="btn btn-primary"
                  onClick={(e) => this.SaveDetails(e, "system")}
                >
                  Save
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }
}
const mapStateToProps = (state) => ({
  retailer: state.retailer,
});
export default connect(mapStateToProps, {
  showSupplierModel,
})(IntegrateExisting);
