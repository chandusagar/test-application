import React from "react";
import Map from "../supplier/GoogleMap/Map";
import SearchLocation from "../supplier/GoogleMap/SearchLocation";

import { connect } from "react-redux";
import { withRouter } from "react-router-dom";
import Validator from "validator";

/**import common files */
import SelectComponent from "../../common/SelectComponent";
import TextFieldGroup from "../../common/TextFieldGroup";

/**import loading Supplier */
import { showSupplierModel } from "../../../actions/supplierAction";
import { distributorStoreDetailsdelete } from "../../../actions/distributorAction";

/**import config validations */
import isEmpty from "../../../utils/isEmpty";

class StorageDetails extends React.Component {
  state = {
    listId: null,
    id: null,
    deleteIndex: null,
    addStoreUnit: false,
    storeDetails: [],
    storeList: [],
    setLocation: "",
  };
  componentDidMount() {
    this.setStoreData();
  }

  /** Set state basic Details data from props */
  setStoreData = () => {
    let storeDetails = this.props.distributor.storeDetails;
    storeDetails.forEach((item, i) => {
      item.latitude = Number(item.latitude);
      item.longitude = Number(item.longitude);
    });

    let storeList =
      storeDetails.length > 0
        ? storeDetails
        : [
            {
              name: "",
              distributorName: "",
              address: "",
              city: "",
              state: "",
              country: "",
              zipCode: "",
              latitude: "",
              longitude: "",
            },
          ];

    let Id = storeDetails.length > 0 ? storeDetails.length : 1;

    this.props.showSupplierModel(true);
    const perview = this.props.editperview;
    if (perview.id) {
      this.showSotreDetails(perview.id - 1);
    } else {
      this.showSotreDetails(Id - 1);
    }

    this.setState({
      storeList: storeList,
      storeDetails: storeList,
      id: Id,
    });
  };

  addStoreDetails = (id, from) => {
    let clear = from;
    let obj = {
      name: "",
      distributorName: "",
      address: "",
      city: "",
      state: "",
      country: "",
      zipCode: "",
      latitude: "",
      longitude: "",
    };

    let storeList = Array.from(this.state.storeList);
    if (!isEmpty(clear)) {
      storeList[id] = obj;
    } else {
      storeList.push(obj);
    }

    this.setState({ storeList, id: id + 1, listId: id, addStoreUnit: false });
    this.props.showSupplierModel(true);
  };

  /**reset input values reset function */
  clearList = (index) => {
    this.addStoreDetails(index, "clear");
  };

  showSotreDetails = (id) => {
    let listid = null;
    if (id !== this.state.listId) {
      listid = id;
    } else {
      listid = null;
    }
    this.setState({
      listId: listid,
    });
  };

  deleteStoreDetails = (id) => {
    this.setState({
      deleteIndex: id,
    });
  };

  /**index based on store details delete from props */
  deleteList = (id) => {
    let storeList = Array.from(this.state.storeList);
    storeList.splice(id, 1);

    this.setState({
      storeList,
      storeDetails: storeList,
      id: id,
      listId: id - 1,
    });

    /** store to storage Details delete function */
    if (this.props.distributor.storeDetails[id]) {
      this.props.distributorStoreDetailsdelete(id);
    }
  };

  onChange = (e, index) => {
    const { name, value } = e.target;
    let storeList = JSON.parse(JSON.stringify(this.state.storeList));
    storeList[index][name] = value;
    this.setState({ storeList: storeList, errors: {} }, async () => {
      this.validateForm({ key: name, i: index });
    });
  };

  saveDetails = (e, list, index) => {
    e.preventDefault();

    if (
      this.validateForm({ submitted: true }) &&
      list.latitude &&
      list.longitude
    ) {
      let latitude = list.latitude.toString();
      let longitude = list.longitude.toString();
      let listobj = Object.assign({}, list);
      delete listobj.errors;
      listobj.latitude = latitude;
      listobj.longitude = longitude;
      let storeDetails = Array.from(this.state.storeDetails);
      storeDetails[index] = listobj;
      this.setState({
        storeDetails,
        addStoreUnit: true,
        listId: null,
      });

      this.props.saveDetails(2, storeDetails, "store", index);
      this.props.showSupplierModel(false);
    } else {
      this.props.showSupplierModel(true);
      this.setState({
        addStoreUnit: false,
      });
    }
  };

  /** validations for add data basic Details form */
  validateForm = ({ key = null, index = -1, submitted = false }) => {
    if (index >= 0) {
      let { validationStatus } = this.validationOnLoop({
        key,
        index,
        submitted,
      });

      return validationStatus;
    } else {
      let status = false;

      const formData = JSON.parse(JSON.stringify(this.state.storeList));

      for (let i = 0; i < formData.length; i++) {
        let { validationStatus } = this.validationOnLoop({
          index: i,
          submitted,
        });

        if (!validationStatus) return validationStatus;
        else status = validationStatus;
      }

      return status;
    }
  };

  /** Validate form data based on index */
  validationOnLoop = ({ key = null, index = null, submitted = false }) => {
    let validateData = JSON.parse(JSON.stringify(this.state.storeList));

    validateData[index].errors = {};

    if (isEmpty(validateData[index].name) && (key === "name" || submitted)) {
      validateData[index].errors.name = " Name is required";
    } else if (
      validateData[index].name &&
      !Validator.isLength(validateData[index].name, { min: 3 })
    ) {
      validateData[index].errors.name = "Name should have minimum 3 characters";
    }

    if (
      isEmpty(validateData[index].distributorName) &&
      (key === "distributorName" || submitted)
    ) {
      validateData[index].errors.distributorName =
        "Distributor Name is required";
    }

    if (
      isEmpty(validateData[index].address) &&
      (key === "address" || submitted)
    ) {
      validateData[index].errors.address = "Storage Address is required";
    } else if (
      validateData[index].address &&
      !Validator.isLength(validateData[index].address, { min: 5 })
    ) {
      validateData[index].errors.address =
        "Address should have minimum 5 characters";
    }

    if (isEmpty(validateData[index].city) && (key === "city" || submitted)) {
      validateData[index].errors.city = "City Name is required";
    } else if (
      validateData[index].city &&
      !Validator.isLength(validateData[index].city, { min: 3 })
    ) {
      validateData[index].errors.city =
        "City name should have minimum 3 characters";
    }

    if (isEmpty(validateData[index].state) && (key === "state" || submitted)) {
      validateData[index].errors.state = "State is required";
    }

    if (
      isEmpty(validateData[index].country) &&
      (key === "country" || submitted)
    ) {
      validateData[index].errors.country = "Country is required";
    }

    if (
      isEmpty(validateData[index].zipCode) &&
      (key === "zipCode" || submitted)
    ) {
      validateData[index].errors.zipCode = "Zip Code is required";
    } else if (
      validateData[index].zipCode &&
      !Validator.isLength(validateData[index].zipCode, { min: 6 })
    ) {
      validateData[index].errors.zipCode =
        "Zip code should have minimum 6 numbers";
    }

    if (
      validateData[index].zipCode &&
      !Validator.isDecimal(validateData[index].zipCode)
    ) {
      validateData[index].errors.zipCode = " Invalid Zip Code";
    }

    this.setState({ storeList: validateData });

    return { validationStatus: isEmpty(validateData[index].errors) };
  };

  /** supplier Name List */
  supplierNames = () => {
    let basicDetails = this.props.distributor.basicDetails;
    let arr = [];

    basicDetails.forEach((item) => {
      let obj = {
        name: `${item.name} (${item.emailId})`,
        value: item.emailId,
      };
      arr.push(obj);
    });

    return arr;
  };

  /** map to get Details */
  mapDetails = (mapData, i) => {
    if (mapData.query) {
      this.setState({ setLocation: mapData.query });
    } else {
      let addressArr = mapData.address.split(",");
      delete addressArr[addressArr.length - 2];
      delete addressArr[addressArr.length - 1];
      let address = "";
      addressArr.forEach((item) => {
        address += `${item},`;
      });

      this.setState((prevProps) => {
        prevProps.setLocation = "";
        prevProps.storeList[i].address = address;
        prevProps.storeList[i].city = mapData.city;
        prevProps.storeList[i].state = mapData.state;
        prevProps.storeList[i].country = mapData.country;
        prevProps.storeList[i].zipCode = mapData.zipCode;
        prevProps.storeList[i].latitude = mapData.markerPosition.lat;
        prevProps.storeList[i].longitude = mapData.markerPosition.lng;

        return prevProps.storeList;
      });
    }
  };

  render() {
    return (
      <div>
        {this.state.storeList.map((list, index) => (
          <div className="accordion mt-1" id="accordion-1" key={index}>
            <div className="card m-0">
              <div className="card-header" id="headingOne">
                <h2 className="mb-0">
                  <button
                    className="btn accordionBtn ml-2"
                    type="button"
                    onClick={() => this.showSotreDetails(index)}
                  >
                    Storage Units Details_{index + 1}
                  </button>

                  {this.state.storeDetails[index] &&
                  this.state.storeDetails[index].name ? (
                    <label>
                      Name of the Storage Unit :
                      <span class="sub-txt-header">
                        {this.state.storeDetails[index].name}
                      </span>
                    </label>
                  ) : (
                    ""
                  )}
                </h2>
              </div>
              <div
                className={index === this.state.listId ? "show" : "collapse"}
              >
                <div className="row">
                  <div className="col-md-12">
                    <div className="stepper-content">
                      <div className="p-w-content ">
                        {this.state.storeList.length > 1 ? (
                          <span
                            class="del-icon"
                            data-toggle="modal"
                            data-target="#modal_01"
                            onClick={() => this.deleteStoreDetails(index)}
                          >
                            <i class="fa fa-trash"></i>
                          </span>
                        ) : (
                          ""
                        )}

                        <div className="row">
                          <div className="col-lg-6 col-xl-6 order-lg-1 order-xl-1">
                            <div className="form-group">
                              <TextFieldGroup
                                label="Name of the Storage Unit"
                                type="text"
                                name="name"
                                value={this.state.storeList[index].name}
                                onChange={(e) => this.onChange(e, index)}
                                placeholder="enter the storage unit"
                                error={list.errors && list.errors.name}
                              />
                            </div>
                            <div className="form-group">
                              <SelectComponent
                                label=" Select your Distributor"
                                onChange={(e) => this.onChange(e, index)}
                                options={this.supplierNames()}
                                name="distributorName"
                                value={list.distributorName}
                                error={
                                  list.errors && list.errors.distributorName
                                }
                                disabled={
                                  list.distributorName &&
                                  this.props.location.pathname.indexOf(
                                    "editdistributor"
                                  ) === 1
                                }
                              />
                            </div>

                            {!this.state.storeList[index].latitude &&
                            !this.state.storeList[index].longitude ? (
                              <div className="form-row">
                                <SearchLocation
                                  mapDetails={(data) =>
                                    this.mapDetails(data, index)
                                  }
                                />
                              </div>
                            ) : (
                              ""
                            )}

                            <div className="form-group">
                              <label>
                                Distributor Storage Address
                                <span className="astric">*</span>
                              </label>
                              <textarea
                                className="form-control"
                                placeholder="enter the storage address"
                                name="address"
                                value={this.state.storeList[index].address}
                                onChange={(e) => this.onChange(e, index)}
                                disabled={true}
                                rows="3"
                              ></textarea>
                              {list.errors ? (
                                <p className="text-danger text-small">
                                  {list.errors.address}
                                </p>
                              ) : (
                                ""
                              )}
                            </div>

                            <div className="form-row">
                              <div className="form-group col-md-6">
                                <TextFieldGroup
                                  label="Distric"
                                  type="text"
                                  name="city"
                                  value={this.state.storeList[index].city}
                                  onChange={(e) => this.onChange(e, index)}
                                  placeholder="Districs name"
                                  disabled={true}
                                  error={list.errors && list.errors.city}
                                />
                              </div>
                              <div className="form-group col-md-6">
                                <TextFieldGroup
                                  label="State"
                                  type="text"
                                  name="state"
                                  value={this.state.storeList[index].state}
                                  onChange={(e) => this.onChange(e, index)}
                                  placeholder="State name"
                                  disabled={true}
                                  error={list.errors && list.errors.state}
                                />
                              </div>
                            </div>
                            <div className="form-row">
                              <div className="form-group col-md-6">
                                <TextFieldGroup
                                  label="Country"
                                  type="text"
                                  name="country"
                                  value={this.state.storeList[index].country}
                                  onChange={(e) => this.onChange(e, index)}
                                  placeholder="Country name"
                                  disabled={true}
                                  error={list.errors && list.errors.country}
                                />
                              </div>
                              <div className="form-group col-md-6">
                                <TextFieldGroup
                                  label="Zip Code"
                                  type="text"
                                  name="zipCode"
                                  maxlength="7"
                                  value={this.state.storeList[index].zipCode}
                                  onChange={(e) => this.onChange(e, index)}
                                  disabled={true}
                                  error={list.errors && list.errors.zipCode}
                                />
                              </div>
                            </div>
                          </div>
                          <div className="col-lg-6 col-xl-6 order-lg-1 order-xl-1">
                            <div className="map-container">
                              <Map
                                mapStyle={{ height: "312px" }}
                                defaultDraggable={true}
                                mapDetails={(data) =>
                                  this.mapDetails(data, index)
                                }
                                setLocation={this.state.setLocation}
                                address={this.state.storeList[index]}
                                location={{
                                  lat: this.state.storeList[index].latitude
                                    ? this.state.storeList[index].latitude
                                    : 0,
                                  lng: this.state.storeList[index].longitude
                                    ? this.state.storeList[index].longitude
                                    : 0,
                                }}
                              />
                            </div>
                          </div>
                        </div>
                        <div className="bottom-btn">
                          <button
                            type="button"
                            className="btn btn-primary-ghost mr-2 px-3"
                            onClick={() => this.clearList(index)}
                          >
                            Clear
                          </button>
                          <button
                            type="submit"
                            className="btn btn-primary px-3"
                            onClick={(e) => this.saveDetails(e, list, index)}
                          >
                            Save
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        ))}
        <div className="add-btn-content">
          <div className="p-w-content">
            <button
              className="btn btn-add-ghost"
              disabled={!this.state.addStoreUnit}
              onClick={() => this.addStoreDetails(this.state.id)}
            >
              <i className="la la-plus-square mr-1"></i> Add another Storage
              unit
            </button>
          </div>
        </div>

        <div className="modal fade" id="modal_01" tabindex="-1" role="dialog">
          <div className="modal-dialog" role="document">
            <div className="modal-content">
              <div className="modal-header">
                <h5 className="modal-title">
                  Delete Storage Units Details of Distributor_
                  {this.state.deleteIndex + 1}
                </h5>
                <button
                  type="button"
                  className="close btn btn-round"
                  data-dismiss="modal"
                  aria-label="Close"
                >
                  <i className="material-icons">close</i>
                </button>
              </div>
              <div className="modal-body">
                <p className="modal-txt m-0">This can't be undone.</p>
                <p>
                  - Distributor_{this.state.deleteIndex + 1} Storage Units
                  Details.
                </p>
              </div>
              <div className="modal-footer">
                <button
                  type="button"
                  className="btn btn-primary-ghost"
                  data-dismiss="modal"
                >
                  Cancel
                </button>
                <button
                  type="button"
                  className="btn btn-danger"
                  data-dismiss="modal"
                  onClick={() => this.deleteList(this.state.deleteIndex)}
                >
                  Delete
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }
}

const mapStateToProps = (state) => ({
  distributor: state.distributor,
});

export default connect(mapStateToProps, {
  showSupplierModel,
  distributorStoreDetailsdelete,
})(withRouter(StorageDetails));
