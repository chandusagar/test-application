import React from "react";

class ExcelSheet extends React.Component {
  render() {
    return (
      <div className="p-w-content mt-2">
        <div className="row">
          <div className="col-lg-6 col-xl-6 order-lg-1 order-xl-1">
            <div
              className="btn-toolbar d-none d-md-block mb-1 btn-toggle"
              role="toolbar"
              aria-label="Toolbar with buttons"
            >
              <div className="btn-group btn-group-toggle" data-toggle="buttons">
                {/* <label
                  className={
                    this.state.activeStep == 1
                      ? "btn btn-outline-secondary active"
                      : "btn btn-outline-secondary"
                  }
                  onClick={() => this.moveStep(1)}
                >
                  Secure File
                </label> */}
                {/* <label
                  className={
                    this.state.activeStep == 2
                      ? "btn btn-outline-secondary active"
                      : "btn btn-outline-secondary"
                  }
                  onClick={() => this.moveStep(2)}
                >
                  Login Based
                </label> */}
              </div>
            </div>
          </div>
        </div>
        {/* {this.state.activeStep == 1 ? (
            <SecureFile />
          ) : this.state.activeStep == 2 ? (
            <LoginBased />
          ) : (
            <SecureFile />
          )} */}
      </div>
    );
  }
}
export default ExcelSheet;
