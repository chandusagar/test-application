import React from "react";
import IntegrateExisting from "./IntegrateExisting";
import ExcelSheet from "../../commonComponents/ExcelSheet";
import DataTable from "../../commonComponents/DataTable";
import IntegrateAPI from "../../commonComponents/IntegrateAPI";

class SystemIntigrate extends React.Component {
  state = {
    activeStep: 1,
    excelSheet: false,
    excelData: null,
    column: [
      { field: "productId", header: "Product Id" },
      { field: "productName", header: "Product Name" },
      { field: "productType", header: "Product Type" },
      { field: "productCategory", header: "Product Category" },
      { field: "productDescription", header: "Product Description" },
      { field: "productImage", header: "Product Image" },
    ],
    details: [],
    ProductsTab: "Products",
  };

  componentDidMount() {
    this.setActiveTab();
  }

  setActiveTab = () => {
    const perview = this.props.editperview;
    let activeId = perview.flag === "import" ? 2 : 1;
    let data = {};
    if (activeId === 2) {
      data = perview.id;
      this.setState({
        excelSheet: true,
        excelData: data,
        details: data && data.fileData ? data.fileData : [],
      });
      this.moveStep(0);
    } else {
      this.moveStep(activeId);
    }
  };

  moveStep = (step) => {
    this.setState({
      activeStep: step,
    });
  };

  /**import excel sheet priview details */
  priview = (id, file, flag) => {
    console.log(id, file, flag);
    this.setState({
      excelSheet: flag,
      activeStep: id,
      excelData: file,
      details: file && file.fileData ? file.fileData : [],
    });
  };

  modifyColums = (rowData, col) => {
    switch (col.field) {
      case "productImage":
        return (
          <div className="pack-image">
            <img src={rowData.productImage} alt="package-image" />
          </div>
        );
      default:
        return rowData[col.field];
    }
  };

  /**Products Esisting Tab function  */
  existingTab = (mainTab) => {
    this.setState({ ProductsTab: mainTab });
  };

  render() {
    return (
      <>
        <div className="qr-custom-tabs">
          <div className="stepper-content">
            <div className="p-w-content" style={{ padding: "0.7rem 3rem" }}>
              <ul className="nav nav-pills" id="pills-tab" role="tablist">
                <li className="nav-item">
                  <label
                    className={
                      this.state.ProductsTab === "Products"
                        ? "nav-link active"
                        : "nav-link"
                    }
                    onClick={() => this.existingTab("Products")}
                  >
                    Existing Products
                  </label>
                </li>
                <li class="nav-item">
                  <label
                    className={
                      this.state.ProductsTab === "Existing"
                        ? "nav-link active"
                        : "nav-link"
                    }
                    onClick={() => this.existingTab("Existing")}
                  >
                    Existing QR codes
                  </label>
                </li>
              </ul>
            </div>
          </div>
        </div>
        <div className="row">
          {this.state.ProductsTab === "Products" ? (
            <div className="col-md-12">
              <div className="stepper-content">
                {!this.state.excelSheet ? (
                  <div className="p-w-content mt-2">
                    <div className="row">
                      <div className="col-lg-6 col-xl-6 order-lg-1 order-xl-1">
                        <div
                          className="btn-toolbar d-none d-md-block mb-1 btn-toggle"
                          role="toolbar"
                          aria-label="Toolbar with buttons"
                        >
                          <div
                            className="btn-group btn-group-toggle"
                            data-toggle="buttons"
                          >
                            <label
                              className={
                                this.state.activeStep === 1
                                  ? "btn btn-outline-secondary active"
                                  : "btn btn-outline-secondary"
                              }
                              onClick={() => this.moveStep(1)}
                            >
                              Integrate Existing System
                            </label>

                            <label
                              className={
                                this.state.activeStep === 2
                                  ? "btn btn-outline-secondary active"
                                  : "btn btn-outline-secondary"
                              }
                              onClick={() => this.moveStep(2)}
                            >
                              Import excel sheet
                            </label>
                            <label
                              className={
                                this.state.activeStep === 3
                                  ? "btn btn-outline-secondary active"
                                  : "btn btn-outline-secondary"
                              }
                              onClick={() => this.moveStep(3)}
                            >
                              Integrate API
                            </label>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                ) : (
                  ""
                )}

                {this.state.activeStep === 1 ? (
                  <IntegrateExisting
                    saveDetails={(id, obj, flag) =>
                      this.props.saveDetails(id, obj, flag)
                    }
                  />
                ) : this.state.activeStep === 2 ? (
                  <ExcelSheet
                    priview={(id, file, flag) => this.priview(id, file, flag)}
                  />
                ) : this.state.activeStep === 3 ? (
                  <IntegrateAPI />
                ) : (
                  ""
                )}

                {this.state.excelSheet ? (
                  <>
                    <div className="p-w-content">
                      <div className="text-small"> Import excel sheet </div>
                    </div>
                    <hr className="m-0" />
                    <DataTable
                      respData={this.state.details}
                      column={this.state.column}
                      modifyColums={(rowData, col) =>
                        this.modifyColums(rowData, col)
                      }
                      excelData={this.state.excelData}
                      priview={(id, file, flag) => this.priview(id, file, flag)}
                      saveDetails={(id, obj, flag) =>
                        this.props.saveDetails(id, obj, flag)
                      }
                    />
                  </>
                ) : (
                  ""
                )}
              </div>
            </div>
          ) : (
            <div className="col-md-12">
              <div className="stepper-content">
                {this.state.ProductsTab === "Existing" ? <IntegrateAPI /> : ""}
              </div>
            </div>
          )}
        </div>
      </>
    );
  }
}

export default SystemIntigrate;
