import React, { Component } from "react";
import { withRouter, Link } from "react-router-dom";
import SweetAlert from "react-bootstrap-sweetalert";

import services from "../../services";

import isEmpty from "../../utils/isEmpty";

class DashBoardHeader extends Component {
  state = {
    user: {},
    successpopup: {},
  };
  componentDidMount() {
    this.setData();
  }

  setData = () => {
    let respData = services.userManagementServices.setCurrentUser();
    let user = JSON.parse(respData);
    this.setState({ user });
  };

  signout = () => {
    services.userManagementServices
      .signoutUser()
      .then((success) => {
        let successpopup = success;
        this.setState({ successpopup });
      })
      .catch((error) => {
        let successpopup = error;
        this.setState({ successpopup });
      });
  };

  hideAlert = () => {
    let redirectPath = "/";
    this.props.history.push(redirectPath);
    this.setState({ successpopup: {} });
  };

  /**show sweet alert popup */
  getAlert = () => {
    return (
      <SweetAlert
        success
        title="Success"
        onConfirm={() => this.hideAlert()}
        btnSize="md"
      >
        {this.state.successpopup.message}
      </SweetAlert>
    );
  };

  render() {
    const userName = (string) => {
      return string.charAt(0).toUpperCase() + string.slice(0, 0);
    };

    const userLabel = (firstName, lastName) => {
      let user = `${firstName.charAt(0).toUpperCase() + firstName.slice(1)} ${
        lastName.charAt(0).toUpperCase() + lastName.slice(1)
      }`;
      return user;
    };

    return (
      <div className="container-fluid">
        {/* sweet alert popup */}
        {!isEmpty(this.state.successpopup) && this.state.successpopup.message
          ? this.getAlert()
          : ""}
        {/* End sweet alert */}
        <header>
          <div className="header-lft">
            <div className="dropdown">
              <button
                className="btn btn-default menu dropdown-toggle"
                type="button"
                data-toggle="dropdown"
                aria-expanded="false"
              >
                <i className="fa fa-th"></i>
              </button>
              <ul className="dropdown-menu">
                <li>
                  <div className="nav-appItem">
                    <Link to="/supplier" className="nav-appTile">
                      <div className="nav-Background">
                        <svg className="manage-nav-icon">
                          <use xlinkHref="assets/img/up-sprite.svg#onboard" />
                        </svg>
                        <span className="nav-appTileTitle">
                          <span>On Board Inventory</span>
                        </span>
                      </div>
                    </Link>
                  </div>
                  <div className="nav-appItem">
                    <Link to="/productLink" className="nav-appTile">
                      <div className="nav-Background">
                        <svg className="manage-nav-icon">
                          <use xlinkHref="assets/img/up-sprite.svg#link_product"></use>
                        </svg>
                        <span className="nav-appTileTitle">
                          <span>Link Product catalogue</span>
                        </span>
                      </div>
                    </Link>
                  </div>
                  <div className="nav-appItem">
                    <Link to="/myinventories" className="nav-appTile">
                      <div className="nav-Background">
                        <svg className="manage-nav-icon">
                          <use xlinkHref="assets/img/up-sprite.svg#Qr_code"></use>
                        </svg>
                        <span className="nav-appTileTitle">
                          <span>Manage QR code orders</span>
                        </span>
                      </div>
                    </Link>
                  </div>
                  <div className="nav-appItem">
                    <Link to="/trackProduct" className="nav-appTile">
                      <div className="nav-Background">
                        <svg className="manage-nav-icon">
                          <use xlinkHref="assets/img/up-sprite.svg#trace_track"></use>
                        </svg>
                        <span className="nav-appTileTitle">
                          <span>Trace & Track</span>
                        </span>
                      </div>
                    </Link>
                  </div>
                  <div className="nav-appItem">
                    <Link to="/manageuser" className="nav-appTile">
                      <div className="nav-Background">
                        <svg className="manage-nav-icon">
                          <use xlinkHref="assets/img/up-sprite.svg#manage_user"></use>
                        </svg>
                        <span className="nav-appTileTitle">
                          <span>Manage users</span>
                        </span>
                      </div>
                    </Link>
                  </div>
                </li>
              </ul>
            </div>
            <div className="header-brand">
              <a href="#" title="Unified Trace & Track">
                Unified Track & Trace
              </a>
            </div>
          </div>
          <div className="header-rt">
            <div className="nav navbar-nav">
              <div className="login_user_det">
                <span>Hi</span>&nbsp;&nbsp;
                <span className="l-user">
                  {this.state.user.firstName && this.state.user.lastName
                    ? userLabel(
                        this.state.user.firstName,
                        this.state.user.lastName
                      )
                    : ""}
                </span>
              </div>
              <div className="dropdown">
                <button
                  className="btn "
                  role="button"
                  data-toggle="dropdown"
                  aria-expanded="false"
                >
                  <span className="l-user-first-letter">
                    {this.state.user.firstName
                      ? userName(this.state.user.firstName)
                      : ""}
                  </span>
                </button>
                <div className="dropdown-menu dropdown-menu-right">
                  <a className="dropdown-item" style={{ color: " #007bff" }}>
                    Profile
                  </a>
                  <a className="dropdown-item" style={{ color: " #007bff" }}>
                    My Account
                  </a>
                  <div className="dropdown-divider"></div>
                  <a
                    className="dropdown-item"
                    style={{ color: " #007bff" }}
                    onClick={this.signout}
                  >
                    Log Out
                  </a>
                </div>
              </div>
            </div>
          </div>
        </header>
      </div>
    );
  }
}

export default withRouter(DashBoardHeader);
