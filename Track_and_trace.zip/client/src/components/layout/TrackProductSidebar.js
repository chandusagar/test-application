import React from "react";
import { withRouter, Link } from "react-router-dom";
import { connect } from "react-redux";

class TrackProductSidebar extends React.Component {
  state = {
    pathName: "",
  };

  componentDidMount() {
    this.changeSidebarMenu(this.props.location.pathname.split("/")[1]);
  }

  componentDidUpdate() {
    if (this.state.pathName !== this.props.location.pathname.split("/")[1]) {
      this.changeSidebarMenu(this.props.location.pathname.split("/")[1]);
    }
  }

  changeSidebarMenu = (pathName) => {
    this.setState({ pathName });
  };

  getSidebarMenus = () => {
    const menuNamesList = [
      {
        menuName: `Track Product`,
        pathName: "trackProduct",
        faIcon: "truck",
      },
      {
        menuName: "Track Package",
        pathName: "trackPackage",
        faIcon: "industry",
      },
      {
        menuName: "Counterfeit Product",
        pathName: "counterfeitProduct",
        faIcon: "truck-loading",
      },
      {
        menuName: "Analysis and reports",
        pathName: "analysisReports",
        faIcon: "chart-line",
      },
    ];

    return menuNamesList.map((item, index) => (
      <div
        className={
          this.state.pathName === item.pathName
            ? "uc-main-menu__item uc-main-menu__item--active"
            : "uc-main-menu__item uc-main-menu__item--deactive"
        }
        key={index}
      >
        <Link to={`/${item.pathName}`} className="uc-main-menu__item-section">
          <div className="uc-main-menu__item-section-border">
            <div className="uc-main-menu__item-section-icon">
              <i
                className={`fa fa-${item.faIcon} uc-font-icon uc-font-icon`}
              ></i>
            </div>
          </div>
          <div className="uc-main-menu__item-text">{item.menuName}</div>
        </Link>
      </div>
    ));
  };

  render() {
    return (
      <div className="navbar navbar-expand-lg bg-dark navbar-dark sticky-top">
        <a className="navbar-brand" href="home-page.html">
          <img alt="on-board" src="assets/img/logo.svg" />
          <span>Unified Track & Trace</span>
        </a>
        <div className="d-flex align-items-center">
          <button
            className="navbar-toggler"
            type="button"
            data-toggle="collapse"
            data-target="#navbar-collapse"
            aria-controls="navbar-collapse"
            aria-expanded="false"
            aria-label="Toggle navigation"
          >
            <span className="navbar-toggler-icon"></span>
          </button>
          <div className="d-block d-lg-none mx-2">
            <div className="dropdown">
              <button
                className="btn"
                role="button"
                data-toggle="dropdown"
                aria-expanded="false"
              >
                <span className="l-user-first-letter">r</span>
              </button>
              <div className="dropdown-menu dropdown-menu-right">
                <span className="side-bar-log-user">Ravi Kumar</span>
                <div className="dropdown-divider"></div>
                <a href="#" className="dropdown-item">
                  Profile
                </a>
                <a href="#" className="dropdown-item">
                  My account
                </a>
                <a href="#" className="dropdown-item">
                  Log Out
                </a>
              </div>
            </div>
          </div>
        </div>
        <hr />
        <div className="back-btn">
          <button className="btn mt-2 mb-4 p-0">
            <i className="la la-mail-reply"></i>Back to home
          </button>
        </div>
        <div
          className="collapse navbar-collapse flex-column"
          id="navbar-collapse"
        >
          <div className="uc-main-menu">{this.getSidebarMenus()}</div>
        </div>
        <div className="d-none d-lg-block">
          <div className="dropup">
            <button
              className="btn"
              role="button"
              data-toggle="dropdown"
              aria-expanded="false"
            >
              {" "}
              <span className="l-user-first-letter">r</span>{" "}
            </button>
            <span className="side-bar-log-user">Ravi Kumar</span>
            <div className="dropdown-menu">
              {" "}
              <a className="dropdown-item">Profile</a>{" "}
              <a className="dropdown-item">My Account </a>{" "}
              <a className="dropdown-item">Log Out</a>{" "}
            </div>
          </div>
        </div>
      </div>
    );
  }
}

const mapStateToProps = (state) => ({});

export default connect(mapStateToProps, {})(withRouter(TrackProductSidebar));
