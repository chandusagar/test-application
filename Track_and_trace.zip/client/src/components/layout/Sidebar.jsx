import React from "react";
import { withRouter, Link } from "react-router-dom";
import { connect } from "react-redux";
import SweetAlert from "react-bootstrap-sweetalert";

import { supplierBasicDetails } from "../../actions/supplierAction";

import services from "../../services";

import isEmpty from "../../utils/isEmpty";

class Sidebar extends React.Component {
  state = {
    menuId: "",
    user: {},
  };

  componentDidMount() {
    this.setId(this.props.location.pathname);
    this.setData();
  }

  setData = () => {
    let respData = services.userManagementServices.setCurrentUser();
    let user = JSON.parse(respData);
    this.setState({ user });
  };

  signout = () => {
    services.userManagementServices
      .signoutUser()
      .then((success) => {
        let successpopup = success;
        this.setState({ successpopup });
      })
      .catch((error) => {
        let successpopup = error;
        this.setState({ successpopup });
      });
  };

  hideAlert = () => {
    let redirectPath = "/";
    this.props.history.push(redirectPath);
    this.setState({ successpopup: {} });
  };

  /**show sweet alert popup */
  getAlert = () => {
    return (
      <SweetAlert
        success
        title="Success"
        onConfirm={() => this.hideAlert()}
        btnSize="md"
      >
        {this.state.successpopup.message}
      </SweetAlert>
    );
  };

  setId = (menuId) => {
    this.setState((prevState) => {
      return {
        [menuId]: !this.state[menuId],
        menuId,
        [prevState.menuId]: false,
      };
    });
  };

  componentDidUpdate() {
    if (this.state.menuId !== this.props.location.pathname) {
      this.setState({
        menuId: this.props.location.pathname,
      });
    }
  }

  render() {
    const userName = (string) => {
      return string.charAt(0).toUpperCase() + string.slice(0, 0);
    };

    const userLabel = (firstName, lastName) => {
      let user = `${firstName.charAt(0).toUpperCase() + firstName.slice(1)} ${
        lastName.charAt(0).toUpperCase() + lastName.slice(1)
      }`;
      return user;
    };

    return (
      <div className="navbar navbar-expand-lg bg-dark navbar-dark sticky-top">
        {/* sweet alert popup */}
        {!isEmpty(this.state.successpopup) && this.state.successpopup.message
          ? this.getAlert()
          : ""}
        {/* End sweet alert */}
        <Link className="navbar-brand" to="/dashboard">
          <img alt="on-board" src="../assets/img/logo.svg" />{" "}
          <span>On Board Inventory</span>
        </Link>

        <div className="d-flex align-items-center">
          <button
            className="navbar-toggler"
            type="button"
            data-toggle="collapse"
            data-target="#navbar-collapse"
            aria-controls="navbar-collapse"
            aria-expanded="false"
            aria-label="Toggle navigation"
          >
            <span className="navbar-toggler-icon"></span>
          </button>
          <div className="d-block d-lg-none mx-2">
            <div className="dropdown">
              <a
                href="#"
                role="button"
                data-toggle="dropdown"
                aria-haspopup="true"
                aria-expanded="false"
              >
                <img
                  alt="Image"
                  src="../assets/img/avatar-male-4.jpg"
                  className="avatar"
                />
              </a>
              <div className="dropdown-menu dropdown-menu-right">
                <a href="#" className="dropdown-item">
                  Profile
                </a>
                <a href="#" className="dropdown-item">
                  My account
                </a>
                <a href="#" className="dropdown-item">
                  Log Out
                </a>
              </div>
            </div>
          </div>
        </div>
        <hr />
        <div className="back-btn">
          <Link to="/dashboard">
            <button className="btn mt-2 mb-4 p-0">
              <i className="la la-mail-reply"></i>Back to home
            </button>
          </Link>
        </div>
        <div
          className="collapse navbar-collapse flex-column"
          id="navbar-collapse"
        >
          <div className="uc-supplyflow">
            <div
              className={
                this.state.menuId === "/supplier" ||
                this.state.menuId.indexOf("editsupplier") === 1
                  ? "uc-supplyflow__item uc-supplyflow__item--active"
                  : "uc-supplyflow__item uc-supplyflow__item--deactive"
              }
              onClick={() => this.setId("/supplier")}
            >
              <Link to="/supplier">
                <a className="uc-supplyflow__item-section">
                  <div className="uc-supplyflow__item-section-border">
                    <div className="uc-supplyflow__item-section-icon">
                      <i className="fa fa-truck uc-font-icon"></i>
                    </div>
                  </div>
                  <div className="uc-supplyflow__item-text">Supplier</div>
                </a>
              </Link>
            </div>
            <div
              className={
                this.state.menuId === "/manufacturer" ||
                this.state.menuId.indexOf("editmanufacturer") === 1
                  ? "uc-supplyflow__item uc-supplyflow__item--active"
                  : "uc-supplyflow__item uc-supplyflow__item--deactive"
              }
              onClick={() => this.setId("/manufacturer")}
            >
              <Link to="/manufacturer">
                <a className="uc-supplyflow__item-section">
                  <div className="uc-supplyflow__item-section-border">
                    <div className="uc-supplyflow__item-section-icon">
                      <i className="fa fa-industry uc-font-icon"></i>
                    </div>
                  </div>
                  <div className="uc-supplyflow__item-text">Manufacturer</div>
                </a>
              </Link>
            </div>
            <div
              className={
                this.state.menuId === "/logistics" ||
                this.state.menuId.indexOf("editlogistics") === 1
                  ? "uc-supplyflow__item uc-supplyflow__item--active"
                  : "uc-supplyflow__item uc-supplyflow__item--deactive"
              }
              onClick={() => this.setId("logistics")}
            >
              <Link to="/logistics">
                <a className="uc-supplyflow__item-section">
                  <div className="uc-supplyflow__item-section-border">
                    <div className="uc-supplyflow__item-section-icon">
                      <i className="fa fa-truck-loading uc-font-icon"></i>
                    </div>
                  </div>
                  <div className="uc-supplyflow__item-text">Logistics</div>
                </a>
              </Link>
            </div>
            <div
              className={
                this.state.menuId === "/distributor" ||
                this.state.menuId.indexOf("editdistributor") === 1
                  ? "uc-supplyflow__item uc-supplyflow__item--active"
                  : "uc-supplyflow__item uc-supplyflow__item--deactive"
              }
              onClick={() => this.setId("/distributor")}
            >
              <Link to="/distributor">
                <a className="uc-supplyflow__item-section">
                  <div className="uc-supplyflow__item-section-border">
                    <div className="uc-supplyflow__item-section-icon">
                      <i className="fa fa-warehouse uc-font-icon"></i>
                    </div>
                  </div>
                  <div className="uc-supplyflow__item-text"> Distributor</div>
                  {/* Warehouse */}
                </a>
              </Link>
            </div>
            <div
              className={
                this.state.menuId === "/retailer" ||
                this.state.menuId.indexOf("editretailer") === 1
                  ? "uc-supplyflow__item uc-supplyflow__item--active"
                  : "uc-supplyflow__item uc-supplyflow__item--deactive"
              }
              onClick={() => this.setId("/retailer")}
            >
              <Link to="/retailer">
                <a className="uc-supplyflow__item-section">
                  <div className="uc-supplyflow__item-section-border">
                    <div className="uc-supplyflow__item-section-icon">
                      <i className="fas fa-store uc-font-icon"></i>
                    </div>
                  </div>
                  <div className="uc-supplyflow__item-text">Retailer</div>
                </a>
              </Link>
            </div>
          </div>
        </div>
        <div className="d-none d-lg-block">
          <div className="dropup">
            <button
              className="btn"
              role="button"
              data-toggle="dropdown"
              aria-expanded="false"
            >
              <span className="l-user-first-letter">
                {this.state.user.firstName
                  ? userName(this.state.user.firstName)
                  : ""}
              </span>
            </button>
            <div style={{ position: "absolute", top: "4px", left: "68%" }}>
              <span className="side-bar-log-user">
                {this.state.user.firstName && this.state.user.lastName
                  ? userLabel(
                      this.state.user.firstName,
                      this.state.user.lastName
                    )
                  : ""}
              </span>
            </div>
            <div className="dropdown-menu">
              <a href="#" className="dropdown-item">
                Profile
              </a>
              <a href="#" className="dropdown-item">
                My Account
              </a>
              <a onClick={this.signout} className="dropdown-item">
                Log Out
              </a>
            </div>
          </div>
        </div>
      </div>
    );
  }
}

const mapStateToProps = (state) => ({
  supplier: state.supplier,
});

export default connect(mapStateToProps, { supplierBasicDetails })(
  withRouter(Sidebar)
);
