import React, { Component } from "react";
import { withRouter, Link } from "react-router-dom";
import { connect } from "react-redux";
import SweetAlert from "react-bootstrap-sweetalert";

import services from "../../services";

import isEmpty from "../../utils/isEmpty";

class QRSidebar extends React.Component {
  state = {
    pathName: "",
    user: {},
    successpopup: {},
  };

  componentDidMount() {
    this.changeSidebarMenu(this.props.location.pathname.split("/")[1]);
    this.setData();
  }

  componentDidUpdate() {
    if (this.state.pathName !== this.props.location.pathname.split("/")[1]) {
      this.changeSidebarMenu(this.props.location.pathname.split("/")[1]);
    }
  }

  changeSidebarMenu = (pathName) => {
    this.setState({ pathName });
  };

  setData = () => {
    let respData = services.userManagementServices.setCurrentUser();
    let user = JSON.parse(respData);
    this.setState({ user });
  };

  signout = () => {
    services.userManagementServices
      .signoutUser()
      .then((success) => {
        // alert(success.message);
        let successpopup = success;
        this.setState({ successpopup });
      })
      .catch((error) => {
        let successpopup = error;
        this.setState({ successpopup });
      });
  };

  hideAlert = () => {
    let redirectPath = "/";
    this.props.history.push(redirectPath);
    this.setState({ successpopup: {} });
  };

  /**show sweet alert popup */
  getAlert = () => {
    return (
      <SweetAlert
        success
        title="Success"
        onConfirm={() => this.hideAlert()}
        btnSize="md"
      >
        {this.state.successpopup.message}
      </SweetAlert>
    );
  };

  getSidebarMenus = () => {
    const menuNamesList = [
      {
        menuName: "My Inventories",
        pathName: "myinventories",
        faIcon: "truck",
      },
      {
        menuName: "Supplier QR Code",
        pathName: "supplierqrcodeorders",
        faIcon: "truck-loading",
      },
      {
        menuName: "Package QR Code",
        pathName: "packageqrcodeorders",
        faIcon: "industry",
      },
    ];

    return menuNamesList.map((item, index) => (
      <div
        className={
          this.state.pathName === item.pathName
            ? "uc-main-menu__item uc-main-menu__item--active"
            : "uc-main-menu__item uc-main-menu__item--deactive"
        }
        key={index}
      >
        <Link to={`/${item.pathName}`}>
          <a className="uc-main-menu__item-section">
            <div className="uc-main-menu__item-section-border">
              <div className="uc-main-menu__item-section-icon">
                <i className={`fa fa-${item.faIcon} uc-font-icon`} />{" "}
              </div>
            </div>
            <div className="uc-main-menu__item-text">{item.menuName}</div>
          </a>
        </Link>
      </div>
    ));
  };

  render() {
    const userName = (string) => {
      return string.charAt(0).toUpperCase() + string.slice(0, 0);
    };

    const userLabel = (firstName, lastName) => {
      let user = `${firstName.charAt(0).toUpperCase() + firstName.slice(1)} ${
        lastName.charAt(0).toUpperCase() + lastName.slice(1)
      }`;
      // return string.charAt(0).toUpperCase() + string.slice(0, 0);
      return user;
    };

    return (
      <div>
        {/* sweet alert popup */}
        {!isEmpty(this.state.successpopup) && this.state.successpopup.message
          ? this.getAlert()
          : ""}
        {/* End sweet alert */}
        <div className="layout layout-nav-side">
          <div className="navbar navbar-expand-lg bg-dark navbar-dark sticky-top">
            <a className="navbar-brand" href="home-page.html">
              <img alt="on-board" src="assets/img/logo.svg" />
              <span>Supply Chain Integration </span>
            </a>
            <div className="d-flex align-items-center">
              <button
                className="navbar-toggler"
                type="button"
                data-toggle="collapse"
                data-target="#navbar-collapse"
                aria-controls="navbar-collapse"
                aria-expanded="false"
                aria-label="Toggle navigation"
              >
                <span className="navbar-toggler-icon"></span>
              </button>
              <div className="d-block d-lg-none mx-2">
                <div className="dropdown">
                  <button
                    className="btn"
                    role="button"
                    data-toggle="dropdown"
                    aria-expanded="false"
                  >
                    <span className="l-user-first-letter">
                      {this.state.user.firstName
                        ? userName(this.state.user.firstName)
                        : ""}
                    </span>
                  </button>
                  <div className="dropdown-menu dropdown-menu-right">
                    <span className="side-bar-log-user">
                      {this.state.user.firstName && this.state.user.lastName
                        ? userLabel(
                            this.state.user.firstName,
                            this.state.user.lastName
                          )
                        : ""}
                    </span>
                    <div className="dropdown-divider" />
                    <a href="#" className="dropdown-item">
                      Profile
                    </a>
                    <a href="#" className="dropdown-item">
                      My account
                    </a>
                    <a onClick={this.signout} className="dropdown-item">
                      Log Out
                    </a>
                  </div>
                </div>
              </div>
            </div>
            <hr />
            <div className="back-btn">
              <Link to="/dashboard">
                <button className="btn mt-2 mb-4 p-0">
                  <i className="la la-mail-reply" />
                  Back to home
                </button>
              </Link>
            </div>
            <div
              className="collapse navbar-collapse flex-column"
              id="navbar-collapse"
            >
              <div className="uc-main-menu">
                {/*Begin::Item */}
                {this.getSidebarMenus()}
              </div>
            </div>
            <div className="d-none d-lg-block">
              <div className="dropup">
                <button
                  className="btn"
                  role="button"
                  data-toggle="dropdown"
                  aria-expanded="false"
                >
                  <span className="l-user-first-letter">
                    {this.state.user.firstName
                      ? userName(this.state.user.firstName)
                      : ""}
                  </span>{" "}
                </button>
                <span className="side-bar-log-user">
                  {this.state.user.firstName && this.state.user.lastName
                    ? userLabel(
                        this.state.user.firstName,
                        this.state.user.lastName
                      )
                    : ""}
                </span>
                <div className="dropdown-menu">
                  <a href="#" className="dropdown-item">
                    Profile
                  </a>
                  <a href="#" className="dropdown-item">
                    My Account
                  </a>
                  <a onClick={this.signout} className="dropdown-item">
                    Log Out
                  </a>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }
}

const mapStateToProps = (state) => ({});

export default connect(mapStateToProps, {})(withRouter(QRSidebar));
