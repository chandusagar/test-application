import React, { Component } from "react";
import { withRouter, Link } from "react-router-dom";
import DashBoardHeader from "./DashBoardHeader";

class Dashboard extends Component {
  render() {
    return (
      <div className="wrapper">
        <div className="content-page">
          <div className="content">
            <div className="topnav-navbar topnav-navbar-light">
              <DashBoardHeader />
            </div>
            <div className="container-fluid">
              <div className="home-main p-6 mb-4">
                <div className="row">
                  <div className="col-12 pb-6">
                    <div className="font-weight-bolder text-dark h4">
                      Unified Track & Trace is a blockchain based Food
                      traceability solution built to enable trust, coordination,
                      and transparency in fragmented supply chains.
                    </div>
                  </div>
                </div>
                <div className="row mt-3">
                  <div className="col-md-4">
                    <Link to="/supplier">
                      <div className="media">
                        <div className="icon mr-3 on_board_bg">
                          <svg className="manage-nav-icon">
                            <use xlinkHref="assets/img/up-sprite.svg#onboard"></use>
                          </svg>
                        </div>
                        <div className="media-body">
                          <div className="h4">On Board Inventory</div>
                          <p className="text-dark text-left">
                            Lorem ipsum dolor sit amet, consectetuer adipiscing
                            elit.
                          </p>
                        </div>
                      </div>
                    </Link>
                  </div>
                  <div className="col-md-4">
                    <Link to="/productLink">
                      <div className="media">
                        <div className="icon mr-3 link_product_bg">
                          <svg className="manage-nav-icon ">
                            <use xlinkHref="assets/img/up-sprite.svg#link_product"></use>
                          </svg>
                        </div>
                        <div className="media-body">
                          <div className="h4">Link Product catalogue</div>
                          <p className="text-dark text-left">
                            Lorem ipsum dolor sit amet, consectetuer adipiscing
                            elit.
                          </p>
                        </div>
                      </div>
                    </Link>
                  </div>
                  <div className="col-md-4">
                    <Link to="/myinventories">
                      <div className="media">
                        <div className="icon mr-3 manage_qr_bg">
                          <svg className="manage-nav-icon ">
                            <use xlinkHref="assets/img/up-sprite.svg#Qr_code"></use>
                          </svg>
                        </div>
                        <div className="media-body">
                          <div className="h4">Manage QR code orders</div>
                          <p className="text-dark text-left">
                            Lorem ipsum dolor sit amet, consectetuer adipiscing
                            elit.
                          </p>
                        </div>
                      </div>
                    </Link>
                  </div>
                </div>
                <div className="row mt-5">
                  <div className="col-md-4">
                    <Link to="/trackProduct">
                      <div className="media">
                        <div className="icon mr-3 trace_bg">
                          <svg className="manage-nav-icon ">
                            <use xlinkHref="assets/img/up-sprite.svg#trace_track"></use>
                          </svg>
                        </div>
                        <div className="media-body">
                          <div className="h4">Trace & Track</div>
                          <p className="text-dark text-left">
                            Lorem ipsum dolor sit amet, consectetuer adipiscing
                            elit.
                          </p>
                        </div>
                      </div>
                    </Link>
                  </div>
                  <div className="col-md-4">
                    <Link to="/manageuser">
                      <div className="media">
                        <div className="icon mr-3 m_user_bg">
                          <svg className="manage-nav-icon">
                            <use xlinkHref="assets/img/up-sprite.svg#manage_user"></use>
                          </svg>
                        </div>
                        <div className="media-body">
                          <div className="h4">Manage users</div>
                          <p className="text-dark text-left">
                            Lorem ipsum dolor sit amet, consectetuer adipiscing
                            elit.
                          </p>
                        </div>
                      </div>
                    </Link>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }
}

export default withRouter(Dashboard);
