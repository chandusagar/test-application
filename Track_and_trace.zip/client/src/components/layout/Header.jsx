import React from "react";
import { Link } from "react-router-dom";

class Header extends React.Component {
  render() {
    return (
      <div
        className="breadcrumb-bar navbar bg-white sticky-top"
        style={{ position: "relative" }}
      >
        <nav aria-label="breadcrumb">
          <ol className="breadcrumb">
            <li className="breadcrumb-item">
              <Link to="/dashboard">Home</Link>
            </li>
            <li className="breadcrumb-item active" aria-current="page">
              {this.props.name}
            </li>
          </ol>
        </nav>
      </div>
    );
  }
}

export default Header;
