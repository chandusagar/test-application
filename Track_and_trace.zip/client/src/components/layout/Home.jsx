import React from "react";
import { withRouter, Link } from "react-router-dom";
import Sidebar from "./Sidebar";
import Routes from "../../Routes";
import QRSidebar from "./QRSidebar";
import TrackProductSidebar from "./TrackProductSidebar";

class Home extends React.Component {
  componentDidMount() {
    console.log("Homepage", this.props.location.pathname);
  }

  render() {
    const pathname = this.props.location.pathname;
    return (
      <>
        {pathname === "/supplier" ||
        pathname === "/manufacturer" ||
        pathname === "/logistics" ||
        pathname === "/distributor" ||
        pathname === "/retailer" ||
        pathname.indexOf("editsupplier") === 1 ||
        pathname.indexOf("editmanufacturer") === 1 ||
        pathname.indexOf("editlogistics") === 1 ||
        pathname.indexOf("editdistributor") === 1 ||
        pathname.indexOf("editretailer") === 1 ? (
          <div className="layout layout-nav-side">
            <Sidebar />
            <div className="main-container">
              <Routes />
            </div>
          </div>
        ) : pathname === "/packageqrcodeorders" ||
          pathname === "/supplierqrcodeorders" ||
          pathname === "/myinventories" ? (
          <div className="layout layout-nav-side">
            <QRSidebar />
            <div className="main-container">
              <Routes />
            </div>
          </div>
        ) : pathname === "/trackProduct" ||
          pathname === "/trackPackage" ||
          pathname === "/counterfeitProduct" ? (
          <div className="layout layout-nav-side">
            <TrackProductSidebar />
            <Routes />
          </div>
        ) : (
          <Routes />
        )}
      </>
    );
  }
}
export default withRouter(Home);
