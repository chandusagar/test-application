import React from "react";
import { Redirect } from "react-router-dom";

/**import services */
import services from "../../services";

/**import util file/isEmpty */
import isEmpty from "../../utils/isEmpty";

class ProtectedRoute extends React.Component {
  state = {};

  isAuthenticated = () => {
    let respData = services.userManagementServices.setCurrentUser();
    let user = JSON.parse(respData);
    return !isEmpty(user) ? true : false;
  };

  render() {
    const Component = this.props.component;

    return this.isAuthenticated() ? (
      <Component />
    ) : (
      <Redirect to={{ pathname: "/" }} />
    );
  }
}

export default ProtectedRoute;
