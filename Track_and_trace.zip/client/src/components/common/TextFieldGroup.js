import React from "react";
import { PropTypes } from "prop-types";

const TextFieldGroup = ({
  name,
  placeholder,
  id,
  value,
  label,
  error,
  type,
  onChange,
  disabled,
  toolTipInfo,
  isValidate,
  maxlength,
}) => {
  return (
    <div>
      {label ? (
        <label className="text-small">
          {label}
          {isValidate === "true" ? <span className="astric">*</span> : ""}
        </label>
      ) : (
        ""
      )}

      <input
        type={type}
        id={id}
        className="form-control"
        placeholder={placeholder}
        name={name}
        value={value}
        onChange={onChange}
        disabled={disabled}
        maxlength={maxlength}
      />
      {error && <p className="text-danger text-small">{error}</p>}

      {toolTipInfo ? (
        <span
          className="fa fa-info-circle fa-lg"
          data-toggle="tooltip"
          data-placement="right"
          title={toolTipInfo}
          style={{ paddingTop: "10px", color: "#324c64", fontSize: "14px" }}
        />
      ) : (
        ""
      )}
    </div>
  );
};
TextFieldGroup.propTypes = {
  name: PropTypes.string.isRequired,
  id: PropTypes.string,
  placeholder: PropTypes.string,
  error: PropTypes.string,
  type: PropTypes.string.isRequired,
  onChange: PropTypes.func.isRequired,
  disabled: PropTypes.string,
  label: PropTypes.string,
  maxlength: PropTypes.string,
  toolTipInfo: PropTypes.string,
  isValidate: PropTypes.string,
};
TextFieldGroup.defaultProps = {
  type: "text",
  isValidate: "true",
};

export default TextFieldGroup;
