import React from "react";
import PropTypes from "prop-types";

const SelectListGroup = ({
  name,
  value,
  error,
  label,
  onChange,
  options,
  toolTipInfo,
  showColumns,
  disabled,
}) => {
  const selectOptions =
    options &&
    options.map((option) => (
      <option
        key={option.name ? option.name : option}
        value={option.value ? option.value : option.value}
      >
        {option.name ? option.name : option.name}
      </option>
    ));

  const selectColumnsOptions =
    options &&
    options.map((option) => (
      <option
        key={option.columnName ? option.columnName : option}
        value={option.columnName ? option.columnName : option}
      >
        {option.columnName ? option.columnName : option}
      </option>
    ));
  return (
    <div>
      {label ? (
        <label className="text-small">
          {label}
          <span className="astric">*</span>
        </label>
      ) : (
        ""
      )}
      <select
        className="form-control"
        name={name}
        value={value}
        onChange={onChange}
        disabled={disabled}
      >
        <option value="">Please Select</option>

        {showColumns === "true" ? selectColumnsOptions : selectOptions}
      </select>
      {error && <p className="text-danger text-small">{error}</p>}
      {/* <span
        className="fa fa-info-circle fa-lg"
        data-html="true"
        data-toggle="tooltip"
        data-placement="right"
        title={toolTipInfo}
        style={{ paddingTop: "10px", color: "#324c64", fontSize: "14px" }}
      /> */}
    </div>
  );
};

SelectListGroup.propTypes = {
  name: PropTypes.string.isRequired,
  value: PropTypes.string,
  label: PropTypes.string,
  onChange: PropTypes.func.isRequired,
  options: PropTypes.array.isRequired,
  toolTipInfo: PropTypes.string,
  showColumns: PropTypes.string,
};

export default SelectListGroup;
