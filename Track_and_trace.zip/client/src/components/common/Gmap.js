import React, { Component } from "react";
import {
  Map,
  InfoWindow,
  Marker,
  Polygon,
  Polyline,
  GoogleApiWrapper,
} from "google-maps-react";

import isEmpty from "../../../src/utils/isEmpty";

export class Gmap extends Component {
  state = {
    showingInfoWindow: [false],
    activeMarker: [{}],
    selectedPlace: [{}],
  };

  onMarkerClick = (props, marker, i) => {
    this.setState((prevState) => {
      prevState.selectedPlace[i] = props;
      prevState.activeMarker[i] = marker;
      prevState.showingInfoWindow[i] = true;
      return prevState;
    });
  };

  onMapClicked = (props) => {
    if (this.state.showingInfoWindow) {
      this.setState((prevState) => {
        prevState.activeMarker = [{}];
        prevState.showingInfoWindow = [false];
        return prevState;
      });
    }
  };

  render() {
    /**multiple marker zoom update */
    const boundsZoom = () => {
      if (this.props.mapDetails && this.props.mapDetails.length > 0) {
        let bounds = new this.props.google.maps.LatLngBounds();
        for (var i = 0; i < this.props.mapDetails.length; i++) {
          bounds.extend(this.props.mapDetails[i]);
        }
        return bounds;
      }
    };

    const zoom = () => {
      // this.props.location && this.props.location.lat ? 15 : null;
      if (
        this.props.location &&
        this.props.location.lat &&
        this.props.location.lng
      ) {
        return 15;
      }
    };

    return (
      <Map
        google={this.props.google}
        containerStyle={this.props.style}
        // zoom={14}
        zoom={zoom()}
        center={
          !isEmpty(this.props.location)
            ? {
                lat: this.props.location.lat,
                lng: this.props.location.lng,
              }
            : {}
        }
        initialCenter={
          this.props.mapDetails && this.props.mapDetails.length > 0
            ? {
                lat: this.props.mapDetails[this.props.mapDetails.length - 1]
                  .lat,
                lng: this.props.mapDetails[this.props.mapDetails.length - 1]
                  .lng,
              }
            : ""
        }
        bounds={boundsZoom()}
        scrollwheel={true}
        streetViewControl={true}
        onClick={this.onMapClicked}
      >
        {/* dynamic marker postion */}
        {this.props.mapDetails && this.props.mapDetails.length > 0 ? (
          <Polyline
            path={this.props.mapDetails}
            strokeColor="#ea4335"
            strokeOpacity={0.8}
            strokeWeight={3}
          />
        ) : (
          ""
        )}

        {this.props.mapDetails && this.props.mapDetails.length > 0
          ? this.props.mapDetails.map((item, i) => (
              <Marker
                key={i}
                draggable={false}
                position={{
                  lat: item.lat,
                  lng: item.lng,
                }}
                label={
                  item.address && item.address.docType === "Supplier"
                    ? "S"
                    : item.address && item.address.docType === "Manufacturer"
                    ? "M"
                    : item.address && item.address.docType === "Logistics"
                    ? "L"
                    : item.address && item.address.docType === "Distributor"
                    ? "D"
                    : item.address && item.address.docType === "Retailer"
                    ? "R"
                    : item.label
                }
                onClick={(props, marker) =>
                  this.onMarkerClick(props, marker, i)
                }
              />
            ))
          : ""}

        {this.props.mapDetails && this.props.mapDetails.length > 0
          ? this.props.mapDetails.map((item, i) => (
              <InfoWindow
                key={i}
                marker={this.state.activeMarker[i]}
                visible={this.state.showingInfoWindow[i]}
              >
                <div key={i}>
                  {item.label === "S" ? (
                    <h6>Supplier:-</h6>
                  ) : item.label === "M" ? (
                    <h6>Manufacturer:-</h6>
                  ) : item.address && item.address.docType ? (
                    <h6>{item.address.docType}:-</h6>
                  ) : (
                    ""
                  )}

                  {item.address
                    ? `${item.address.address}${item.address.city},${item.address.state} ${item.address.zipCode},${item.address.country}`
                    : ""}
                </div>
              </InfoWindow>
            ))
          : ""}

        {/* End dynamic marker postion */}

        {/* single marker position */}
        {!isEmpty(this.props.location) &&
        this.props.location.lat &&
        this.props.location.lng ? (
          <Marker
            draggable={false}
            position={{
              lat: this.props.location.lat,
              lng: this.props.location.lng,
            }}
            name={"Current location"}
            onClick={(props, marker) => this.onMarkerClick(props, marker, 0)}
          />
        ) : (
          ""
        )}
        {!isEmpty(this.props.location) &&
        this.props.location.lat &&
        this.props.location.lng ? (
          <InfoWindow
            marker={this.state.activeMarker[0]}
            visible={this.state.showingInfoWindow[0]}
          >
            <div>
              {this.props.address
                ? `${this.props.address.address}${this.props.address.city},${this.props.address.state} ${this.props.address.zipCode},${this.props.address.country}`
                : ""}
            </div>
          </InfoWindow>
        ) : (
          ""
        )}
        {/* End single marker postion */}
      </Map>
    );
  }
}

export default GoogleApiWrapper({
  apiKey: "AIzaSyDUsoLY33TlpJ4feuhEPJFF3Q9HGP1iC5g",
})(Gmap);
