import React from "react";
import { BrowserRouter as Router, Route, Switch } from "react-router-dom";

import Signin from "./components/signup/Signin";
import Signup from "./components/signup/Signup";
import CreatePassword from "./components/signup/CreatePassword";
import AccountVerification from "./components/signup/AccountVerification";
import SignupConfirmation from "./components/signup/SignupConfirmation";

//home and dash board routes
import Dashboard from "./components/layout/Dashboard";

//on Board Inventory routes
import Supplier from "./components/onBoardInventory/supplier/Supplier";
import Manufacture from "./components/onBoardInventory/manufacturer/Manufacturer";
import logistics from "./components/onBoardInventory/logistics/logistics";
import Distributor from "./components/onBoardInventory/distributor/Distributor";
import Retailer from "./components/onBoardInventory/retailer/Retailer";

//user Management routes
import Manageuser from "./components/userManagement/ManageUser";

// QR code orders routes
import PackageQRCodeOrders from "./components/qrcodeOrders/package/PackageQRCodeOrders";
import SupplierQRCodeOrders from "./components/qrcodeOrders/supplier/SupplierQRCodeOrders";
import OrderDetails from "./components/qrcodeOrders/package/OrderDetails";
import SupplierOrderDetails from "./components/qrcodeOrders/supplier/SupplierOrderDetails";
import PreviewPackageDetails from "./components/qrcodeOrders/package/PreviewPackageDetails";
import PreviewSupplierPackageDetails from "./components/qrcodeOrders/supplier/PreviewSupplierPackageDetails";

import MyInventories from "./components/qrcodeOrders/myInventories/myInventoriesList";

//LINK Product routes
import ProductLink from "./components/linkProductCatalogue/ProductLink";

/**track And Trace routes */
import TrackProduct from "./components/TrackAndTraceProduct/trackProduct/TrackProduct";
import TrackPackage from "./components/TrackAndTraceProduct/trackPackage/TrackPackage";
import CounterfeitProduct from "./components/TrackAndTraceProduct/counterfeitProduct/CounterfeitProduct";

import ProtectedRoute from "./components/common/ProtectedRoute";

function Routes() {
  return (
    <Switch>
      <Route exact path="/" component={Signin} />
      <Route exact path="/signup" component={Signup} />
      <Route exact path="/signup/:companyId" component={CreatePassword} />
      <Route
        exact
        path="/verifyAccount/:email"
        component={AccountVerification}
      />
      <ProtectedRoute
        exact
        path="/signupConfirmation"
        component={SignupConfirmation}
      />

      <ProtectedRoute exact path="/supplier" component={Supplier} />
      <ProtectedRoute exact path="/manufacturer" component={Manufacture} />
      <ProtectedRoute exact path="/logistics" component={logistics} />
      <ProtectedRoute exact path="/distributor" component={Distributor} />
      <ProtectedRoute exact path="/retailer" component={Retailer} />

      <Route exact path="/editsupplier/:supplierId" component={Supplier} />
      <Route
        exact
        path="/editmanufacturer/:manufacturerId"
        component={Manufacture}
      />
      <Route exact path="/editlogistics/:logisticId" component={logistics} />
      <Route
        exact
        path="/editdistributor/:distributorId"
        component={Distributor}
      />
      <Route exact path="/editretailer/:retailerId" component={Retailer} />

      <ProtectedRoute exact path="/manageuser" component={Manageuser} />
      <ProtectedRoute exact path="/dashboard" component={Dashboard} />
      <ProtectedRoute
        exact
        path="/packageqrcodeorders"
        component={PackageQRCodeOrders}
      />
      <ProtectedRoute
        exact
        path="/supplierqrcodeorders"
        component={SupplierQRCodeOrders}
      />
      <Route exact path="/orderDetails/:orderId" component={OrderDetails} />
      <Route
        exact
        path="/previewPackageDetails/:orderId"
        component={PreviewPackageDetails}
      />
      <Route
        exact
        path="/supplierOrderDetails/:orderId"
        component={SupplierOrderDetails}
      />

      <ProtectedRoute exact path="/productLink" component={ProductLink} />
      <ProtectedRoute exact path="/trackProduct" component={TrackProduct} />
      <ProtectedRoute exact path="/trackPackage" component={TrackPackage} />
      <ProtectedRoute
        exact
        path="/counterfeitProduct"
        component={CounterfeitProduct}
      />
      <Route
        exact
        path="/previewSupplierPackageDetails/:orderId"
        component={PreviewSupplierPackageDetails}
      />
      <ProtectedRoute exact path="/myinventories" component={MyInventories} />
    </Switch>
  );
}
export default Routes;
